# 仕様を真実の源にする開発 第5版（Kindle・Word・後ろに追加した部）

## 中身
| ファイル | 用途 |
|---|---|
| spec-driven-development-5th.epub | Kindle（KDP）へ投入する EPUB（目次つき、図5点を内蔵） |
| spec-driven-development-5th.docx | Word 版（同じ原稿から作成、図5点を内蔵） |
| book.md | 原稿（正本）。EPUB と Word は、ここから作る |
| figures/ | 図（PNG 5点）。Mermaid の図を、Chromium で描画した画像 |
| kindle.css、reference-jp.docx | スタイル |
| parts/ | 追加した部の原稿（A：仕様とソース、B：改修の方法） |

## 第5版で追加した部（後ろ）
- 第21〜27章：仕様書とソースの対応（関数の解説、行番号、図、Why・What・How）
- 第28〜34章：改修の4つの方法（スキル、Claude、Claude Code、手動）と、実例（分割単位に2分を加える）
- 付録F：関数の索引

## 原稿を直すとき
```bash
pandoc book.md -o spec-driven-development-5th.epub --css kindle.css --toc --toc-depth=2 -M lang=ja --split-level=1 --resource-path=.
pandoc book.md -o spec-driven-development-5th.docx --toc --reference-doc=reference-jp.docx -M lang=ja --resource-path=.
```
EPUB と Word は、必ず両方作り直す。

## 確かめたこと・確かめていないこと
| 項目 | 状態 |
|---|---|
| EPUB の構造、全 XML の整形、言語 ja、書名、識別子、図5点の内蔵 | 確認済み |
| Word 版：開けること（PDF に変換。70ページ）、見出し、表、図5点 | 確認済み |
| 第33章の実例（作業コピーで実行：単体27件、画面13件合格、verify OK） | 確認済み |
| 第31章の Claude Code の操作、第29章のスキルの実行、第30章のチャット | 説明（この環境では、実際の操作は行っていない） |
| 関数の説明と行番号 | この版（v2.9.0）のソースに基づく。ソースが変わったら索引を作り直す |
| Kindle Previewer での表示 | 未確認（投入前に確認） |
