---
title: "Azure Speechを使うJavaScript開発でローカルMockサーバーを作る"
emoji: "🎤"
type: "tech"
topics: ["JavaScript", "Azure", "AzureSpeech", "Node.js", "Mock"]
published: false
---

## はじめに

Azure Speechを利用するJavaScriptアプリケーションを開発するとき、毎回AzureのAPIに接続して動作確認するのは少し面倒です。

例えば、次のような問題があります。

- Azureのサブスクリプションやリソースが必要
- APIキーやリージョンの設定が必要
- APIの呼び出し回数や料金が気になる
- ネットワーク環境によってテスト結果が変わる
- エラー時の動作を意図的に再現しにくい

そこで今回は、**Azure Speech APIに接続せずに、ローカル環境だけで動作確認できるMockサーバー**をNode.jsで作成します。

VS Codeを使い、JavaScriptのフロントエンドからローカルMockサーバーにリクエストを送り、ダミーの文字起こし結果を受け取る構成です。

## この記事で作るもの

今回作成する環境は次のとおりです。

```text
ブラウザ
  |
  | HTTP POST
  v
JavaScriptアプリ
  |
  | http://127.0.0.1:8787
  v
Mockサーバー（Node.js）
  |
  | ダミーの文字起こし結果
  v
JavaScriptアプリに結果を返す
```

実際のAzure Speech APIは呼び出しません。

Mockサーバーが固定のダミー結果を返すため、AzureのリソースやAPIキーがなくても画面やエラー処理を確認できます。

## 1. 開発環境

今回使用するものは次のとおりです。

| 項目 | 内容 |
|---|---|
| エディター | Visual Studio Code |
| 実行環境 | Node.js 20以上 |
| 言語 | JavaScript |
| サーバー | Node.js標準HTTPモジュール |
| ブラウザ | Chromeなど |
| 外部ライブラリ | 原則不要 |

Node.jsがインストールされていることを確認します。

```bash
node --version
npm --version
```

## 2. プロジェクトを作成する

作業用フォルダーを作成します。

```bash
mkdir azure-speech-js-mock
cd azure-speech-js-mock
code .
```

次のファイルを作成します。

```text
azure-speech-js-mock/
├── mock-server.js
├── web-server.js
├── config.js
├── index.html
├── app.js
└── style.css
```

## 3. Mockサーバーを作成する

まず、Mockサーバー本体を作成します。

`mock-server.js` を作成し、次のコードを記述します。

```javascript
import http from "node:http";

const PORT = 8787;
const MOCK_KEY = "local-mock-key";

const server = http.createServer(async (req, res) => {
  // CORS設定
  res.setHeader("Access-Control-Allow-Origin", "http://127.0.0.1:5500");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Content-Type, Ocp-Apim-Subscription-Key"
  );

  // OPTIONSリクエスト
  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  // エンドポイント確認
  if (
    req.method !== "POST" ||
    req.url !== "/speechtotext/transcriptions:transcribe"
  ) {
    res.writeHead(404);
    res.end(JSON.stringify({ error: "Not Found" }));
    return;
  }

  // APIキー確認
  if (req.headers["ocp-apim-subscription-key"] !== MOCK_KEY) {
    res.writeHead(401, {
      "Content-Type": "application/json"
    });
    res.end(JSON.stringify({ error: "Unauthorized" }));
    return;
  }

  // リクエストボディを受信
  let body = [];

  for await (const chunk of req) {
    body.push(chunk);
  }

  // 少し待ってからダミー結果を返す
  await new Promise(resolve => setTimeout(resolve, 1200));

  const result = {
    combinedPhrases: [
      {
        text: "これはローカルMockサーバーによるテスト結果です。"
      }
    ]
  };

  res.writeHead(200, {
    "Content-Type": "application/json"
  });

  res.end(JSON.stringify(result));
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`Mock server: http://127.0.0.1:${PORT}`);
});
```

このサーバーでは、次の処理を行っています。

1. 指定されたエンドポイントへのPOSTを受け付ける
2. Mock用APIキーを確認する
3. リクエストを受信する
4. 1.2秒待機する
5. ダミーの文字起こし結果をJSONで返す

> **注意:** このコードはローカル開発用の簡易例です。Azure Speechの正式なAPI実装や認証方式を完全に再現するものではありません。

## 4. フロントエンドから接続する

フロントエンド側では、接続先とMock用キーを設定します。

`config.js`

```javascript
export const config = {
  endpoint: "http://127.0.0.1:8787",
  apiKey: "local-mock-key"
};
```

`app.js` からMockサーバーにリクエストを送信します。

```javascript
import { config } from "./config.js";

export async function sendToMock(file) {
  const formData = new FormData();
  formData.append("file", file);

  const response = await fetch(
    `${config.endpoint}/speechtotext/transcriptions:transcribe`,
    {
      method: "POST",
      headers: {
        "Ocp-Apim-Subscription-Key": config.apiKey
      },
      body: formData
    }
  );

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }

  return await response.json();
}
```

これで、ブラウザからローカルMockサーバーにファイルを送信できるようになります。

## 5. ローカルWebサーバーを起動する

ブラウザからHTMLを表示するため、簡易Webサーバーを用意します。

`web-server.js`

```javascript
import http from "node:http";
import fs from "node:fs";
import path from "node:path";

const PORT = 5500;
const ROOT = process.cwd();

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8"
};

const server = http.createServer((req, res) => {
  const pathname = decodeURIComponent(
    new URL(req.url, `http://localhost:${PORT}`).pathname
  );

  const relativePath =
    pathname === "/" ? "index.html" : pathname.slice(1);

  const filePath = path.resolve(ROOT, relativePath);

  if (!filePath.startsWith(ROOT + path.sep)) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }

  fs.readFile(filePath, (error, data) => {
    if (error) {
      res.writeHead(404);
      res.end("Not Found");
      return;
    }

    const contentType =
      mimeTypes[path.extname(filePath)] || "application/octet-stream";

    res.writeHead(200, {
      "Content-Type": contentType
    });

    res.end(data);
  });
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`Web server: http://127.0.0.1:${PORT}`);
});
```

## 6. Mockサーバーを起動する

ターミナルを2つ用意します。

1つ目のターミナルでMockサーバーを起動します。

```bash
node mock-server.js
```

2つ目のターミナルでWebサーバーを起動します。

```bash
node web-server.js
```

ブラウザから次のURLを開きます。

```text
http://127.0.0.1:5500
```

画面からファイルを選択して送信すると、Mockサーバーからダミーの文字起こし結果が返る構成になります。

## 7. エラー処理もMockで確認する

開発時には正常系だけでなく、エラー時の動作確認も重要です。

例えば、次のようなケースをテストします。

| HTTPステータス | 想定する動作 |
|---|---|
| 200 | 正常終了 |
| 401 | 認証エラー。再試行しない |
| 429 | 最大3回まで再試行 |
| 503 | 再試行する |

再試行処理では、指数バックオフを使用します。

```javascript
function getBackoffSeconds(tries) {
  return Math.min(2 ** (tries - 1), 30);
}
```

待機時間は次のようになります。

| 試行回数 | 待機時間 |
|---|---:|
| 1回目 | 1秒 |
| 2回目 | 2秒 |
| 3回目 | 4秒 |

401のような認証エラーは、同じ条件で再試行しても成功する可能性が低いため、再試行対象から除外します。

## 8. テストを実行する

Node.jsの標準テスト機能を使えば、追加ライブラリなしでテストできます。

```bash
node --test
```

今回のMock DEV環境では、次のような項目をテスト対象にします。

- Mockサーバーが起動すること
- 正しいエンドポイントで応答すること
- 不正なAPIキーで401を返すこと
- 正常系でダミー結果が返ること
- 401では再試行しないこと
- 429や503では再試行すること

テストを自動化しておくことで、実装変更によるデグレードを確認できます。

## 9. Mock DEV環境を使うメリット

今回の構成により、次のようなメリットがあります。

- Azureのリソースを準備せずに開発できる
- API利用料金を気にせず画面を確認できる
- 認証エラーやサーバーエラーを再現できる
- ネットワークに依存せずテストできる
- フロントエンドとAPIの接続部分を独立して確認できる

特に、APIの応答が固定されているため、画面側の開発やエラー処理のテストを安定して実施できます。

## まとめ

今回は、Node.jsを使ってAzure Speech風のローカルMockサーバーを作成しました。

重要なのは、**本番APIに接続する部分と、ローカルMockに接続する部分を切り替えられる構成にすること**です。

最初からAzureの実環境に依存するのではなく、Mock環境で画面・通信・エラー処理を確認しておけば、開発効率とテストの再現性を高められます。

次のステップとして、実際のAzure Speech APIを接続する環境を別途用意し、Mock環境で確認したテスト項目を本番接続時にも実施できるようにするとよいでしょう。
