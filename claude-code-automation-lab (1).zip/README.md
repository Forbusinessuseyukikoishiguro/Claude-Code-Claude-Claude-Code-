# claude-code-automation-lab

Udemy講座「Claude Codeの拡張機能と /goal・フックで業務自動化する方法」の演習リポジトリです（うさうさ研修工房）。

題材は、前の講座で作った売上KPIダッシュボードです。ただし **3か所にバグを仕込んであり、`npm test` は4件失敗** します。これを Claude Code に「テストを書き換えずに」直させ、結果を Notion に記録する流れを、拡張機能・フック・`/goal` で自動化します。

## 中身

```
.claude/
  settings.json                 権限（permissions）とフックの設定
  settings.stopgate.example.json  Stop フック（確定的な完了ゲート）を足す例
  hooks/                        フックのスクリプト（Node.js・Windowsでも動く）
    block-dangerous.js          [PreToolUse/Bash] 危険なコマンドをブロック
    protect-files.js            [PreToolUse/Write・Edit] tests/・.env・CI設定などを保護
    post-edit-check.js          [PostToolUse] js/ を編集した直後に速いテストを実行
    stop-gate.js                [Stop] npm test が通るまで続行（上限回数つき）
    session-context.js          [SessionStart] プロジェクトのルールを文脈に入れる
    __tests__/hooks.test.js     フックと構成の単体テスト
  skills/
    fix-failing-tests/          失敗テストを「テストを書き換えず」に直す手順
    notion-test-recorder/       テスト結果をNotionに記録する（前の講座のスキル）
  agents/
    test-runner.md              テスト実行と要約の専用（書き込みツールなし）
    code-reviewer.md            読み取り専用のレビュー
  commands/
    fix-and-record.md           「直す→Notionに記録」を1コマンドで
    record-tests.md             テスト結果をNotionに記録
.mcp.json.example               Notion MCP の設定例（.mcp.json にして使う）
js/ css/ data/ index.html       題材のダッシュボード（バグ入り）
tests/                          ユニット・DOMテスト（変更禁止＝仕様）
solutions/js/                   答え合わせ用の修正済みファイル
tools/normalize_results.py      テスト結果を共通JSONにそろえる
docs/                           goals.md・hooks.md・security.md・exercises.md
```

## はじめかた（Windows / PowerShell）

```powershell
npm install
npm test            # 4件失敗するのが正常な出発点
npm run test:hooks  # フックの単体テスト（15件・Claude Code 不要）
claude              # このフォルダで起動し、信頼ダイアログを承認
```

章ごとの演習は `docs/exercises.md`、`/goal` の条件の書き方は `docs/goals.md` を見てください。

## 動作確認の状況（正直な一覧）

| 項目 | 状況 |
|---|---|
| バグ入りの状態で `npm test` | **確認済み**：62件中 4件失敗（3か所のバグ） |
| `solutions/js/` を当てた状態 | **確認済み**：62件すべて成功 |
| フックのスクリプト単体 | **確認済み**：`npm run test:hooks` 15件成功（終了コード・JSON出力・上限回数・標準入力が空の場合） |
| フック × 本物のテスト出力 | **確認済み**：失敗時はどのテストがなぜ失敗したかを要約して返し、成功時は何も返さない |
| `settings.json`・スキル・サブエージェントの形 | **確認済み**：JSONとして正しい、参照先が存在する、名前の一致、書き込み系ツールを持たないこと |
| **Claude Code 本体での動作** | **未確認**：この環境には Claude Code が無いため、設定の読み込み、フックの呼び出し、`/goal`、スキル・サブエージェントの検出、MCP 接続は実機で確認していません |
| Windows での実行 | **未確認**（Linux で確認） |

フックの仕様（標準入力のJSON・終了コード2でブロック・`decision:"block"` のJSON）と `/goal` の仕様は、公式ドキュメントおよび複数の解説で確認した内容に基づいています。**収録前に、実際の Claude Code で一通り動かして確認してください**（特に permissions のルールの書き方、フックのマッチャー、`/goal` の挙動）。
