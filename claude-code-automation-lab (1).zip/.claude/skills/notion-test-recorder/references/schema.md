# 共通JSONスキーマ

```json
{
  "run_id": "20261112-1000-a1b2c3d",
  "env": "local-win11",
  "commit": "a1b2c3d",
  "framework": "pytest",
  "executed_at": "2026-11-12T10:00:00+00:00",
  "summary": { "total": 4, "pass": 2, "fail": 1, "skip": 1 },
  "tests": [
    { "id": "test_calc.py::test_add", "name": "test_add", "result": "PASS", "duration_ms": 12, "error": null }
  ]
}
```

## ルール
- `id`：実行内で一意。更新判定のキーは「`run_id` ＋ `id`」。
- `result`：PASS / FAIL / SKIP の3値のみ。
- `error`：FAIL のときだけ。先頭500文字まで、メール・トークン・ホームパスはマスク済み。
- 時刻は ISO 8601。Notion の「実行日時」に入れるときは日付＋時刻で。

## 変換の対応表

| 項目 | pytest（pytest-json-report） | Jest / Vitest（--json） | Playwright（json レポーター） |
|---|---|---|---|
| ID | `nodeid` | ファイル名 ＋ `::` ＋ `fullName` | ファイル名 ＋ `::` ＋ describe 階層とテスト名 ＋ `[プロジェクト名]` |
| 名前 | `nodeid` の最後の部分 | `title` | テスト名 |
| 結果 | `outcome`：passed/xpassed→PASS、failed/error→FAIL、他→SKIP | `status`：passed→PASS、failed→FAIL、pending/todo→SKIP | `status`：expected/flaky→PASS、unexpected→FAIL、skipped→SKIP |
| 所要時間 | setup＋call＋teardown の秒 → ms | `duration`（ms） | 全リトライの `duration` の合計（ms） |
| 失敗ログ | `longrepr`（無ければ `crash.message`） | `failureMessages` を結合 | 最後の試行の `error.message`（色コードは除去） |

※ 出力形式はバージョンで変わる可能性がある。想定と違うときは、実物を読んで対応を直す。
