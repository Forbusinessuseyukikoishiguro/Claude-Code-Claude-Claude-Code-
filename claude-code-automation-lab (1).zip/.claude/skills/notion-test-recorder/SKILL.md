---
name: notion-test-recorder
description: pytest / Jest / Vitest / Playwright のテスト結果（JSON）を共通スキーマに正規化し、Notion MCP 経由で「テスト結果」データベースへ重複なく登録・更新するスキル。「テスト結果をNotionに記録して」「results.json をNotionに登録」「テスト結果を転記」「Notionに試験結果を書き込んで」「テスト結果DBを作って」「テスト結果のサマリページを作って」といった依頼、または pytest・Jest・Vitest・Playwright・結果JSON・Notion が一緒に出てきたら、スキル名が出なくても必ずこのスキルを使うこと。Windows（PowerShell）/ VSCode / Claude Code を想定。
---

# Notionテスト結果レコーダー

テスト結果を「共通JSON」にそろえ、Notion の「テスト結果」DB に **重複させず** 登録する。
人の転記作業をなくし、「いつ・どの環境・どのコミットで・何が落ちたか」を検索できる状態にするのが目的。

## 0. 前提チェック（毎回、最初に）

1. Notion MCP が接続済みか確認する（Notion のツールが使えるか）。使えなければ、ユーザーに次を案内して止まる。
   - Claude Code：`claude mcp add --transport http --scope user notion https://mcp.notion.com/mcp` を実行し、Claude Code 内で `/mcp` から認証する。
   - Claude（チャット）：コネクタ設定から Notion を接続する。
   - 手順や画面は更新されるので、迷ったら公式ドキュメントで最新を確認するよう伝える。
2. 認証先のワークスペース名をユーザーに確認してもらう（業務用と個人用の取り違え防止）。
3. 触ってよいのは「テスト結果」DB（とそのサマリページ）だけ。他のページは検索・読み取り・変更をしない。

## 1. 入力を決める

- `results.json`（pytest-json-report、`jest --json --outputFile`、Vitest の JSON レポーター、Playwright の JSON レポーター）があればそれを使う。
- 無ければ、ユーザーの言語に合わせて実行方法を案内する（実行するかは確認する）。
  - pytest：`pytest --json-report --json-report-file=results.json`（要 `pip install pytest-json-report`）
  - Jest：`npx jest --json --outputFile=results.json`
  - Vitest：`npx vitest run --reporter=json --outputFile=results.json`（形式は Jest と同じ。Notion の「フレームワーク」には `--label Vitest` で記録する）
  - Playwright：`npx playwright test --reporter=json`（出力先は設定で指定）
- 出力形式はバージョンで変わることがある。**正規化前に実物を一度開いて**、想定と違えばユーザーに伝える。

## 2. 共通スキーマに正規化する

```powershell
python scripts/normalize_results.py results.json --env local-win11 --out results.normalized.json
```

- Windows で `python` が無ければ `py` を使う。文字コードは UTF-8。
- `--env`（実行環境名）、`--commit`、`--run-id` は必要に応じて指定。未指定なら Git のコミットと日時から自動生成。
- スクリプトは、失敗ログの先頭500文字への切り詰めと、メール・トークン・ホームディレクトリのマスクを行う。
- 共通スキーマの詳細は `references/schema.md`。

## 3. Notion の「テスト結果」DB を特定する

1. Notion で「テスト結果」DB を検索する。
2. 見つからない場合は、**作成してよいかユーザーに確認**してから作る。構造は `references/notion-db-template.md` の通り（プロパティ名・型を一字一句そろえる）。
3. 見つかったら、プロパティ一覧を取得し、`references/notion-db-template.md` の名前・型と一致するか確認する。ずれていれば、勝手に直さず、差分をユーザーに提示して指示を待つ。

## 4. 登録する（更新または追加）

キーは **「実行ID ＋ テストID」**。

1. まず1件だけ登録して、Notion 上の結果をユーザーに確認してもらう（初回のみ。信頼できる運用になったら省略可）。
2. 各テストについて、「実行ID」と「テストID」が同じ行を検索する。
   - あれば **更新**、なければ **新規追加**。
3. 設定する値：テスト名、テストID、実行ID、結果（PASS/FAIL/SKIP）、実行日時、環境、コミット、所要時間(ms)、失敗ログ（FAIL のみ、先頭500文字）、フレームワーク。
4. 書き込みに失敗したテストは、最大2回までリトライし、それでも失敗なら失敗一覧に積んで先へ進む。
5. `results.json` と `results.normalized.json` は **削除しない**（Notion が失敗しても結果をローカルに残すため）。

## 5. サマリページ（任意）

ユーザーが希望したら、`templates/run-page-template.md` の形で、1回の実行を1ページにまとめる。希望がなければ作らない。

## 6. 報告する

最後に、次の形式で簡潔に報告する。

```
登録結果：追加 N 件 ／ 更新 N 件 ／ 失敗 N 件
テスト件数：合計 N（PASS N ／ FAIL N ／ SKIP N）← Notion上の件数と一致を確認
FAIL：テストID の一覧（失敗ログ本文は貼らない）
未登録：（あればテストIDと理由）
```

件数が合わない場合は「合っている」と言わず、差分を示してユーザーの確認を求める。

## 守るルール

- 最小権限：対象DB以外は触らない。ワークスペース全体を検索して内容を読み出さない。
- 秘密情報：トークン・パスワード・個人情報・顧客データを Notion に書かない。マスクされていない疑いがあれば、書く前に止めてユーザーに確認する。
- DB の構造（プロパティの追加・削除・型変更）は、ユーザーの明示的な指示があるときだけ行う。
- 既存の行を削除しない。更新のみ。
- 社内規程で Notion への保存が許されない情報区分があるかもしれない。迷ったら保存せず、ユーザーに確認する。

## つまずき早見表

| 症状 | 原因の候補 | 対応 |
|---|---|---|
| Notion のツールが無い／`/mcp` が空 | 登録がフォルダ限定 | `--scope user` で登録し直す |
| DB が見つからない | 許可範囲が狭い | 許可ページに「テスト結果」DB（またはその親ページ）を追加 |
| 書き込みが失敗する | プロパティ名・型の不一致 | `references/notion-db-template.md` と見比べる |
| 行が重複する | 更新条件が曖昧 | 「実行ID＋テストID」で必ず検索してから書く |
| 文字化け | 文字コード | UTF-8 に統一 |

## 同梱ファイル

- `scripts/normalize_results.py`：pytest / Jest / Vitest / Playwright の結果を共通スキーマに変換（マスク・切り詰め付き）
- `references/schema.md`：共通JSONスキーマと、pytest・Jest との対応表
- `references/example.normalized.json`：正規化後JSONの実例（pytest の実行結果から生成）
- `references/notion-db-template.md`：Notion「テスト結果」DB のプロパティ定義と、DB作成プロンプト
- `templates/test-results-template.csv`：Notion に CSV インポートして DB のひな形を作るためのファイル
- `templates/run-page-template.md`：1回の実行をまとめるサマリページのひな形
- `templates/record-tests.md`：Claude Code のスラッシュコマンド用（`.claude/commands/record-tests.md` に置く）
