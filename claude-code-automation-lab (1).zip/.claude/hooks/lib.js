// フック共通の小さな道具。標準入力のJSONを読む・パスを正規化する・ANSI色を除く
import { readFileSync } from 'node:fs';

/** 標準入力（フックにはイベントのJSONが渡される）を読んで、オブジェクトにする */
export function readInput() {
  try {
    const text = readFileSync(0, 'utf8');
    return text.trim() ? JSON.parse(text) : {};
  } catch {
    return {};
  }
}

/** Windows の \ を / にそろえ、プロジェクト直下からの相対パスにする */
export function relPath(filePath, cwd = process.cwd()) {
  const norm = String(filePath ?? '').replace(/\\/g, '/');
  const base = String(cwd).replace(/\\/g, '/').replace(/\/$/, '');
  return norm.startsWith(base + '/') ? norm.slice(base.length + 1) : norm.replace(/^\.\//, '');
}

export const stripAnsi = (s) => String(s ?? '').replace(/\x1b\[[0-9;]*[A-Za-z]/g, '');

/** 長いログを先頭だけにする（Claude に返すログは短く） */
export const clip = (s, n = 800) => {
  const t = stripAnsi(s).trim();
  return t.length > n ? t.slice(0, n) + '…（省略）' : t;
};

/** テストの出力から「どれが・なぜ失敗したか」の行だけを抜き出す。見つからなければ先頭を使う */
export function summarizeFailures(text, maxLines = 25) {
  const lines = stripAnsi(text).split(/\r?\n/);
  const hit = lines.filter((l) => /(FAIL|×|AssertionError|Expected|Received|expected|Error:)/.test(l)).map((l) => l.trim()).filter(Boolean);
  return hit.length ? hit.slice(0, maxLines).join('\n') : clip(text);
}
