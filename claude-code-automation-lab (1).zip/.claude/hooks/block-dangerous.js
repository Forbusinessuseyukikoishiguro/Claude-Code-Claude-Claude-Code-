// PreToolUse（Bash）：危険なコマンドを実行前にブロックする
// 終了コード 2 = ブロック（stderr の内容が理由として Claude に返る）。終了コード 0 = 何もしない（承認ではない）
import { readInput } from './lib.js';

const RULES = [
  [/\brm\s+(-[a-z]*r[a-z]*f|-[a-z]*f[a-z]*r|--recursive\b[^|;&]*--force|--force\b[^|;&]*--recursive)/i, 'rm -rf（再帰的な強制削除）'],
  [/Remove-Item\b[^|;&]*-Recurse[^|;&]*-Force|Remove-Item\b[^|;&]*-Force[^|;&]*-Recurse/i, 'Remove-Item -Recurse -Force（PowerShell の強制削除）'],
  [/\bgit\s+push\b[^|;&]*(--force\b|--force-with-lease\b|\s-f\b)/i, 'git push --force（履歴の上書き）'],
  [/\bgit\s+reset\s+--hard\b/i, 'git reset --hard（未コミットの変更が消える）'],
  [/\b(curl|wget)\b[^|;&]*\|\s*(sh|bash|zsh|pwsh|powershell)\b/i, 'ダウンロードしたスクリプトの即時実行（curl | sh）'],
  [/\bnpm\s+publish\b/i, 'npm publish（外部への公開）'],
  [/\b(cat|type|Get-Content|more|less|head|tail)\b[^|;&]*\.env\b/i, '.env（秘密情報）の読み取り'],
];

const input = readInput();
const command = input.tool_input?.command ?? '';

for (const [pattern, label] of RULES) {
  if (pattern.test(command)) {
    console.error(`ブロックしました：${label}。別の方法（安全なコマンド）で実現するか、人に確認してください。`);
    process.exit(2);
  }
}
process.exit(0);
