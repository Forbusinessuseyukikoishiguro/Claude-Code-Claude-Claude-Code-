// PreToolUse（Write / Edit）：守るべきファイルへの書き込みをブロックする
// 狙い：「テストを書き換えて、テストを通した」というズルを防ぐ。秘密情報とCI設定も守る
import { readFileSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readInput, relPath } from './lib.js';

const here = dirname(fileURLToPath(import.meta.url));
const configPath = join(here, 'protect.config.json');
const config = existsSync(configPath) ? JSON.parse(readFileSync(configPath, 'utf8')) : { protected: [] };

const input = readInput();
const file = relPath(input.tool_input?.file_path, input.cwd ?? process.cwd());

for (const { pattern, reason } of config.protected) {
  if (new RegExp(pattern).test(file)) {
    console.error(`ブロックしました：${file} は書き換え禁止です（${reason}）。ソースコード側を直してください。`);
    process.exit(2);
  }
}
process.exit(0);
