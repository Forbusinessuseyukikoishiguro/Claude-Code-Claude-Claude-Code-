// Stop（確定的な完了ゲート）：npm test が通るまで、Claude に作業を続けさせる
// /goal（モデルが判定）と違い、ここは「スクリプトが判定」する＝毎回同じ結果になる
// 無限ループ防止：連続でブロックする回数に上限を設ける（既定3回）
import { spawnSync } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { readInput, summarizeFailures } from './lib.js';

const input = readInput();
const cwd = input.cwd ?? process.cwd();
const max = Number(process.env.STOP_GATE_MAX ?? 3);
const counter = join(tmpdir(), `claude-stop-gate-${String(input.session_id ?? 'default').replace(/[^\w-]/g, '')}.count`);

const cmd = process.env.STOP_GATE_CMD || 'npm test --silent';
const r = spawnSync(cmd, { shell: true, cwd, encoding: 'utf8', timeout: 120_000 });

if (r.status === 0) {
  if (existsSync(counter)) rmSync(counter);
  process.exit(0); // テストが通っているので、終わってよい
}

const count = (existsSync(counter) ? Number(readFileSync(counter, 'utf8')) : 0) + 1;
if (count > max) {
  rmSync(counter, { force: true });
  process.stderr.write(`テストがまだ失敗していますが、ブロックの上限（${max}回）に達したため止めます。人が確認してください。\n`);
  process.exit(0);
}
writeFileSync(counter, String(count));

const reason = `npm test がまだ失敗しています（${count}/${max}回目）。テストファイルは変更せず、実装を直してください。\n` + summarizeFailures((r.stdout ?? '') + (r.stderr ?? ''));
process.stdout.write(JSON.stringify({ decision: 'block', reason }));
process.exit(0);
