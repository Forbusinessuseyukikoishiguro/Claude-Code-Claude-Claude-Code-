// PostToolUse（Write / Edit）：js/ を編集した直後に、速いテストを走らせて、失敗を Claude に返す
// PostToolUse は「ブロック」できない（もう実行済み）。代わりに decision:"block" + reason を JSON で返すと、理由が Claude に伝わる
import { spawnSync } from 'node:child_process';
import { readInput, relPath, summarizeFailures } from './lib.js';

const input = readInput();
const file = relPath(input.tool_input?.file_path, input.cwd ?? process.cwd());

if (!/^js\/.+\.js$/.test(file)) process.exit(0); // js/ 以外は何もしない

const cmd = process.env.POST_EDIT_CMD || 'npx vitest run tests/unit --reporter=dot';
const r = spawnSync(cmd, { shell: true, cwd: input.cwd ?? process.cwd(), encoding: 'utf8', timeout: 60_000 });

if (r.status === 0) process.exit(0);

const detail = r.error ? `（実行エラー：${r.error.message}）` : summarizeFailures((r.stdout ?? '') + (r.stderr ?? ''));
const reason = `${file} を編集した直後のユニットテストが失敗しました。\n` + detail;
process.stdout.write(JSON.stringify({ decision: 'block', reason }));
process.exit(0);
