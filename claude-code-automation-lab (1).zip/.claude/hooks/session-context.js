// SessionStart：セッション開始時に、プロジェクトの約束事を Claude の文脈に入れる（標準出力がそのまま文脈になる）
console.log([
  '【プロジェクトのルール】',
  '- テストは npm test。tests/ 配下は変更しない（フックでブロックされる）',
  '- 完了の定義：npm test が終了コード0、かつ tests/ に変更がないこと',
  '- 危険なコマンド（rm -rf・git push --force など）は実行しない',
].join('\n'));
