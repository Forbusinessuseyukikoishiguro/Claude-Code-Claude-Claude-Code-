---
description: テスト結果（results.json）をNotionの「テスト結果」DBに記録する
---

notion-test-recorder スキルの手順で、`$ARGUMENTS`（未指定なら `results.json`）の結果を Notion の「テスト結果」DB に記録してください。

- 正規化 → 実行ID＋テストIDで更新／追加 → 件数を報告
- 触るのは「テスト結果」DBだけ。秘密情報・個人情報は書かない
- 最後に「追加N件／更新N件／失敗N件」と、PASS/FAIL/SKIP の件数突合を報告
