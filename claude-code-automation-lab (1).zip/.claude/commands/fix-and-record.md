---
description: テストが通るまで実装を直し、結果をNotionの「テスト結果」DBに記録する
---

次の順で進めてください。

1. fix-failing-tests スキルの手順で、`npm test` が通るまで実装を直す（tests/ は変更しない）。
2. `npm run test:json` で結果を JSON に出し、notion-test-recorder スキルの手順で、Notion の「テスト結果」DB に記録する。
3. 最後に、直した内容・`npm test` の最終結果・Notion への登録件数（追加・更新・失敗）を報告する。

追加の指示：$ARGUMENTS
