# 演習の手順（章ごと）

準備：`npm install` → `npm test`（**4件失敗**が正常な出発点）。`claude` をこのフォルダで起動し、信頼ダイアログを承認する。

| 章 | 演習 | 確認すること |
|---|---|---|
| 1 | `.claude/` の中身を読み、「CLAUDE.md・コマンド・スキル・サブエージェント・フック・MCP」のどれに当たるか分類する | 各拡張機能の使いどころ |
| 2 | `.claude/settings.json` の permissions を読み、`.env` の読み取りが deny になっていることを確認する | 最小権限 |
| 3 | `.claude/skills/fix-failing-tests/SKILL.md` を読み、「テストを書き換えない」原則を自分の言葉で説明する。`/fix-and-record` コマンドの中身を読む | 手順の資産化 |
| 4 | `test-runner` サブエージェントに「テストを回して要約して」と頼む。`.mcp.json.example` を `.mcp.json` にして Notion MCP を接続する | 役割分担・MCP |
| 橋渡し | `/goal` を最小の条件で試す：`/goal npm test の失敗件数を表示して、4件であることを確認する（1ターンで終わる）` | /goal の基本の動き |
| 5 | `tests/unit/metrics.test.js` を編集させてみる → ブロックされることを確認。`npm run test:hooks` を実行し、フックを単体で確認 | PreToolUse・終了コード2 |
| 6 | `docs/goals.md` の演習用の条件で `/goal` を実行し、4件の失敗を直させる | 良い条件の4要素 |
| 7 | `.claude/settings.stopgate.example.json` の Stop を足し、同じ演習を再実行して、`/goal` との違いを観察する | 確定的な判定との併用 |
| 8 | `/fix-and-record` で「直す→Notionに記録」まで通す。`docs/security.md` のチェックリストでフックをレビュー | 一気通貫・安全 |

## 失敗を試す（第8章の山場）
- 曖昧な条件（「テストをいい感じに直して」）で `/goal` を実行し、終わらない・暴走する様子を観察する（**必ず上限ターンを付けて**試す）。
- 条件に上限ターンを入れ忘れた場合の挙動を、少ないターン数で確認する。

## 答え合わせ
`solutions/js/` に、修正後の `data.js` と `metrics.js` が入っている。直し方の確認用（Claude に直させた結果と比べる）。
```powershell
# 4件の失敗の原因（3か所）
#  js/metrics.js : 終了日を含めていない（>= を > に）
#  js/metrics.js : 0件の平均単価が 0 になっている（null にする）
#  js/data.js    : 空欄の金額を受け入れている（空欄はエラー行にする）
```
