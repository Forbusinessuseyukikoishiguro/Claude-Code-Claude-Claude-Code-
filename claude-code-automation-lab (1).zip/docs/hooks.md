# フックの早見表（第5章）

## 置き場所（3か所）
| ファイル | 範囲 |
|---|---|
| `~/.claude/settings.json` | 自分の全プロジェクト |
| `.claude/settings.json` | このリポジトリ（チームで共有・コミットする） |
| `.claude/settings.local.json` | このリポジトリ（自分だけ・コミットしない） |

## よく使うイベント
| イベント | いつ動く | ブロックできるか | このリポジトリの例 |
|---|---|---|---|
| SessionStart | セッション開始・再開 | できない（標準出力が文脈になる） | `session-context.js` |
| PreToolUse | ツール実行の前 | できる（終了コード2） | `block-dangerous.js`・`protect-files.js` |
| PostToolUse | ツール実行の後 | できない（`decision:"block"` のJSONで理由を返す） | `post-edit-check.js` |
| Stop | Claude が回答を終えるとき | できる（`decision:"block"` で続行させる） | `stop-gate.js`（例の設定で有効化） |

イベントは他にも多数ある（UserPromptSubmit、Notification、SubagentStop など）。全一覧は公式のフックのリファレンスを見ること。

## 入出力のルール
- 入力：イベントの内容が **標準入力にJSON**で渡される（`tool_name`、`tool_input`、`cwd`、`session_id` など）。
- **終了コード0**：成功。何もブロックしない。
- **終了コード2**：ブロック（ブロックできるイベントのみ）。標準エラー出力の内容が理由として Claude に返る。
- **終了コード1などその他**：ブロックにならない（ユーザーにエラーが表示されるだけ）。→ ブロックしたいのに終了コード1にしてしまう間違いが多い。
- PreToolUse で終了コード0を返しても、**承認にはならない**。通常の許可の確認はそのまま行われる。
- JSONで制御する場合は、終了コード0で標準出力にJSONを出す（`decision:"block"` と `reason`）。「終了コード2」と「JSON」は、1つのフックでどちらか一方にする。

## 書くときの注意
- Windows でも動くよう、フックは **Node.js** で書く（bash が無い環境がある）。
- 標準入力が空・壊れていても落ちないようにする（防御的に書く）。
- 重い処理を毎回走らせない（PostToolUse は速いテストだけ）。タイムアウトを付ける。
- Stop フックには **必ず上限回数**を付ける（無限ループの防止）。`stop-gate.js` は既定で3回。
- 作業ディレクトリが変わる場合に備え、スクリプトのパスは `$CLAUDE_PROJECT_DIR` を使う方法もある（環境による。収録前に確認すること）。

## このリポジトリのフックを単体でテストする
```powershell
npm run test:hooks
```
フックは「標準入力のJSON → 終了コードと出力」なので、Claude Code を起動しなくてもテストできる。
