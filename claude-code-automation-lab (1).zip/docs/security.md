# 安全・コスト・運用（第8章）

## フックは「任意のコマンドを実行できる設定」
- フックは、あなたの権限でコマンドを実行する。**他人のリポジトリの `.claude/settings.json` を、中身を読まずに信頼しない**。
- リポジトリにコミットされたフックは、非対話の実行（`claude -p` など）でも確認なしに動く場合がある。チームの設定は、PRで必ずレビューする。
- 設定ファイルとフック自体を、Claude に書き換えさせない（`protect.config.json` で `.claude/settings` と `.claude/hooks` を保護）。

## 守りの重ね方
| 層 | 手段 | このリポジトリ |
|---|---|---|
| 許可 | permissions の allow / deny | `.claude/settings.json` |
| 実行前の検査 | PreToolUse フック | 危険なコマンド・保護ファイル |
| 実行後の検査 | PostToolUse フック | 編集直後のテスト |
| 完了の判定 | Stop フック・`/goal` | 上限付きのゲート |
| 人の確認 | PRレビュー・`git diff` | `tests/` に変更がないこと |

## コスト
- `/goal` は、ターンごとに評価のモデルも呼ぶ。条件が曖昧だと、長く回ってトークンを使う。
- **上限ターンを条件に入れる**。回し始めたら、状態を `/goal` で確認し、想定より長いときは `/goal clear` か Ctrl+C で止める。

## 止め方
| 状況 | 方法 |
|---|---|
| `/goal` を止めたい | `/goal clear`（または `/clear`） |
| 非対話の実行を止めたい | Ctrl+C |
| フックが暴走している | 設定の hooks を外す／`disableAllHooks` |
| Stop ゲートが止まらない | 上限回数に達すると自動で止まる（`STOP_GATE_MAX`） |

## 秘密情報
- `.env`・トークンを Claude に読ませない（deny ルールと `block-dangerous.js`）。
- Notion に書く失敗ログは、マスクしてから（`tools/normalize_results.py` がメール・トークン・ホームパスをマスク）。
