"""spec_ac.csv と results.json を突き合わせ、仕様照合表（Markdown）を出す。
試験が無いACは『未実施』と出す（合格と書かない）。"""
import csv, json
res = json.load(open("results.json", encoding="utf-8"))
out = ["| AC | 要件 | 結果 | 受け入れ基準 |", "|---|---|---|---|"]
for r in csv.DictReader(open("docs/spec_ac.csv", encoding="utf-8")):
    out.append(f"| {r['AC']} | {r['要件']} | {res.get(r['AC'], '未実施')} | {r['受け入れ基準（入力→結果）']} |")
open("trace.md", "w", encoding="utf-8").write("\n".join(out) + "\n")
print("\n".join(out))
