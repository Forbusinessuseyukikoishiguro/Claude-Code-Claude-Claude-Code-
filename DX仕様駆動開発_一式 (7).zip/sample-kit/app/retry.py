"""模倣API向けの失敗分類と再試行（講座用の小さな例）。FR-02 / FR-03 に対応。"""
import time

RETRYABLE = {"rate_limit", "server", "network", "timeout"}


def classify(status):
    """HTTPステータス（または通信状態の文字列）を、失敗の種類に分類する。 FR-02"""
    if status == 401:
        return "auth"
    if status == 429:
        return "rate_limit"
    if isinstance(status, int) and 500 <= status <= 599:
        return "server"
    if status in ("network", "timeout"):
        return status
    if status == 200:
        return "ok"
    return "unknown"


def should_retry(kind):
    """再試行してよい種類だけ True。 FR-03"""
    return kind in RETRYABLE


def send_with_retry(send, max_tries=3, sleep=time.sleep):
    """send() は status を返す関数。試行回数と最後の種類を返す。 FR-03"""
    tries, kind = 0, "unknown"
    while tries < max_tries:
        tries += 1
        kind = classify(send())
        if not should_retry(kind):
            break
        if tries < max_tries:
            sleep(0.0 if sleep is not time.sleep else 2 ** (tries - 1))
    return {"tries": tries, "kind": kind}
