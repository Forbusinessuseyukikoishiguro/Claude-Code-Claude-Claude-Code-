"""試験名の先頭に受け入れ基準の番号（AC_xx）を付ける。"""
import unittest
from app.retry import classify, should_retry, send_with_retry

nosleep = lambda s: None


class Contract(unittest.TestCase):
    def test_AC_01_401_is_auth_and_not_retried(self):
        calls = []
        r = send_with_retry(lambda: calls.append(1) or 401, sleep=nosleep)
        self.assertEqual(r, {"tries": 1, "kind": "auth"})

    def test_AC_02_429_stops_at_3_tries(self):
        r = send_with_retry(lambda: 429, sleep=nosleep)
        self.assertEqual(r, {"tries": 3, "kind": "rate_limit"})

    def test_AC_03_5xx_is_retryable_and_recovers(self):
        seq = iter([503, 200])
        r = send_with_retry(lambda: next(seq), sleep=nosleep)
        self.assertEqual(r, {"tries": 2, "kind": "ok"})

    def test_AC_04_unexpected_status_is_not_retried(self):
        self.assertFalse(should_retry(classify(418)))
