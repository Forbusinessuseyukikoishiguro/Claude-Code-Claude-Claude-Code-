"""unittest を実行し、AC番号つきの結果を results.json に書く。"""
import json, os, re, sys, unittest

sys.path.insert(0, os.getcwd())


def walk(s):
    for t in s:
        if isinstance(t, unittest.TestSuite):
            yield from walk(t)
        else:
            yield t


suite = unittest.TestLoader().discover("tests")
tests = list(walk(suite))          # 実行前に控える（実行後は中身が解放されるため）
result = unittest.TestResult()
suite.run(result)
failed = {t.id() for t, _ in result.failures + result.errors}

rows = {}
for t in tests:
    m = re.search(r"test_(AC_\d+)", t.id())
    if not m:
        continue
    ac = m.group(1).replace("_", "-")
    if t.id() in failed:
        rows[ac] = "不合格"          # 同じACに複数試験があれば、1件でも不合格なら不合格
    elif rows.get(ac) != "不合格":
        rows[ac] = "合格"

json.dump(rows, open("results.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print(f"実行 {result.testsRun} 件 / 失敗 {len(result.failures)} / エラー {len(result.errors)}")
sys.exit(1 if (result.failures or result.errors) else 0)
