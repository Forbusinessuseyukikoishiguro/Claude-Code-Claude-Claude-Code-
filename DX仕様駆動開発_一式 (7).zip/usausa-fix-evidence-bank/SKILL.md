---
name: usausa-fix-evidence-bank
description: 改修・回帰試験・デバッグ・コードレビュー・試験計画の方針の根拠を、公式・査読済み論文・規格に分けて、確認状況と「言えること／言えないこと」つきで示す根拠バンク。「根拠は」「公式は」「査読済み論文は」で使う。
---

# 根拠バンク（改修・回帰試験・手動デバッグ）

usausa-manual-fix-regression と usausa-manual-debug-playbook の方針の根拠を、正直に示すためのバンク。確認日：2026-11-14。

## 使い方の原則

1. 根拠は3種に分けて書く：公式（事実）／査読済み論文（知見）／講師の整理（解釈）
2. 論文は「何を調べ、何が分かったとされるか」と「言えないこと」をセットで書く。論文の結果を、別の場面にそのまま当てはめない
3. 確認していないものは「未確認」と書く。記憶から書誌情報（著者・年・巻号・DOI）を足さない
4. 新しい出典を加えるときは、WebSearchで出典のURLを出し、そのURLをWebFetchで読み、書誌情報と要旨を確かめてから、確認状況を書く。公式サイトを直接取得して拒否されたら、同じ取得を繰り返さず、検索で表示された別のURL（マニュアルページ等）で取り直す
5. 規格は「参照点」であり、準拠・適合の主張はしない
6. 「確認した範囲」を超える主張（効果の大きさ、一般化、数値）はしない

## A. 公式（事実）

| 論点 | 公式の記述（要約） | 出典 | 確認 |
|---|---|---|---|
| diffの検査 | git apply --check：適用せず、適用可能かを確認 | Gitマニュアル git-apply（https://man.archlinux.org/man/git-apply.1.en） | 読了（2026-11-14）。gitの公式サイトは取得できず、マニュアルページで確認 |
| 変更統計 | --stat：適用せず変更統計を出す | 同上 | 同上 |
| 差し戻し | --reverse（-R）：逆向きに適用 | 同上 | 同上 |
| 全部か無か | 一部のハンクが適用できないとき、既定では全体が失敗し、作業ツリーは変更されない。適用できる部分だけは --reject（できなかった部分は .rej） | 同上 | 同上 |
| 版の二分探索 | git bisect：bad と good を指定し、中間の版を調べて半分ずつ絞る。run の終了コード：0＝good、1〜127（125を除く）＝bad、125＝スキップ | Gitマニュアル git-bisect（https://man7.org/linux/man-pages/./man1/git-bisect.1.html） | 読了（2026-11-14） |
| unittest の探索 | discover：-s 開始ディレクトリ、-t トップレベル、-p パターン（既定 test*.py）、-v 詳細。名前が test で始まるメソッドが試験 | Python公式 unittest（https://docs.python.org/3.13/library/unittest.html） | 読了（2026-11-14） |
| skip と expectedFailure | skip系は実行されない。expectedFailure は失敗すると成功扱い、成功すると失敗扱い | 同上 | 同上 |
| subTest | 複数の入力を1つの試験内で区別して確かめる。失敗しても後続の反復は実行され、パラメータ付きで報告される | 同上 | 同上 |
| CLAUDE.md の性質 | 文脈として読み込まれ、強制ではない | https://code.claude.com/docs/en/memory | 読了（2026-11-14） |
| 権限の評価順 | deny→ask→allow | https://code.claude.com/docs/en/permissions | 読了（2026-11-14） |
| フック | LLMの判断に頼らず決まった動きを実行。PreToolUseで編集を止める例（終了コード2） | https://code.claude.com/docs/en/hooks-guide | 読了（2026-11-14） |
| GNU diff／patch | 実行で動作を確認（`diff -u`、`patch --dry-run`、`-R`）。公式マニュアルは未読 | － | 実行のみ |

## B. 査読済み論文

| 論点 | 出典 | 確認した内容 | 言えること | 言えないこと |
|---|---|---|---|---|
| 回帰試験と選択技法 | Rothermel, G. & Harrold, M. J. (1996). Analyzing regression test selection techniques. IEEE Transactions on Software Engineering, 22(8). | 要旨を確認。回帰試験は、変更が悪影響を及ぼしていないことを示すために必要だが費用のかかる保守作業。選択技法は既存の試験を再利用する。技法は目標が異なり比較が難しいため、評価の枠組みを示す | 回帰試験の目的と、技法の目標の違いを意識して選ぶ根拠。影響範囲の試験を選ぶ考え方の背景 | 本Skillの「3段」運用が有効だという証拠。数値的な効果 |
| 最小化・選択・優先順位付け | Yoo, S. & Harman, M. (2012). Regression testing minimization, selection and prioritization: a survey. Software Testing, Verification and Reliability, 22(2), 67–120. | KAIST登録ページで書誌情報と要旨を確認（著者名は取得ページに無く、検索結果の表記による）。DOIは取得ページ上は 10.1002/stv.430、検索結果上は 10.1002/stvr.430（要確認）。3分野（最小化＝冗長の除去、選択＝変更に関係する試験の特定、優先順位付け＝早期に欠陥を見つける順）を調査し課題を論じるサーベイ | 試験計画の「削減」「選択」「順序」を分けて考える根拠 | 個々の技法の効果。手動運用での有効性。全文は未読 |
| 故障位置特定の技法 | Wong, W. E., Gao, R., Li, Y., Abreu, R., & Wotawa, F. (2016). A survey on software fault localization. IEEE Transactions on Software Engineering, 42(8), 707–740. DOI 10.1109/TSE.2016.2521368 | Crossrefの書誌情報のみ確認。要旨・本文は未読 | 故障位置特定の技法を扱うサーベイが存在すること | 個々の技法の内容・効果（未読） |
| 自動デバッグ技術と実際の開発者 | Parnin, C. & Orso, A. (2011). Are automated debugging techniques actually helping programmers? ISSTA 2011（国際ソフトウェアテスト・解析シンポジウム）. | 論文本文を確認。予備的な実験。疑わしさの順位付け（Tarantula）を提示した群と比較。全体では有意差なし。上位の成績者に限ると、1課題で有意に速かった。順位を変えても所要時間に有意な差はなし。参加者は順位順に確認せず、大きくジャンプした。故障文を見ても、時間の約61%を確認に費やした。限界：制限時間30分、学生、不慣れなコード、対象は各2件、予備的研究と明記 | 疑わしさの順位を鵜呑みにせず、依存をたどり、入力を変えて再実行する人の動きを前提に手順を作る根拠（慎重な表現で） | 手動デバッグ手順が優れている証拠。プロの開発者・大規模コードへの一般化 |
| 実務者のデバッグ過程 | Böhme, M., Soremekun, E. O., Chattopadhyay, S., Ugherughe, E., & Zeller, A. (2017). Where is the bug and how is it fixed? An experiment with practitioners. ESEC/FSE 2017. | 取得ページで題名・会議・年と要旨を確認（著者名は検索結果の表記）。27件の実際のエラーについて、プロの技術者による数百のデバッグ過程から、欠陥の場所・診断・パッチのデータセット（DBGBENCH）を作り、仮説の立案からパッチ提出までを分析 | デバッグを、仮説から修正までの過程として扱い、記録する考え方の背景 | 要旨にない個別の知見（例：所要時間の傾向）。本文は未読 |
| コードレビューの実際 | Bacchelli, A. & Bird, C. (2013). Expectations, outcomes, and challenges of modern code review. ICSE 2013. | 取得ページで要旨を確認。Microsoftのチームで観察・インタビュー・アンケート・レビューコメントの分類。主な動機は欠陥発見だが、実際には知識の移転・チームの認識・代替案の創出が多い。変更の理解がレビューの鍵 | 差分を小さく、目的・根拠・影響を付けて出すと、レビューが「変更の理解」を支える、という講師の解釈の背景 | AI生成の差分に対する効果。本Skillの提案カードの有効性 |
| AIアシスタントと安全性 | Perry, N., Srivastava, M., Kumar, D., & Boneh, D. (2023). Do users write more insecure code with AI assistants? arXiv:2211.03622（v3）. DOI 10.1145/3576915.3623157（ACM CCS 2023 と理解。arXivページに掲載先の記載なし） | arXivの要旨を確認。AIアシスタントを使えた参加者は、使えなかった参加者より有意に安全性の低いコードを書き、安全に書けたと思い込む傾向が強かった。AIへの信頼が低く、プロンプトを工夫した参加者ほど脆弱性が少なかった | AIの提案を無批判に採用せず、秘密・権限・安全性の観点で人がレビューする根拠 | 現在のモデルや他の課題でも同じ結果になること（研究は当時のモデル・特定の課題）。因果の大きさ |

## C. 規格（参照点）

| 規格 | 確認 | 使い方 |
|---|---|---|
| ISO/IEC/IEEE 29119-3:2021 Software and systems engineering — Software testing — Part 3: Test documentation | 規格が存在することを検索結果（販売ページ）で確認。ISOのページは取得できず、本文（試験計画の記載項目）は未読（有料） | 試験計画の項目の参照点。本Skillの項目は講師の整理で、規格への準拠は主張しない |

## D. 方針と根拠の対応

| Skillの方針 | 根拠の種類 | 出典 |
|---|---|---|
| diffを検査してから適用、失敗時は全体が失敗、差し戻しは -R | 公式＋実行確認 | A（git-apply）、実行 |
| 変更前の結果を保存し、前後を比べる | 講師の整理＋論文の背景 | B（Rothermel & Harrold：回帰試験の目的） |
| 試験の削除・縮小は理由と承認 | 講師の整理＋論文の背景 | B（Yoo & Harman：最小化は冗長の除去） |
| skip・expectedFailure の増加を見る | 公式 | A（unittest） |
| 疑わしい場所の順位を鵜呑みにしない | 論文（予備的） | B（Parnin & Orso） |
| 版の二分探索と、実行コマンドの事前確認 | 公式＋実行確認 | A（git-bisect）、実行（誤った版が出る落とし穴を再現） |
| 差分を小さく、目的・根拠付きで出す | 講師の整理＋論文の背景 | B（Bacchelli & Bird） |
| AIの提案を人が3観点でレビュー | 論文＋講師の整理 | B（Perry ら） |
| 最後は人が責任をもつ | 講師の整理 | （公式・論文の主張ではない） |

## 答え方（「根拠を教えて」と聞かれたとき）

1. 方針ごとに、公式／査読済み論文／講師の整理に分けて出す
2. 論文は、書誌情報・確認した内容・言えること・言えないことを書く
3. 確認状況（読了／要旨のみ／書誌情報のみ／未読）を必ず書く
4. 出典が見つからない・未確認のときは、「根拠は確認できていない」と言い、講師の整理として扱う
5. 公式は変わるので、確認日を添え、使う前に開いて確認するよう伝える

## 出力で必ず付けること

1. 確認したこと／未確認のこと
2. 次の一手（1つ）

## 検証範囲

1. 確認した（2026-11-14）：Gitマニュアル（git-apply・git-bisect）、Python公式unittest、Claude Code公式3ページ（memory・permissions・hooks-guide）の記述。Parnin & Orso は本文、Perry ら・Bacchelli & Bird・Böhme ら・Rothermel & Harrold・Yoo & Harman は要旨や登録ページ、Wong ら は書誌情報のみ
2. 実行で確認：diff・patch・git apply・git bisect run の動作
3. 未確認：各論文の全文（Parnin & Orso を除く）、ISO/IEC/IEEE 29119-3 の本文、Gitの公式サイト（git-scm.com）の記述、DOIの表記の差（Yoo & Harman）
