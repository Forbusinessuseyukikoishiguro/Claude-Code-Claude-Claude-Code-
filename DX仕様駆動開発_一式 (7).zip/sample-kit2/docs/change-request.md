# 変更依頼 CR-01（記入例）
1. 依頼：429が続くとき、待ち時間が長くなりすぎないようにしたい
2. 影響範囲（impact.py で確認）：NFR-01 / AC-05 / AC-06、app/retry.py、tests/test_contract.py
3. 仕様の更新：AC-05 を試験対象に、AC-06 を追加（docs/spec_ac.csv）。先に仕様を直した
4. 決定：待ち時間の上限は30秒（根拠は現場の運用要件。数値は例）。ADR-010 に記録
5. 試験：変更前の結果を before.json に保存→変更→run_tests.py→diff_results.py
6. 承認：確認者（人）__________ 日付__________  ※AIは承認できない
