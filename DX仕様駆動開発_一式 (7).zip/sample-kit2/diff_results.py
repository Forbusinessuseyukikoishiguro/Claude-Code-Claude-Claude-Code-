"""変更前後の results.json を比べ、退行・新規合格・新規不合格を出す。
使い方: python3 diff_results.py before.json results.json"""
import json, sys
a, b = (json.load(open(f, encoding="utf-8")) for f in sys.argv[1:3])
rank = {"未実施": 0, "合格": 1, "不合格": 2}
for ac in sorted(set(a) | set(b)):
    x, y = a.get(ac, "未実施"), b.get(ac, "未実施")
    if x == y:
        tag = "変化なし"
    elif x == "合格" and y == "不合格":
        tag = "退行（要対応）"
    elif x == "合格" and y == "未実施":
        tag = "消失（試験が消えた。要説明）"
    elif y == "合格":
        tag = "新規合格"
    elif y == "不合格":
        tag = "新規不合格"
    else:
        tag = "変化"
    print(f"{ac}: {x} → {y}  [{tag}]")
bad = any(a.get(k) == "合格" and b.get(k, "未実施") != "合格" for k in a) or any(v == "不合格" for v in b.values())
sys.exit(1 if bad else 0)
