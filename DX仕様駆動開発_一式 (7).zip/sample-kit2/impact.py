"""変更したいID（AC-xx / FR-xx / NFR-xx）から、関係する仕様行・コード・試験を逆引きする。
使い方: python3 impact.py AC-02   （影響範囲＝再実行すべきものの一覧）"""
import csv, os, re, sys
key = sys.argv[1]
spec = list(csv.DictReader(open("docs/spec_ac.csv", encoding="utf-8")))
ids = {key}
for r in spec:                      # AC を指定したら要件も、要件を指定したら属するACも対象に含める
    if key in (r["AC"], r["要件"]):
        ids |= {r["AC"], r["要件"]}
print("対象ID:", ", ".join(sorted(ids)))
print("仕様:")
for r in spec:
    if r["AC"] in ids or r["要件"] in ids:
        print(f"  {r['AC']} ({r['要件']}) {r['受け入れ基準（入力→結果）']}")
print("コード・試験:")
hits = 0
for d in ("app", "tests"):
    for f in sorted(os.listdir(d)):
        if not f.endswith(".py"):
            continue
        for n, line in enumerate(open(os.path.join(d, f), encoding="utf-8"), 1):
            norm = line.replace("AC_", "AC-")
            if any(re.search(re.escape(i) + r"(?!\d)", norm) for i in ids):
                print(f"  {d}/{f}:{n}: {line.strip()[:70]}"); hits += 1
if not hits:
    print("  （該当なし＝番号が付いていない。仕様と実装の対応を確認）")
