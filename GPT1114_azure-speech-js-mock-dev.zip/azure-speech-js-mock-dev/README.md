# Azure Speech JavaScript Local Mock DEV

**目的:** Azure Speech Fast Transcription風のHTTP契約をローカルで模倣し、UI・アップロード・再試行・結果表示を検証する。
**重要:** このプロジェクトはAzureへ接続しない。実際の音声認識はしない。返却文字列は固定のダミーである。

## 1. 必要環境
- Node.js 20以上（標準のfetch/FormData/AbortControllerを使用）
- VS Code
- npm installは不要。外部パッケージなし。

確認:
```bash
node -v
npm -v
```

## 2. 起動（VS Codeターミナルを2つ使う）
ターミナルA:
```bash
node mock-server.js
```
`Local Azure Speech mock: http://127.0.0.1:8787` と表示される。

ターミナルB:
```bash
node web-server.js
```
ブラウザで `http://127.0.0.1:5500` を開く。

音声ファイルを選び「Mockへ送信してテスト」。応答は固定文言。ファイル内容を音声認識しない。

## 3. 429再試行の確認
Mockサーバーを停止してから、ターミナルAで再起動:
```bash
# macOS / Linux
FAIL_EVERY=3 node mock-server.js
```
Windows PowerShell:
```powershell
$env:FAIL_EVERY=3
node mock-server.js
```
サーバー起動後の3回目ごとのPOSTに429を返す。リトライの動きはブラウザの実行ログで確認する。
注意: 3回目の要求で429になるため、単一の処理の3回リトライを必ず失敗させる設定ではない。要求累計に対するカウンターである。

任意設定:
```bash
MOCK_DELAY_MS=1200 PORT=8787 node mock-server.js
```
- `FAIL_EVERY`: 0なら429なし。NならN回ごとに429
- `MOCK_DELAY_MS`: 正常応答の遅延ms
- `PORT`: Mockポート
- `MAX_BODY_MB`: リクエスト上限MB
- `MOCK_KEY`: Mock用キー（本物のAzureキーではない）

## 4. テスト・照合
```bash
npm test
npm run trace
node impact.js NFR-01
node diff-results.js before.json results.json
```
`npm test` はNode標準テストランナーで試験し、AC別 `results.json` を出力する。
`npm run trace` は `trace.md` を生成する。
`impact.js` はIDの文字列一致による簡易逆引き。番号が書かれていない依存関係は検出できない。
`diff-results.js` は退行・消失・新規不合格があれば終了コード1。

## 5. AC一覧
- AC-01: 401は1回で停止
- AC-02: 429は最大3回
- AC-03: 503→200は2回目で成功
- AC-04: 418は再試行しない
- AC-05: 1,2,4秒の指数バックオフ
- AC-06: 30秒上限
- AC-07: multipart POSTでMock JSON
- AC-08: 誤キーは401、DEV接続先はloopback
- AC-09: 不正ルート・メソッド・Content-Type拒否

## 6. セキュリティ・注意
- Mock ServerとWeb Serverは127.0.0.1にのみbindする。
- ブラウザからアクセスできるキーはMock専用の `mock-key` のみ。
- 本物のAzureキーを `config.js` やブラウザへ置かない。
- 本番切替をこのDEV画面に追加しない。実Azure連携は別のサーバー側設計・承認・セキュリティレビューを行う。
- CORSはローカルホスト系Originのみ許可。これは開発用制御であり本番用ではない。

## 7. 仕様駆動の変更手順
1. CRを起票し、依頼者と目的を記録。
2. `impact.js <ID>` で影響範囲を調べる。
3. 改修前に全試験を実行し、`results.json` を別名で保存する。
4. `docs/spec_ac.csv` とADRを先に更新する。
5. 試験を先に追加し、可能なら実装前に不合格（Red）を確認。
6. 最小差分で実装し、全試験・照合表・前後diffを実行。
7. 仕様外変更／試験弱体化／秘密・権限の3観点で人がレビュー。
8. 説明の5問を埋め、人が承認する。AIは承認しない。

## 8. 現時点の検証範囲
この配布物について、ローカル環境でのNodeテストを実行した結果を同梱する。実Azureとの互換性、認識精度、Azureの本番制限・Retry-After等は未確認。詳細は `docs/OQ.md`。
