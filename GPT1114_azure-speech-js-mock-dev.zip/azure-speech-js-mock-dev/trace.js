// docs/spec_ac.csv と results.json を突き合わせる照合表。
import fs from "node:fs";
const rows = fs.readFileSync("docs/spec_ac.csv", "utf8").trim().split(/\r?\n/);
const results = JSON.parse(fs.readFileSync("results.json", "utf8"));
const table = ["| AC | 要件 | 結果 | 受け入れ基準 |", "|---|---|---|---|"];
for (const line of rows.slice(1)) {
  const [ac, requirement, ...criteria] = line.split(",");
  table.push(`| ${ac} | ${requirement} | ${results[ac] || "未実施"} | ${criteria.join(",")} |`);
}
const output = table.join("\n") + "\n";
fs.writeFileSync("trace.md", output);
console.log(output);
