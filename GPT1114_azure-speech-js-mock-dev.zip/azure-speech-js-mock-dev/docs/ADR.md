# ADR（Architecture Decision Record）

## ADR-001: DEVはローカルMockのみを呼び出す
- 状態: 採用
- 決定: `config.js` の接続先を `http://127.0.0.1:8787` に固定し、Mock Serverは127.0.0.1だけでlistenする。
- 理由: Azure APIへの誤送信と課金を避けるため。
- 代替案: Azure開発リソースを利用する（本DEV構成の対象外）。
- 影響: 実際の認識精度・Azure側の認証・サービス挙動は検証しない。

## ADR-002: 再試行契約は教材 sample-kit2 を移植
- 状態: 採用
- 決定: 401は再試行しない。429・5xx・network・timeoutは最大3回。待機は指数バックオフ1,2,4秒、上限30秒。
- 根拠: ZIP内 `sample-kit2/app/retry.py`、`sample-kit2/docs/spec_ac.csv`。
- 注意: 最大3回のため通常の実行で待機するのは1秒と2秒。4秒は3回目以降の待機計算値として単体テストする。

## ADR-003: 外部依存を導入しない
- 状態: 採用
- 決定: Node.js組み込みモジュールとNode標準テストランナーのみを使う。
- 理由: セットアップを簡単にし、ネットワーク接続やnpm installを不要にする。
