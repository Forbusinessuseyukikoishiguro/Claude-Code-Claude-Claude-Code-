// ローカル専用Azure Speech Fast Transcription形状Mock。
// Node.js標準モジュールのみ。Azure・外部ネットワークへは接続しない。
import http from "node:http";
import { URL, fileURLToPath } from "node:url";
import path from "node:path";

export const PORT = Number(process.env.PORT || 8787);
export const MOCK_KEY = process.env.MOCK_KEY || "mock-key";
export const FAIL_EVERY = Math.max(0, Number(process.env.FAIL_EVERY || 0));
export const MOCK_DELAY_MS = Math.max(0, Number(process.env.MOCK_DELAY_MS || 1200));
export const MAX_BODY_BYTES = Math.max(1024, Number(process.env.MAX_BODY_MB || 25) * 1024 * 1024);
export const TRANSCRIBE_PATH = "/speechtotext/transcriptions:transcribe";

function setCors(req, res) {
  const origin = req.headers.origin;
  // 開発用のローカル画面だけ許可。curl等、Originなしも許可。
  const allowed = !origin || /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin);
  if (allowed && origin) res.setHeader("Access-Control-Allow-Origin", origin);
  res.setHeader("Vary", "Origin");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Ocp-Apim-Subscription-Key");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
}

function json(res, status, body) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(body));
}

export function createMockServer(options = {}) {
  const key = options.key ?? MOCK_KEY;
  const failEvery = options.failEvery ?? FAIL_EVERY;
  const delayMs = options.delayMs ?? MOCK_DELAY_MS;
  const maxBodyBytes = options.maxBodyBytes ?? MAX_BODY_BYTES;
  let requestCount = 0;

  const server = http.createServer((req, res) => {
    setCors(req, res);
    const url = new URL(req.url || "/", "http://127.0.0.1");

    if (req.method === "OPTIONS") {
      res.writeHead(204);
      return res.end();
    }

    if (url.pathname !== TRANSCRIBE_PATH || req.method !== "POST") {
      return json(res, 404, { error: { code: "404", message: "Not found" } });
    }

    if (req.headers["ocp-apim-subscription-key"] !== key) {
      return json(res, 401, { error: { code: "401", message: "Access denied (mock)" } });
    }

    const contentType = String(req.headers["content-type"] || "");
    if (!contentType.toLowerCase().startsWith("multipart/form-data;")) {
      return json(res, 400, { error: { code: "400", message: "Expected multipart/form-data" } });
    }

    let bytes = 0;
    let tooLarge = false;
    req.on("data", chunk => {
      bytes += chunk.length;
      if (bytes > maxBodyBytes) tooLarge = true;
    });
    req.on("end", () => {
      if (tooLarge) return json(res, 413, { error: { code: "413", message: "Mock payload too large" } });
      requestCount += 1;
      const current = requestCount;

      if (failEvery > 0 && current % failEvery === 0) {
        return json(res, 429, { error: { code: "429", message: "Too many requests (mock)" } });
      }

      setTimeout(() => {
        if (res.destroyed) return;
        json(res, 200, {
          durationMilliseconds: 600000,
          combinedPhrases: [
            { text: `【モック】${(bytes / 1048576).toFixed(1)}MBの区間 #${current} の文字起こし結果です。` }
          ],
          mock: true,
          requestNumber: current,
          receivedBytes: bytes
        });
      }, delayMs);
    });
  });

  return {
    server,
    get requestCount() { return requestCount; }
  };
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  const instance = createMockServer();
  // 127.0.0.1へ限定し、LAN・インターネットから到達できないようにする。
  instance.server.listen(PORT, "127.0.0.1", () => {
    console.log(`Local Azure Speech mock: http://127.0.0.1:${PORT}`);
    console.log(`Route: POST ${TRANSCRIBE_PATH}`);
    console.log(`FAIL_EVERY=${FAIL_EVERY}, MOCK_DELAY_MS=${MOCK_DELAY_MS}`);
    console.log("Azure API calls: disabled (local mock only)");
  });
}
