import { spawnSync } from "node:child_process";
import fs from "node:fs";

const run = spawnSync(process.execPath, ["--test", "--test-reporter=tap"], {
  encoding: "utf8"
});
const output = (run.stdout || "") + (run.stderr || "");
process.stdout.write(output);

const results = {};
for (const line of output.split(/\r?\n/)) {
  const match = line.match(/^(ok|not ok)\s+\d+\s+-\s+(AC-\d{2})\b/);
  if (match) {
    const [, state, ac] = match;
    if (state === "not ok") results[ac] = "不合格";
    else if (results[ac] !== "不合格") results[ac] = "合格";
  }
}
const spec = fs.readFileSync("docs/spec_ac.csv", "utf8").trim().split(/\r?\n/).slice(1);
for (const row of spec) {
  const ac = row.split(",")[0];
  if (!results[ac]) results[ac] = "未実施";
}
fs.writeFileSync("results.json", JSON.stringify(results, null, 2) + "\n");
if (run.status !== 0) process.exit(run.status ?? 1);
