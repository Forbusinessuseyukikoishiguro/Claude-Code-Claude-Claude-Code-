import test from "node:test";
import assert from "node:assert/strict";
import { createMockServer, TRANSCRIBE_PATH } from "../mock-server.js";

async function withServer(options, fn) {
  const mock = createMockServer({ delayMs: 0, ...options });
  await new Promise(resolve => mock.server.listen(0, "127.0.0.1", resolve));
  const address = mock.server.address();
  try { await fn(`http://127.0.0.1:${address.port}`); }
  finally { await new Promise(resolve => mock.server.close(resolve)); }
}

test("AC-07 valid multipart request returns Speech-shaped mock JSON", async () => {
  await withServer({ key: "test-key" }, async base => {
    const form = new FormData();
    form.append("audio", new Blob(["fake audio bytes"], { type: "audio/wav" }), "sample.wav");
    const response = await fetch(base + TRANSCRIBE_PATH, {
      method: "POST",
      headers: { "Ocp-Apim-Subscription-Key": "test-key" },
      body: form
    });
    assert.equal(response.status, 200);
    const body = await response.json();
    assert.equal(body.mock, true);
    assert.equal(Array.isArray(body.combinedPhrases), true);
    assert.match(body.combinedPhrases[0].text, /【モック】/);
  });
});

test("AC-08 invalid key returns 401", async () => {
  await withServer({ key: "right-key" }, async base => {
    const form = new FormData();
    form.append("audio", new Blob(["x"]), "x.wav");
    const response = await fetch(base + TRANSCRIBE_PATH, {
      method: "POST", headers: { "Ocp-Apim-Subscription-Key": "wrong-key" }, body: form
    });
    assert.equal(response.status, 401);
  });
});

test("AC-09 wrong route, method and content type are rejected", async () => {
  await withServer({}, async base => {
    assert.equal((await fetch(base + "/wrong")).status, 404);
    assert.equal((await fetch(base + TRANSCRIBE_PATH, { method: "GET" })).status, 404);
    const response = await fetch(base + TRANSCRIBE_PATH, {
      method: "POST",
      headers: { "Ocp-Apim-Subscription-Key": "mock-key", "Content-Type": "text/plain" },
      body: "not multipart"
    });
    assert.equal(response.status, 400);
  });
});
