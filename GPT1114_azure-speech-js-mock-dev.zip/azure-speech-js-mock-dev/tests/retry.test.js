import test from "node:test";
import assert from "node:assert/strict";
import { classify, shouldRetry, backoffSec, sendWithRetry } from "../retry.js";

const noSleep = async () => {};

test("AC-01 401 is auth and stops after one attempt", async () => {
  let calls = 0;
  const result = await sendWithRetry(async () => { calls++; return 401; }, { sleep: noSleep });
  assert.deepEqual({ tries: result.tries, kind: result.kind }, { tries: 1, kind: "auth" });
  assert.equal(calls, 1);
});

test("AC-02 persistent 429 stops after three attempts", async () => {
  let calls = 0;
  const result = await sendWithRetry(async () => { calls++; return 429; }, { sleep: noSleep });
  assert.deepEqual({ tries: result.tries, kind: result.kind }, { tries: 3, kind: "rate_limit" });
  assert.equal(calls, 3);
});

test("AC-03 503 then 200 recovers on second attempt", async () => {
  const sequence = [503, 200];
  const result = await sendWithRetry(async () => sequence.shift(), { sleep: noSleep });
  assert.deepEqual({ tries: result.tries, kind: result.kind }, { tries: 2, kind: "ok" });
});

test("AC-04 unexpected 418 is not retryable", () => {
  assert.equal(classify(418), "unknown");
  assert.equal(shouldRetry(classify(418)), false);
});

test("AC-05 exponential backoff is 1, 2, 4 seconds", () => {
  assert.deepEqual([1, 2, 3].map(backoffSec), [1, 2, 4]);
});

test("AC-05 retry waits are recorded in order", async () => {
  const waits = [];
  await sendWithRetry(async () => 429, { sleep: async ms => waits.push(ms) });
  assert.deepEqual(waits, [1000, 2000]);
});

test("AC-06 exponential backoff is capped at 30 seconds", () => {
  assert.equal(backoffSec(10), 30);
});

test("AC-06 invalid attempt numbers are rejected", () => {
  assert.throws(() => backoffSec(0), RangeError);
});
