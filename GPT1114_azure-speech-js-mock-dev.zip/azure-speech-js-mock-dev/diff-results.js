// before.json と results.json を比較し、退行・試験消失を検出する。
import fs from "node:fs";
const [beforePath, afterPath] = process.argv.slice(2);
if (!beforePath || !afterPath) {
  console.error("Usage: node diff-results.js before.json results.json"); process.exit(2);
}
const before = JSON.parse(fs.readFileSync(beforePath, "utf8"));
const after = JSON.parse(fs.readFileSync(afterPath, "utf8"));
let hasProblem = false;
for (const ac of [...new Set([...Object.keys(before), ...Object.keys(after)])].sort()) {
  const a = before[ac] || "未実施";
  const b = after[ac] || "未実施";
  let tag = "変化なし";
  if (a === "合格" && b === "不合格") { tag = "退行（要対応）"; hasProblem = true; }
  else if (a === "合格" && b === "未実施") { tag = "消失（試験が消えた。要説明）"; hasProblem = true; }
  else if (b === "合格" && a !== "合格") tag = "新規合格";
  else if (b === "不合格") { tag = "新規不合格"; hasProblem = true; }
  console.log(`${ac}: ${a} → ${b} [${tag}]`);
}
process.exit(hasProblem ? 1 : 0);
