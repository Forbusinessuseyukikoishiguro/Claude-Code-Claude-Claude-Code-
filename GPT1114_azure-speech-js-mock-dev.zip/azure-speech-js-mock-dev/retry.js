// FR-02 / FR-03 / NFR-01: ZIP教材 sample-kit2 の契約をJavaScriptへ移植。
export const BACKOFF_CAP_SEC = 30;
export const RETRYABLE = new Set(["rate_limit", "server", "network", "timeout"]);

export function classify(value) {
  if (value && typeof value === "object" && typeof value.kind === "string") {
    return RETRYABLE.has(value.kind) ? value.kind : value.kind;
  }
  const status = typeof value === "object" && value !== null ? value.status : value;
  if (status === 401) return "auth";
  if (status === 429) return "rate_limit";
  if (Number.isInteger(status) && status >= 500 && status <= 599) return "server";
  if (status === 200) return "ok";
  return "unknown";
}

export function shouldRetry(kind) {
  return RETRYABLE.has(kind);
}

export function backoffSec(tries) {
  if (!Number.isInteger(tries) || tries < 1) throw new RangeError("tries must be a positive integer");
  return Math.min(2 ** (tries - 1), BACKOFF_CAP_SEC);
}

export async function sendWithRetry(send, {
  maxTries = 3,
  sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms)),
  onRetry = () => {}
} = {}) {
  if (!Number.isInteger(maxTries) || maxTries < 1) throw new RangeError("maxTries must be >= 1");
  let tries = 0;
  let lastResult;
  let kind = "unknown";

  while (tries < maxTries) {
    tries += 1;
    try {
      lastResult = await send(tries);
      kind = classify(lastResult);
    } catch (error) {
      lastResult = { kind: error?.name === "TimeoutError" ? "timeout" : "network", error };
      kind = classify(lastResult);
    }

    if (!shouldRetry(kind) || tries >= maxTries) break;

    const waitSec = backoffSec(tries);
    onRetry({ tries, nextTry: tries + 1, kind, waitSec });
    await sleep(waitSec * 1000);
  }
  return { tries, kind, result: lastResult };
}

// ブラウザ用。タイムアウトと通信失敗をHTTPステータスと区別する。
export async function postMultipartWithRetry(url, formData, apiKey, options = {}) {
  const { timeoutMs = 30000, ...retryOptions } = options;
  return sendWithRetry(async () => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Ocp-Apim-Subscription-Key": apiKey },
        body: formData,
        signal: controller.signal
      });
      return { status: response.status, response };
    } catch (error) {
      return {
        kind: controller.signal.aborted ? "timeout" : "network",
        error: controller.signal.aborted ? new DOMException("Request timed out", "TimeoutError") : error
      };
    } finally {
      clearTimeout(timer);
    }
  }, retryOptions);
}
