// AC / FR / NFR IDから仕様・コード・試験の文字列一致を逆引きする簡易ツール。
// 限界: IDが記載されていない依存関係は検出できない。
import fs from "node:fs";
import path from "node:path";
const key = process.argv[2];
if (!key) { console.error("Usage: node impact.js AC-02|FR-03|NFR-01"); process.exit(2); }
const specLines = fs.readFileSync("docs/spec_ac.csv", "utf8").trim().split(/\r?\n/);
const ids = new Set([key]);
for (const line of specLines.slice(1)) {
  const [ac, req] = line.split(",");
  if (key === ac || key === req) { ids.add(ac); ids.add(req); }
}
console.log("対象ID:", [...ids].sort().join(", "));
console.log("仕様:");
for (const line of specLines.slice(1)) {
  if ([...ids].some(id => line.includes(id))) console.log("  " + line);
}
console.log("コード・試験:");
let hits = 0;
for (const dir of ["tests", "."]) {
  const names = dir === "tests" ? fs.readdirSync(dir).map(n => path.join(dir, n)) :
    ["retry.js", "mock-server.js", "app.js", "config.js"];
  for (const file of names) {
    if (!fs.existsSync(file) || !fs.statSync(file).isFile()) continue;
    const lines = fs.readFileSync(file, "utf8").split(/\r?\n/);
    lines.forEach((line, i) => {
      const normalized = line.replaceAll("_", "-");
      if ([...ids].some(id => normalized.includes(id))) {
        console.log(`  ${file}:${i + 1}: ${line.trim().slice(0, 100)}`); hits++;
      }
    });
  }
}
if (!hits) console.log("  （該当なし。仕様と実装の対応を人が確認）");
