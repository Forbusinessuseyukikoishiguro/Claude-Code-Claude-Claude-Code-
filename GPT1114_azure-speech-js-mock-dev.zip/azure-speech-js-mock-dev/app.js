import { CONFIG } from "./config.js";
import { postMultipartWithRetry } from "./retry.js";

const $ = (id) => document.getElementById(id);
const fileInput = $("audioFile");
const sendButton = $("sendButton");
const log = $("log");
const status = $("status");
const resultBox = $("result");

$("endpoint").textContent = `${CONFIG.endpoint}${CONFIG.route}`;

function writeLog(message) {
  log.textContent += `\n${new Date().toLocaleTimeString()} ${message}`;
  log.scrollTop = log.scrollHeight;
}

fileInput.addEventListener("change", () => {
  const file = fileInput.files?.[0];
  $("fileInfo").textContent = file
    ? `${file.name} / ${(file.size / 1048576).toFixed(2)} MB / ${file.type || "type unknown"}`
    : "ファイル未選択";
  sendButton.disabled = !file || file.size > CONFIG.maxFileBytes;
  if (file && file.size > CONFIG.maxFileBytes) {
    status.textContent = "ファイルサイズ超過";
    writeLog(`選択不可: 最大 ${(CONFIG.maxFileBytes / 1048576).toFixed(0)} MB`);
  }
});

sendButton.addEventListener("click", async () => {
  const file = fileInput.files?.[0];
  if (!file) return;
  sendButton.disabled = true;
  resultBox.value = "";
  log.textContent = "Mock送信を開始します。";
  status.textContent = "処理中";

  const form = new FormData();
  form.append("audio", file, file.name);

  const outcome = await postMultipartWithRetry(
    `${CONFIG.endpoint}${CONFIG.route}`,
    form,
    CONFIG.apiKey,
    {
      maxTries: CONFIG.maxTries,
      timeoutMs: CONFIG.timeoutMs,
      onRetry: ({ tries, nextTry, kind, waitSec }) => {
        writeLog(`${kind}: ${tries}回目失敗。${waitSec}秒待って${nextTry}回目を実行`);
        status.textContent = `再試行待ち (${nextTry}/${CONFIG.maxTries})`;
      }
    }
  );

  writeLog(`終了: tries=${outcome.tries}, kind=${outcome.kind}`);
  if (outcome.kind === "ok") {
    const payload = outcome.result.response ? await outcome.result.response.json() : {};
    const text = (payload.combinedPhrases || []).map(item => item.text || "").join("\n");
    resultBox.value = text || "Mock応答にcombinedPhrasesがありません。";
    status.textContent = `成功 (HTTP ${outcome.result.status})`;
    writeLog(`Mock応答: ${payload.receivedBytes ?? "?"} bytes / request #${payload.requestNumber ?? "?"}`);
  } else {
    const response = outcome.result?.response;
    let detail = "";
    if (response) {
      try { detail = JSON.stringify(await response.json()); } catch {}
    } else if (outcome.result?.error) {
      detail = outcome.result.error.message;
    }
    status.textContent = `失敗 (${outcome.kind})`;
    writeLog(`最終エラー: ${detail || outcome.kind}`);
  }
  sendButton.disabled = !fileInput.files?.[0] || fileInput.files[0].size > CONFIG.maxFileBytes;
});
