// DEV専用設定。Azureの実キーをここへ書かないこと。
export const CONFIG = Object.freeze({
  environment: "development",
  endpoint: "http://127.0.0.1:8787",
  apiKey: "mock-key",
  route: "/speechtotext/transcriptions:transcribe",
  maxTries: 3,
  timeoutMs: 30000,
  maxFileBytes: 25 * 1024 * 1024
});
