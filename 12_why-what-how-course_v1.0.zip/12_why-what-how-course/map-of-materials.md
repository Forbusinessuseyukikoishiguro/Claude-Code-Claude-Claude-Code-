# 成果物の対応表（講義と、zip の番号）

| 講義 | 主な成果物（zip） | 中の場所（例） |
|---|---|---|
| 0 | 全体（01〜11） | README.md |
| W1・W2 | 03、10 | 03 の docs/spec.md（受け入れ基準）、10 の 01 仕様を要件に起こす |
| W3 | 10、08 | 10 の 04・07（レビュー前、指摘対応）、08 の 00（研修設計） |
| T1 | 03、09、11 | 03 の docs/decisions.md・open-questions.md、09 の notion-kit、11 |
| T2 | 03、04 | 03 の src/・test/・docs/、04（旧版の講座） |
| T3 | 05、06、09、11 | 05 の docker/dev、06 の api-testing-kit、09 の notion-kit、11 の setup-manual |
| T4 | 07、08、10、04 | 07 の book/、08 の corporate-course、10 の dev-docs-kit、04 |
| H1 | 03、10、11 | 03 の docs/spec.md、10 の 01、11 の setup-manual |
| H2 | 03、09 | 03 の docs/decisions.md、09 の決定データベース |
| H3 | 03、06 | 03 の tests/、06 の tests/ |
| H4 | 03、10 | 03 の scripts/run_all_tests.py・make_checklist_xlsx.py、10 の 04・06・07 |
| H5 | 03、07、09、10 | 03 の CLAUDE.md と .claude/skills、07 の特典、09 のスキル、10 の 08・09 |

> 番号は、この講座の制作時点の zip の番号（01〜11）。最新の版は、リポジトリのタグで確認する（例：v2.1.0）。
