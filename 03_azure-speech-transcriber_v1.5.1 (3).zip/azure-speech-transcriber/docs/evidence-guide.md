# 証跡の回収手順書（エンジニア実務向け）

対象: Azure Speech 文字起こしツール
目的: 試験の結果、版、環境、ログを1つのフォルダに集め、報告できる状態にする。
関連: `.claude/skills/evidence-collect/SKILL.md`（Claude Code のスキル）、`scripts/collect-evidence.js`

---

## 1. 回収するもの

| 種類 | ファイル | 作成元 | 目的 |
|---|---|---|---|
| 実行ログ | verify.log | `npm run verify` | build・単体テスト・秘密情報検査の結果 |
| 実行ログ | e2e.log | `scripts/e2e_smoke.py` | 画面試験（AC単位の合否） |
| 機械可読の記録 | manifest.json | 回収スクリプト | 版、環境、ハッシュ、手順の結果、秘密情報検査 |
| 人が読む報告 | report.md | 回収スクリプト | 判定の候補、AC別の結果、未検証の項目 |
| 成果物の控え | index.html | build | 試験した版（再現に使う） |
| 仕様の控え | docs/spec.md ほか | コピー | 試験時点の要件（版番号つき） |
| 計測結果 | docs/measurements.md | コピー（任意） | メモリ計測の記録 |
| Git の状態 | git-status.txt | git | 未コミットの変更があったかの記録 |

**回収しないもの（必ず守る）**
- `config.js`、`config.real.js`（APIキーを含む）
- `*.wav`（音声。機密を含みうる）
- 本番の文字起こし結果（試験で作った `.txt` も、必要な分だけ残す）

---

## 2. 保存の場所と名前
- 場所: `test/results/<YYYY-MM-DD_HHMM>/`
- 同じ分に2回実行すると、同じフォルダに上書きされる。
- 試験の日付ごとに、フォルダを分けて残す。上書きしない。

---

## 3. VS Code での操作（手順）

### 3-1. 初回の準備（一度だけ）
1. VS Code で `azure-speech-transcriber` フォルダを開く。
2. Node.js 18 以上を確認：ターミナル（Ctrl + `）で `node -v`
3. ブラウザ試験を使う場合のみ：
   - `python --version`（Windows）または `python3 --version`（Mac・Linux）
   - `pip install playwright`
   - `python -m playwright install chromium`（Windows は `python -m`、Mac・Linux は `python3 -m`）

### 3-2. 回収の実行（推奨：タスクを使う）
1. `Ctrl + Shift + P` → 「Tasks: Run Task」
2. 次のいずれかを選ぶ。
   - **証跡を回収（verify のみ）**：ブラウザ試験を含めない場合
   - **証跡を回収（verify ＋ ブラウザ試験）**：通常の回収
   - **証跡を回収（ブラウザ試験 ＋ メモリ計測の結果を含める）**：計測結果も含める場合
3. ターミナルに「自動判定（候補）」と、手順ごとの結果が表示される。

### 3-3. Claude Code で回収する（スキルを使う）
1. VS Code のターミナルで `claude` を起動する（Claude Code がインストール済みであること）。
2. 次のように依頼する。
   - 「証跡を回収して。ブラウザ試験も含めて」
   - 「試験結果を報告書にまとめて」
3. Claude が `evidence-collect` スキルに従って、回収・確認・報告を行う。
4. 報告を受けたら、`report.md` を開き、判定欄（§6）を人が記入する。

> スキルは `.claude/skills/evidence-collect/SKILL.md` にある。内容を変えると、Claude の動作も変わる。変更は仕様の変更と同じ扱いで、docs/spec.md の版を上げる。

---

## 4. 回収後の確認チェックリスト
- [ ] `report.md` の「自動判定（候補）」を確認した
- [ ] 不合格の手順は、ログの該当行を確認した
- [ ] `manifest.json` の `secretScan.ok` が `true` である
- [ ] フォルダに `config.js`・`config.real.js`・`*.wav` が**無い**ことを確認した（エクスプローラーで確認）
- [ ] `report.md` の §5（未確認の項目）を、報告書に転記した
- [ ] 判定欄（§6）に、確認者と日付を記入した

---

## 5. 共有・保管の手順

### 5-1. 圧縮して渡す
Windows（PowerShell）:

    Compress-Archive -Path .\test\results\2026-11-11_1030 -DestinationPath .\test\results\2026-11-11_1030.zip

Mac・Linux:

    tar -czf 2026-11-11_1030.tar.gz -C test/results 2026-11-11_1030

### 5-2. 共有の前に確認すること
- 圧縮ファイルの中身に、APIキーと音声が含まれないこと（§4 のチェック）。
- 共有先の範囲（社内のみ、取引先には出さない等）。規程は OQ-07 に従う。

### 5-3. 保管
- 保管期間は社内規程に従う（OQ-07 で未確定）。
- 音声ファイル（分割したピースも含む）は、試験後に削除する。結果フォルダには残さない。
- Git で管理する場合、`test/results/` は `.gitignore` の対象。結果は別の場所に保存する。

---

## 6. 困ったとき

| 症状 | 原因の候補 | 対処 |
|---|---|---|
| 「python が見つからない」 | Python 未導入、または PATH 未設定 | Python を入れ直す。Windows は「PATH に追加」を有効にする |
| e2e が失敗し、Chromium が無いと表示 | playwright の chromium 未導入 | `python -m playwright install chromium` |
| verify が失敗（build） | src/index.html のマーカー欠落 | src/index.html に `<!--@INLINE lib-->` があるか確認 |
| verify が失敗（check） | 実際のキーが src/・index.html に入っている | キーを config.js に移し、ファイルのキーを消す |
| 自動判定が「未完了」 | `--e2e` を付けなかった | `--e2e` 付きのタスクで実行し直す |
| 自動判定が「不合格」だが原因が分からない | ログが長い | verify.log は `not ok`、e2e.log は `[否]` で検索する |
| 「機密を含みうるファイルが Git の追跡対象」の警告 | config.js を git add した | `git rm --cached config.js` で追跡を外し、`.gitignore` を確認する |

---

## 7. 運用ルール（要点）
1. 回収は、試験の実施日に行う。後日まとめて回収しない。
2. 報告書は、実行した手順だけを合格と書く。未実行は未実行と書く。
3. 回収フォルダは、APIキーや音声を含めない。
4. 仕様と試験の対応（AC番号）を崩さない。AC番号が変わったら docs/spec.md と報告書の両方を更新する。
