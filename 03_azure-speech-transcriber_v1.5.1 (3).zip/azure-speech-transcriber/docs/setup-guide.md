# セットアップ手順書（Windows・VS Code・Git・GitHub・Docker）

対象: Azure Speech 文字起こしツール
想定環境: Windows 10/11、VS Code、Git for Windows、GitHub アカウント、Docker Desktop（任意）
読み方: §1〜§7 が**初回**。§8 以降が**次回以降**と、トラブル対応。

> 用語: 「リポジトリ」＝プロジェクトのフォルダと、その変更履歴（Git が管理する）。「push」＝自分のPCの変更をGitHubへ送ること。「pull」＝GitHubの変更を自分のPCへ取り込むこと。

---

## 0. 守ること（必読）
1. **config.js をコミットしない。** APIキーが入る。`.gitignore` で除外済み。
2. **音声ファイル（*.wav・*.mp3）と test/results/ をコミットしない。** 機密を含みうる。
3. **APIキーを index.html や src/ に書かない。** `npm run check` で検出される。
4. Docker・CI は本番のAzureに接続しない（試験はモック）。

---

## 1. 初回：ツールの導入（Windows）

| ツール | 入手先 | 確認コマンド（PowerShell） | 必須 |
|---|---|---|---|
| Git for Windows | https://git-scm.com/ | `git --version` | 必須 |
| Node.js 22 LTS | https://nodejs.org/ | `node -v` | 必須 |
| Python 3.12 以上 | https://www.python.org/ | `python --version` | 必須（インストーラーで「Add python.exe to PATH」を有効に） |
| VS Code | https://code.visualstudio.com/ | — | 推奨 |
| Docker Desktop | https://www.docker.com/ | `docker --version` | 任意（§6） |

Git のインストールでは、次の設定を推奨する。
- 既定のエディタ：Visual Studio Code
- 改行コード：「Checkout Windows-style, commit Unix-style」（既定のまま）
- 既定ブランチ名：`main`

Docker Desktop は、インストール時に **WSL 2 の使用** を有効にする。初回起動後、再起動を求められたら再起動する。

---

## 2. 初回：プロジェクトを開く

1. 配布された zip（`azure-speech-transcriber.zip`）を任意の場所に展開する（例：`C:\work\azure-speech-transcriber`）。**日本語を含まないパスが望ましい。**
2. VS Code で `File → Open Folder` から、展開したフォルダを開く。
3. VS Code の右下に「推奨拡張機能」の通知が出たら、`Install` を押す（Claude Code、Docker、GitHub PR）。
4. 統合ターミナルを開く：`Ctrl + @`（または `Ctrl + ``）。既定は PowerShell。

---

## 3. 初回：Git を用意する

PowerShell（プロジェクトのフォルダで）:

```powershell
git init -b main
git config user.name "your-name"          # 自分の名前（GitHub の表示名と揃えると分かりやすい）
git config user.email "you@example.com"   # GitHub に登録したメールアドレス
git add .
git status
```

`git status` の一覧を**必ず確認する**。次のファイルが無いことを確かめる（§0）。
- `config.js` ／ `config.real.js` ／ `*.wav` ／ `test/results/`

もし含まれていたら、次で追跡から外す。

```powershell
git rm --cached config.js
```

問題がなければ、最初のコミットを作る。

```powershell
git commit -m "初回コミット：仕様・実装・試験一式"
```

---

## 4. 初回：GitHub にリポジトリを作り、push する

### 4-1. GitHub でリポジトリを作る
1. https://github.com/ にログインし、右上の `+ → New repository` を開く。
2. Repository name：`azure-speech-transcriber`（例）
3. **Private** を選ぶ（社内ツールのため公開しない）。
4. `Add a README`・`.gitignore`・`license` は**チェックしない**（手元のファイルと衝突するため）。
5. `Create repository` を押す。

### 4-2. 手元とつなぐ
画面に表示される「…or push an existing repository from the command line」のコマンドを使う（URL は各自のものに置き換わる）。

```powershell
git remote add origin https://github.com/<あなたのアカウント>/azure-speech-transcriber.git
git push -u origin main
```

- 初回の push で、Git Credential Manager がブラウザを開く。GitHub にサインインして承認する。
- パスワードは使えない（GitHub の仕様）。ブラウザ認証、または GitHub CLI（`gh auth login`）を使う。

### 4-3. 確認
- GitHub のリポジトリ画面で、ファイルが見えること。
- `config.js` が**見えないこと**。
- `.github/workflows/ci.yml` があり、`Actions` タブで `verify` が実行されていること（§5 参照）。

---

## 5. 初回：APIキーの設定と検証

1. PowerShell で、セットアップを実行する。
   ```powershell
   powershell -ExecutionPolicy Bypass -File .\scripts\windows\setup.ps1
   ```
   - 「NG」が出たツールを入れてから、もう一度実行する。
   - `config.js` が作られたら、VS Code で開いて次を編集する。
     - `endpoint`：Azure リソースのエンドポイント（例：`https://japaneast.api.cognitive.microsoft.com`）
     - `apiKey`：Azure ポータルの「キーとエンドポイント」から取得したキー
2. 検証（APIキーを使わない試験）：
   ```powershell
   npm run verify
   ```
   - 「自動試験」「秘密情報の混入は検出されませんでした」が出れば成功。
3. ブラウザ試験（モック使用）：
   ```powershell
   npm run e2e
   ```
   - `合格 13 / 13 件` で成功。
4. 回収（報告書の作成）：
   ```powershell
   powershell -ExecutionPolicy Bypass -File .\scripts\windows\collect.ps1
   ```
   - `test\results\<日時>\report.md` と、同じ名前の `.zip` ができる。

> 注意：`config.js` に実際の APIキーを入れた状態で、`npm run e2e` は実行しないこと。e2e は一時フォルダにモック用の設定を作るため、本番のキーは使わないが、手順の混同を防ぐため。実Azureの確認は、§9 の手順で1分程度の音声を使って1回だけ行う。

---

## 6. 初回：Docker で試験する（任意）

Docker を使うと、Node・Python・Chromium・ffmpeg の版を固定できる。PCごとの差を減らせる。

PowerShell（プロジェクトのフォルダで。Docker Desktop が起動していること）:

```powershell
docker build -t azure-speech-test .
docker run --rm azure-speech-test                       # verify（既定）
docker run --rm azure-speech-test sh -c "npm run verify && npm run e2e"   # verify と画面試験
```

回収結果を Windows 側に残す場合（`test\results` を共有する）:

```powershell
docker run --rm -v "${PWD}\test\results:/app/test/results" azure-speech-test sh -c "npm run verify && node scripts/collect-evidence.js --e2e"
```

- `${PWD}` は PowerShell の書き方。cmd では `%cd%` を使う。
- `.dockerignore` により、`config.js` と音声ファイルはイメージに入らない。
- 注意：**この手順書の作成環境では Docker は実行していない。** 初回は §8-4 の手順で、エラーがないか確認すること。

---

## 7. 初回：VS Code で Claude Code を使う（任意）

1. ターミナルで `claude` を起動する（Claude Code がインストール済みであること）。
2. 依頼例：
   - 「仕様に沿って、verify と e2e を実行して結果を報告して」
   - 「証跡を回収して、報告書にまとめて」
3. スキル `evidence-collect`（`.claude/skills/evidence-collect/SKILL.md`）が、回収の手順を担当する。
4. Claude が `config.js` を読んで APIキーを表示しないことを、必ず確認する（`.claude/settings.json` で読み取りを禁止している）。

---

# 次回以降（毎回の作業）

## 8. 次回以降の基本手順

### 8-1. 作業を始める（最新を取り込む）
```powershell
cd C:\work\azure-speech-transcriber
git status                 # 前回の作業が残っていないか確認
git pull                   # GitHub の最新を取り込む
```

### 8-2. 変更する
1. 仕様を変えるときは、先に `docs/spec.md` を更新する。
2. 編集は `src/` で行う（`index.html` は生成物。直接編集しない）。
3. 変更したら、ビルドとテストを実行する。
   ```powershell
   npm run verify
   ```

### 8-3. 作業を保存する（コミットと push）
```powershell
git status                             # 変更ファイルを確認（config.js が無いこと）
git add src docs scripts test/unit CLAUDE.md
git commit -m "FR-06: 区間の見出しを修正（AC-UT-06 追加）"
git push
```

- コミットのメッセージには、**関係する要件番号（FR・AC）を書く**。
- `git add .` は、意図しないファイルが混ざる恐れがあるため、次回から避ける。`git status` で対象を確かめてから、ファイル名を指定する。

### 8-4. 自動検証（CI）の確認
- GitHub の `Actions` タブで、最新の `verify` が緑（成功）であることを確認する。
- 赤（失敗）の場合は、ログを開き、失敗した手順（verify または e2e）を確認する。

### 8-5. 試験結果を回収する
```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\windows\collect.ps1
```
- 結果は `test\results\<日時>\` と zip に残る。**zip は GitHub にアップロードしない**（`.gitignore` で除外済み）。

### 8-6. 作業を終える
1. `git status` で、未コミットの変更がないことを確認する。
2. `git push` で、GitHub に反映されていることを確認する。
3. 試験結果の zip は、社内の規程に従って保管する（OQ-07）。

---

## 9. 実Azureでの最初の確認（1回だけ）
モック試験が通った後に、1分程度の音声で一度だけ確認する（TST-02）。

1. `config.js` の `endpoint` と `apiKey` を本番の値にする。
2. 1分の WAV を用意する（`node make-test-wav.js 1` で生成できる。内容は試験用の音）。
3. `python -m http.server 8000` で配信し（プロジェクトのフォルダで実行）、ブラウザで `http://localhost:8000/index.html` を開く。
4. 分割単位 1 分で開始し、結果が返るかを確認する。
5. 次を記録する：CORS エラーの有無、api-version の受け付け、応答の形、処理時間。
6. 結果を `docs/open-questions.md`（OQ-01・OQ-02）に書き、確定した値を `config.js` と `docs/spec.md` に反映する。
7. 課金の確認：Azure ポータルで、利用量を確認する。

---

## 10. トラブルシューティング

| 症状 | 原因の候補 | 対処 |
|---|---|---|
| `git` が認識されない | PATH 未設定、または導入直後 | 新しいターミナルを開く。それでも駄目なら Git を入れ直す |
| `npm` が「スクリプトの実行が無効」 | PowerShell の実行ポリシー | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`（管理者でなくてよい） |
| `python` が Microsoft Store を開く | 実際の Python が未導入 | Python を入れ直し、「Add to PATH」を有効にする |
| `playwright install` が失敗する | 通信制限、または古い pip | `python -m pip install --upgrade pip` のあと再実行 |
| push で認証が求められて進まない | 認証情報の不一致 | `git credential-manager erase` の後、再度 push する |
| `config.js` を push してしまった | `.gitignore` 適用前に追加した | `git rm --cached config.js`、commit、push。**APIキーは再発行する** |
| CI（Actions）が失敗する | ローカルと環境の差 | ログの `npm run verify` の部分を見る。Node の版（22）を揃える |
| Docker が起動しない | WSL 2 が無効、仮想化が無効 | Docker Desktop の設定で WSL 2 を有効にする。BIOS の仮想化（VT-x/AMD-V）を確認 |
| `docker run` で `test\results` に書けない | ボリュームのパス指定の誤り | `${PWD}\test\results` を使う。パスに空白がある場合は引用符で囲む |
| 日本語が文字化けする（ログ） | PowerShell のコードページ | `chcp 65001` を実行する |
| 改行コードの警告（CRLF/LF） | `.gitattributes` の設定前のファイル | 警告は無害。気になる場合は `git add --renormalize .` |

---

## 11. チェックリスト

### 初回（一度だけ）
- [ ] Git・Node.js 22・Python 3.12 を導入し、PATH で確認できた
- [ ] VS Code でフォルダを開き、推奨拡張機能を入れた
- [ ] `git status` で `config.js` と `*.wav` が含まれないことを確認した
- [ ] GitHub にプライベートリポジトリを作り、push できた
- [ ] GitHub の画面で `config.js` が見えないことを確認した
- [ ] `setup.ps1` が完了し、`npm run verify` が通った
- [ ] `npm run e2e` が 13/13 で通った
- [ ] Actions（verify）が緑になった

### 次回以降（毎回）
- [ ] `git pull` で最新を取り込んだ
- [ ] `npm run verify` が通った
- [ ] コミットに要件番号を書いた
- [ ] `git status` で機密ファイルが無いことを確認した
- [ ] `git push` の後、Actions が緑になった
- [ ] 試験結果を回収し、報告書の判定欄を人が記入した
