# 未確定事項（Open Questions）

未確定の値は、推測で確定させない。確認方法と担当を決め、解消したら「解消」欄に日付と結果を書く。

| ID | 未確定の内容 | 影響する要件 | 確認方法 | 担当 | 状態 |
|---|---|---|---|---|---|
| OQ-01 | Fast transcription の api-version（現在 2024-11-15）と、フォーム項目名（audio・definition）が正しいか | FR-07 | Microsoft Learn の Fast transcription のページで最新版と項目名を確認。config.js の apiVersion を更新 | 開発者 | 未解消 |
| OQ-02 | ブラウザ（file://・http://localhost）から Azure へ直接通信できるか（CORS） | FR-07、NFR-01 | 1分の音声で実Azureに1回だけ接続。CORS エラーなら、Azure側の設定やプロキシを検討 | 開発者 | 未解消 |
| OQ-03 | m4a・aac・ogg・flac・webm が、ブラウザでのデコードと Azure での受け付けの両方で通るか | FR-02 | 部分解消：mp3（128kbps・60分）と wav は、Chromium のデコードと試験フロー（モック）で通過を確認済み（docs/measurements.md）。残り：m4a・aac・ogg・flac・webm、および実Azureでの受け付け | 開発者 | 一部解消 |
| OQ-04 | Fast transcription の上限（1リクエストの長さ・サイズ）。設計では「2時間・300MB」を仮定している | FR-03、FR-04 | 公式ドキュメントで確認。仮定と異なれば分割単位の選択肢を修正 | 開発者 | 未解消 |
| OQ-05 | 音声長ごとのピーク・メモリ使用量の実測値。目標値の決定 | FR-04、NFR-02、ADR-004、ADR-009 | 実測済み（docs/measurements.md）。残り：目標値（例：ピーク 2GB 以下）の決定と、Windows・Edge での再計測 | 開発者・管理者 | 一部解消 |
| OQ-06 | 利用料金の見積もり（時間あたりの単価と、月間の想定利用時間） | 運用 | Azure 料金ページで確認。試験の課金上限を決める | 管理者 | 未解消 |
| OQ-07 | 音声データの取り扱い規程（Azure のリージョン、保存期間、個人情報の扱い）。DXBE 環境の利用ルール | NFR-04、運用 | 社内の情報セキュリティ担当へ確認 | 管理者 | 未解消 |
| OQ-08 | 利用者の環境（Chrome・Edge の版、PCのメモリ量）の範囲 | NFR-01、NFR-02 | 利用予定者へのヒアリング | 管理者 | 未解消 |
