# 02 改修・デバッグ方法

## 1. 改修の基本手順（必ずこの順で行う）
1. **要件を決める**：何を変えるかを、docs/spec.md の要件番号（FR・NFR・UX）で指定する。該当がなければ新しい番号を振る。
2. **仕様を先に書く**：受け入れ基準（AC）を書く。既存の AC を変えるときは、理由を docs/decisions.md に残す。
3. **変更箇所を決める**：下の §2 の表で、どのファイルを直すかを確認する。
4. **実装する**：`src/` を編集する（`index.html` は直接編集しない）。
5. **単体テストを足す**：純粋関数の変更は、`test/unit/lib.test.js` に AC 番号つきのテストを足す。
6. **検証する**：`npm run verify`（build・単体テスト・秘密情報検査）を実行する。
7. **画面を確かめる**：`npm run e2e`（実ブラウザ、モック使用）を実行する。
8. **記録する**：報告書の対応表と、必要なら docs/decisions.md・docs/open-questions.md を更新する。

> 注意：`index.html` を直接編集すると、次の `npm run build` で消える。

## 2. 変更の種類ごとの作業場所
| 変更の内容 | 直す場所 | 追加で行うこと |
|---|---|---|
| 文言（エラーメッセージ） | `src/lib.js` の `friendlyError` | AC-UT-08 を更新 |
| 分割単位の選択肢を増やす | `src/index.html` の `<select id="splitMin">` | e2e の分割数の確認 |
| 既定の分割単位 | `config.example.js` の `defaultSegmentMinutes` | 画面の選択肢と一致しているか確認 |
| 再試行の条件 | `src/lib.js` の `isRetryable` | AC-UT-07 を更新 |
| 再試行の回数・待ち時間 | `src/index.html` の `MAX_ATTEMPTS` と `sleep(2000 * attempt)` | e2e の再試行（フェーズC）を確認 |
| 見出しの形式 | `src/lib.js` の `segmentHeader` | AC-UT-06 を更新。e2e の見出しの検査文字列も更新 |
| 区間の計算 | `src/lib.js` の `buildSegments` | AC-UT-05 を更新 |
| WAV の形式 | `src/lib.js` の `wavFromFloat` | AC-UT-03・04 を更新 |
| 送信先・ヘッダー・本文 | `src/index.html` の `callAzure` | 【仮定】の欄（OQ-01）を更新。モックも同じ形に合わせる |
| 応答の読み取り | `src/index.html` の `callAzure`（combinedPhrases） | モック（mock-server.js）も同じ形にする |
| 画面の部品・レイアウト | `src/index.html` の HTML と CSS | e2e の対象 ID を確認 |
| 保存ファイルの形式 | `src/index.html` の `saveText` | e2e の BOM 検査（AC-09b）を確認 |
| 試験用の模倣サーバー | `mock-server.js` | e2e のフェーズ C の仕組みを確認 |
| 秘密情報の検査 | `scripts/check-secrets.js` | `npm run check` で確認 |

## 3. 改修の例（手順の具体例）

### 例1：エラーメッセージを変える
1. `src/lib.js` の `friendlyError` の該当の `case` を変える。
2. `test/unit/lib.test.js` の AC-UT-08 の期待する文字列を変える。
3. `npm run verify` を実行する。
4. 変更を `docs/spec.md` の該当行（AC）に反映する。

### 例2：分割単位に「2分」を足す
1. `src/index.html` の `<select id="splitMin">` に `<option value="2">2分</option>` を足す。
2. `npm run build` と `npm run e2e` を実行する（分割数の表示が変わることを確認）。
3. 仕様の FR-05 の説明に選択肢を書き足す。

### 例3：送信先の応答の形が変わったとき（OQ-01 の解消後）
1. 実Azureの応答を1回だけ記録する（音声は短いもの）。
2. `src/index.html` の `callAzure` の読み取り部分を直す。
3. `mock-server.js` の応答も同じ形にする。
4. `npm run verify`、`npm run e2e` を実行する。
5. docs/open-questions.md の OQ-01 を「解消」にし、確定した値を書く。

## 4. デバッグの基本（ブラウザの開発者ツール）
1. `index.html` を `http://localhost:8000/index.html`（`python -m http.server 8000`）で開く。
2. `F12` で開発者ツールを開く。
3. 次の順で確認する。

| 見る場所 | 確認すること |
|---|---|
| Console（コンソール） | 赤いエラー（例：`Uncaught TypeError`）。行番号をたどる |
| Network（ネットワーク） | `transcriptions:transcribe` のリクエスト。ステータス（200・401・429 など）、Request Headers の `Ocp-Apim-Subscription-Key` の有無、Response の本文 |
| Sources（ソース） | `index.html` の行に**ブレークポイント**を置き、`run` や `callAzure` で止める |
| Elements（要素） | `#status`・`#errBox`・`#result` の表示内容 |
| Application（アプリケーション）※Chromium 系 | 通常は使わない（このツールはストレージを使わない） |

### ブレークポイントの置き場所（目安）
| 調べたいこと | 置く行 |
|---|---|
| 音声が読めない | `loadFile` の `decodeAudioData` の前後 |
| 区間の数が想定と違う | `run` の `buildSegments` の結果 |
| WAV が壊れている | `encodeSegment` の `rendered` の後 |
| 送信内容が違う | `callAzure` の `fetch` の直前 |
| 再試行されない | `callWithRetry` の `isRetryable(e)` の結果 |
| 途中で止まる | `run` の `for` の中（中止の判定の行） |

### Console での確認例
```javascript
// 区間の計算を確かめる（lib.js は window.AzureLib として見える）
AzureLib.buildSegments(3725, 600)
// 見出しを確かめる
AzureLib.segmentHeader({index:0, offset:0, duration:600})
// 再試行の判定
AzureLib.isRetryable({status: 429})
```

## 5. 症状から原因を探す
| 症状 | 最初に見る場所 | よくある原因 |
|---|---|---|
| 「設定未完了」と出る | config.js | apiKey が「ここにキーを入力」のまま |
| 開始ボタンが押せない | 状態文、config.js | 音声未読込、設定未完了、処理中 |
| 「読み込めませんでした」 | Console のデコードエラー | 未対応形式、破損ファイル |
| 分割数が 0 や NaN | `#splitMin` の値 | 選択肢に無い値（例：config の既定値と選択肢の不一致） |
| 401 の案内 | Network のヘッダー | キーの誤り、リージョンの誤り |
| 「Azureに接続できません」 | Network（失敗しているか）、Console（CORS） | endpoint の誤り、CORS、オフライン |
| 「再試行中」のまま進まない | Network の 429 の回数 | 利用上限。待つか、分割単位を変える |
| タイムアウト | Console、Network の時間 | 区間が長すぎる。分割単位を短くする |
| 結果が途中で止まる | status 欄、Network | 中止の誤作動、例外の握りつぶし（catch 内） |
| 保存したファイルの日本語が崩れる | 保存したファイルの先頭3バイト | BOM の欠落（saveText を確認） |
| 画面の表示が崩れる | 開発者ツールの端末表示（360px） | CSS の幅、固定の高さ |
| メモリ警告が出る | `memWarn` の数値 | 音声が長い。事前分割（docs/operations.md） |

## 6. 試験で調べる
- **単体テスト**：`npm test`。失敗した `not ok` の名前（AC番号）を見る。
- **画面試験**：`npm run e2e`。`[否]` の行の AC 番号を見る。`e2e_smoke.py` の該当フェーズを読む。
- **模倣サーバーで異常を再現**：`FAIL_EVERY=2 node mock-server.js`（429）。モックを止めれば接続エラー。
- **記録**：`npm run collect:e2e` で回収フォルダを作り、`report.md` と `manifest.json` を見る。

## 7. 過去に見つかった不具合（再発防止の記録）
| 内容 | 原因 | 対処 | 確認 |
|---|---|---|---|
| タイムアウトが「中止しました」と表示された | タイムアウトと利用者の中止を区別していなかった | `timedOut` の記録と `TimeoutError` を追加 | AC-UT-09、ブラウザで表示を確認 |
| 試験用設定で分割数が不正になりうる | 選択肢に「1分」が無かった | 「1分（試験用）」の選択肢を追加 | TC-05 |
| 3時間の音声でブラウザが落ちる | 音声全体を展開するため、メモリが不足 | 事前分割の運用を定めた（ADR-009） | docs/measurements.md |

## 8. 改修後の確認チェックリスト
- [ ] 要件番号と AC を書いた
- [ ] `src/` だけを編集した（index.html は build で生成）
- [ ] `npm run verify` が通った
- [ ] `npm run e2e` が 13/13 で通った（画面に関係する変更の場合）
- [ ] 秘密情報（APIキー）を `src/` や `index.html` に書いていない
- [ ] docs/spec.md、docs/decisions.md、報告書を更新した
