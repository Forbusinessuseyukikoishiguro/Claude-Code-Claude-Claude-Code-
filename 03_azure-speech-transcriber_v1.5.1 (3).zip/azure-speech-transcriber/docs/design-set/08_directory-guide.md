# 08 ディレクトリ説明

## 1. 全体の構成
```
azure-speech-transcriber/
├── index.html                 ★配布物（生成物。直接編集しない）
├── src/                       ★編集するソース
│   ├── index.html             画面と制御（テンプレート）
│   └── lib.js                 純粋関数（テスト対象）
├── build.js                   src/ から index.html を作る
├── config.example.js          設定の雛形（コミット対象）
├── config.js                  実際の設定（APIキー。コミットしない）※作成して使う
├── config.mock.js             試験用の設定（APIキー不要）
├── mock-server.js             Azure の応答を模倣するサーバー
├── make-test-wav.js           試験用 WAV を作る
├── TEST-PROCEDURE.md              手動試験の手順
├── README.md                  入口（ここから読む）
├── CLAUDE.md                  Claude Code への指示
├── package.json               npm のコマンドの定義
├── test/
│   ├── unit/lib.test.js       単体テスト
│   ├── sample-2min.wav        試験用音声（生成物。コミットしない）
│   └── results/               試験結果の回収先（コミットしない）
├── scripts/
│   ├── e2e_smoke.py           ブラウザ試験（Chromium）
│   ├── measure_memory.py      メモリ計測
│   ├── check-secrets.js       秘密情報の検査
│   ├── build-docx.js         Markdown の設計書を Word にまとめる
│   ├── collect-evidence.js    証跡の回収と報告書
│   └── windows/
│       ├── setup.ps1          Windows の初回セットアップ
│       └── collect.ps1        回収と zip 化
├── docs/
│   ├── 設計書一式/            本設計書（Markdown と Word）
│   ├── 仕様書.md              統合版の仕様書
│   ├── spec.md                要件と受け入れ基準（FR・NFR・AC）
│   ├── decisions.md           決定事項（ADR）
│   ├── open-questions.md      未確定事項（OQ）
│   ├── measurements.md        メモリ計測の記録
│   ├── operations.md          運用手順（事前分割）
│   ├── evidence-guide.md          証跡の回収手順
│   └── setup-guide.md  環境構築（初回・次回）
├── .claude/
│   ├── settings.json          Claude Code の権限（機密ファイルの読取禁止）
│   └── skills/evidence-collect/SKILL.md   回収のスキル
├── .github/workflows/ci.yml   GitHub Actions（自動検証）
├── .vscode/
│   ├── tasks.json             VS Code のタスク
│   └── extensions.json        推奨拡張機能
├── Dockerfile                 試験環境のイメージ
├── .dockerignore              イメージに入れないもの
├── .gitignore                 Git で追跡しないもの
├── .gitattributes             改行コードの扱い
└── .editorconfig              エディタの共通設定
```

★は、最初に目を通すべきもの。

## 2. 役割ごとの説明

### 2.1 配布物
| パス | 説明 | 注意 |
|---|---|---|
| index.html | ブラウザで開く本体。lib.js を埋め込み済み | build.js が作る。直接編集しない |
| config.js | APIキーなどの設定 | 利用者が作る。共有しない |

### 2.2 ソース
| パス | 説明 | 注意 |
|---|---|---|
| src/index.html | 画面の HTML、CSS、制御スクリプト | 制御の変更はここ |
| src/lib.js | 純粋関数（副作用なし） | 単体テストの対象 |
| build.js | マーカー `<!--@INLINE lib-->` を lib.js で置き換える | マーカーを消さない |

### 2.3 設定
| パス | 説明 | Git |
|---|---|---|
| config.example.js | 設定の雛形 | 追跡する |
| config.js | 実際の設定（APIキーを含む） | 追跡しない（.gitignore） |
| config.mock.js | 試験用（APIキー不要） | 追跡する |

### 2.4 試験
| パス | 説明 |
|---|---|
| test/unit/lib.test.js | 単体テスト（node:test） |
| scripts/e2e_smoke.py | 画面試験（フェーズ A〜E） |
| mock-server.js | 模倣サーバー（localhost:8787） |
| make-test-wav.js | 試験用音声を作る |
| TEST-PROCEDURE.md | 手動試験の手順（TC-01〜18） |
| test/results/ | 回収された結果（日付ごとのフォルダ） |

### 2.5 スクリプト（運用）
| パス | 説明 |
|---|---|
| scripts/check-secrets.js | APIキーの混入を検査（npm run check） |
| scripts/measure_memory.py | メモリを計測（npm run measure） |
| scripts/collect-evidence.js | 証跡を回収し、報告書を作る（npm run collect） |
| scripts/build-docx.js | Markdown の文書群を Word にまとめる（npm run docs:docx） |
| scripts/windows/setup.ps1 | Windows の初回セットアップ |
| scripts/windows/collect.ps1 | Windows の回収と zip 化 |

### 2.6 文書
| パス | 読む人 | 内容 |
|---|---|---|
| README.md | 全員 | 入口。最初に読む |
| docs/design-set/ | 開発者 | 設計の一式（00〜09） |
| docs/spec-integrated.md | 全員 | 統合版の仕様 |
| docs/spec.md | 開発者、試験 | 要件と受け入れ基準の一覧 |
| docs/decisions.md | 開発者 | 決めたことと理由 |
| docs/open-questions.md | 管理者、開発者 | まだ決まっていないこと |
| docs/measurements.md | 開発者 | 計測の記録 |
| docs/operations.md | 運用担当 | 長い音声の分割の手順 |
| docs/setup-guide.md | 全員 | 環境構築 |
| docs/evidence-guide.md | 試験担当 | 証跡の回収 |
| CLAUDE.md | Claude Code | 作業の約束、コマンド |

### 2.7 連携・環境
| パス | 説明 |
|---|---|
| .claude/ | Claude Code の権限とスキル |
| .github/workflows/ci.yml | push と pull request の自動検証（verify と e2e） |
| .vscode/ | 推奨拡張機能とタスク |
| Dockerfile、.dockerignore | 試験環境の再現（Docker） |
| .gitignore、.gitattributes、.editorconfig | Git と編集の共通設定 |

## 3. 生成されるもの（作られるファイル）
| 作るコマンド | 生成されるもの |
|---|---|
| `npm run build` | index.html |
| `npm run e2e` | 一時フォルダ（終了時に削除） |
| `npm run measure` | 一時フォルダ（音声）、docs/measurements.md への記録（手動で転記） |
| `npm run collect` | test/results/日時/（verify.log、manifest.json、report.md など） |
| `npm run docs:docx` | docs/design-set/design-set.docx（Word。要 `npm install`） |
| `make-test-wav.js` | test/sample-(分)min.wav |

## 4. 触ってはいけないもの
- index.html：生成物。直接編集すると build で消える。
- config.js、config.real.js：APIキーを含む。共有・コミットしない。
- test/results/、*.wav、*.zip：機密を含みうる。コミットしない。
- node_modules/、__pycache__/：生成物。コミットしない。

## 5. 新しいファイルを追加するときの置き場所
| 種類 | 置き場所 |
|---|---|
| 画面やロジックのコード | src/ |
| 純粋関数 | src/lib.js（テストを test/unit/ に追加） |
| 試験の補助 | scripts/ |
| Windows 用のスクリプト | scripts/windows/（改行は CRLF） |
| 仕様や決定の文書 | docs/ |
| 設計書の文書 | docs/design-set/（番号を付ける） |
