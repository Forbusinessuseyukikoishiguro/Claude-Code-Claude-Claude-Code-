# 01 ソースコード解説

## 1. 全体像
ツールは、次の5つの層でできている。

```
┌────────────────────────────────────────────┐
│ 画面（index.html の HTML 部分）            │  ボタン・表示・入力
├────────────────────────────────────────────┤
│ 制御（index.html の スクリプト部分）       │  開始・分割・再試行・中止・保存
├──────────────────────┬─────────────────────┤
│ 純粋関数（src/lib.js）│ 音声処理（ブラウザ） │  時間表示・WAV生成・区間計算・文言
│                      │ AudioContext        │  decodeAudioData・OfflineAudioContext
├──────────────────────┴─────────────────────┤
│ 通信（fetch）→ Azure Speech（または模倣）  │
└────────────────────────────────────────────┘
```

配布物は `index.html` の1ファイルだけである。開発時は `src/index.html`（テンプレート）と `src/lib.js` に分けて編集し、`node build.js` で `index.html` を生成する。

## 2. ファイルの役割
| ファイル | 役割 | 編集するか |
|---|---|---|
| `src/index.html` | 画面の HTML、CSS、制御スクリプト | ✅ |
| `src/lib.js` | 純粋関数（副作用なし） | ✅ |
| `index.html` | 生成物（配布物）。build.js が作る | ❌（直接編集しない） |
| `build.js` | テンプレートに lib.js を埋め込む | 必要時のみ |
| `config.example.js` | 設定の雛形 | ✅ |
| `config.js` | 実際の設定（APIキーを含む） | 利用者が作る |
| `config.mock.js` | 試験用の設定 | 試験時のみ |
| `mock-server.js` | Azure の応答を模倣するサーバー | 試験時のみ |
| `make-test-wav.js` | 試験用の WAV を作る | 試験時のみ |

## 3. src/lib.js（純粋関数）
入力だけで出力が決まる関数を集めている。ブラウザの API や通信を使わないため、Node.js で単体テストできる。

| 関数 | 役割 | 呼び出し元 |
|---|---|---|
| `fmtTime(sec)` | 秒を「hh:mm:ss」にする。不正値は 00:00:00 | index.html（情報表示、区間見出し） |
| `fmtSize(b)` | バイト数を「MB」または「KB」にする | index.html（情報表示） |
| `wavFromFloat(f32, rate)` | Float32 の値を 16bit PCM の WAV（ArrayBuffer）にする | encodeSegment |
| `buildSegments(durationSec, segSec)` | 区間の一覧（index・offset・duration・total）を作る | run |
| `segmentHeader(seg)` | 「--- 第N部（開始〜終了）---」の見出しを作る | run |
| `isRetryable(e)` | 再試行してよい失敗かを判定する | callWithRetry |
| `friendlyError(e)` | 失敗の種類ごとの日本語メッセージを作る | run |

この関数群は、`window.AzureLib`（ブラウザ）または `module.exports`（Node.js）として公開される。

## 4. src/index.html の制御スクリプト
スクリプトは1つの即時実行関数の中にあり、外部からは見えない。上から順に次のように並ぶ。

| 関数 | 役割 | 主な入出力 |
|---|---|---|
| `configOK()` | endpoint と apiKey が設定済みか | 真偽値 |
| `setProgress(done, total, text)` | 進捗バーと状態文を更新 | — |
| `enableOutputs(on)` | コピー・保存ボタンの有効化 | — |
| `setBusy(b)` | 処理中の画面の操作可否を一括で切り替える | — |
| `updateEstimate()` | 分割数の目安を表示 | — |
| `loadFile(file)` | 音声を検査し、16kHz で展開して情報を表示 | 入力: File、状態: `source` |
| `encodeSegment(off, dur)` | 区間を 16kHz・モノラルの WAV Blob にする | 出力: Blob |
| `callAzure(wav, outerSignal)` | 1区間を Azure へ送り、テキストを返す | 出力: 文字列 |
| `sleep(ms, signal)` | 待機（中止に応じる） | — |
| `callWithRetry(wav, signal)` | 一時的な失敗を最大3回まで再試行 | 出力: 文字列 |
| `run()` | 分割 → 変換 → 送信 → 結合の全体制御 | 状態: `ui.result`、`parts` |
| `copyText()` | 結果をクリップボードへ | — |
| `saveText()` | 結果を BOM 付き .txt で保存 | — |

主な状態変数は次のとおり。
- `source`：デコード済みの AudioBuffer（メモリの大部分を占める）。
- `fileName`：保存名に使う元のファイル名。
- `abortCtl`：中止ボタン用の AbortController（処理中以外は null）。
- `busy`：処理中の印。二重実行を防ぐ。

## 5. 処理の流れ（1回の文字起こし）
1. 利用者がファイルを選ぶ → `loadFile`：拡張子と MIME を検査し、`decodeAudioData` で展開する。
2. 利用者が分割単位を選び、開始を押す → `run`。
3. `run` は `buildSegments` で区間一覧を作り、区間ごとに次を繰り返す。
   - `encodeSegment`：区間を WAV にする。
   - `callWithRetry` → `callAzure`：送信する。失敗時は `isRetryable` で再試行を判定する。
   - 結果を `segmentHeader` の見出し付きで `parts` に追加し、結果欄を更新する。
4. 全区間が終わると、状態を「完了しました」にし、コピーと保存を有効にする。
5. 途中で中止・失敗した場合も、`parts` にある分は残す。

## 6. 通信の詳細（callAzure）
- URL：`{endpoint の末尾の/を除いたもの}/speechtotext/transcriptions:transcribe?api-version={apiVersion}`
- ヘッダー：`Ocp-Apim-Subscription-Key`
- 本文（multipart）：`audio`（WAV）と `definition`（JSON。言語と不適切語フィルタ）
- 応答：`combinedPhrases` の `text` を改行で連結する。
- タイムアウト：`requestTimeoutMs` を超えると、`timedOut` を立てて中止し、`TimeoutError` として扱う。利用者の中止（AbortError）とは区別する。

> 【仮定】apiVersion、項目名、応答の形は、公式で確認していない（OQ-01）。

## 7. 読むときの順序（初めての人向け）
1. `src/lib.js`：純粋関数を読む（短く、独立している）。
2. `test/unit/lib.test.js`：関数の期待する動作を確認する。
3. `src/index.html` の `loadFile` → `run` → `callAzure` → `callWithRetry` の順に読む。
4. `mock-server.js`：送信先の応答の形を確認する。
5. `scripts/e2e_smoke.py`：画面の操作の流れを確認する。

## 8. 設計上の注意点（コードを読むときに知っておくこと）
- 表示に使う文字列は `textContent` で入れる。`innerHTML` は使わない（安全性）。
- API キーは `config.js` にだけ書く。`npm run check` が他のファイルの混入を検出する。
- 純粋関数に副作用を入れない。ブラウザ API が必要な処理は index.html 側に置く。
- 区間は直列に送る（同時送信しない）。途中の失敗で、それまでの結果を失わない。
