# 05 実装仕様書

## 1. 実装の約束
| 項目 | 約束 |
|---|---|
| 言語 | HTML5、CSS、JavaScript（ES2017 以上。async/await、?? を使う）|
| 外部ライブラリ | 使わない |
| インデント | スペース2つ（.editorconfig） |
| 改行 | LF（.gitattributes。.ps1 は CRLF） |
| 文字コード | UTF-8 |
| 表示 | `textContent` を使う。`innerHTML` を使わない |
| 秘密情報 | APIキーは config.js のみ |
| コメント | 関数の目的・引数・戻り値を書く。要件番号（FR・AC）を書く |
| 命名 | 関数は動詞で始める（loadFile、callAzure）。定数は UPPER_SNAKE_CASE（MAX_ATTEMPTS）|

## 2. ファイル別の仕様

### 2.1 src/lib.js
| 関数 | 引数 | 戻り値 | 仕様 | 要件 |
|---|---|---|---|---|
| fmtTime | sec: 数値 | 文字列 | 有限で正、かつ 1e9 未満の数は小数点以下を切り捨て、それ以外は 0。出力は常に「hh:mm:ss」（各部は2桁）（1.4） | FR-08 |
| fmtSize | b: 数値 | 文字列 | 1048576 以上は「x.x MB」（小数1桁）、それ未満は「n KB」（最低 1 KB）。NaN・負数・無限大は「不明」（1.4） | FR-01 |
| wavFromFloat | f32: Float32Array、rate: 数値 | ArrayBuffer | 44バイトのヘッダー、PCM、モノラル、16bit。範囲外は ±1 に収める | FR-07 |
| buildSegments | durationSec、segSec | 配列 | 上記 3.2 の規則。区間数は ceil(全長 ÷ 分割単位 − 1e-6)（浮動小数点の誤差を許容）。不正値は空配列（1.4） | FR-03、FR-05 |
| segmentHeader | seg: 区間 | 文字列 | 「--- 第(index+1)部（開始〜終了）---」| FR-06 |
| isRetryable | e: 例外 | 真偽値 | TypeError・429・5xx は真。AbortError・TimeoutError・InvalidResponse は偽 | FR-10 |
| friendlyError | e: 例外 | 文字列 | InvalidResponse、TimeoutError、TypeError、400、401/403、413、429、その他の順に判定 | FR-10 |

公開：`window.AzureLib` と `module.exports` に上記7関数を入れる。

### 2.2 src/index.html（テンプレート）
#### 2.2.1 定数
| 名前 | 値 | 意味 |
|---|---|---|
| TARGET_RATE | 16000 | 展開とWAVの周波数 |
| MAX_ATTEMPTS | 3 | 試行回数の上限 |
| 待ち時間の係数 | 2000 | 再試行の待ち（ミリ秒）|
| 既定の requestTimeoutMs | 300000 | config に無い場合の既定値 |

#### 2.2.2 DOM 要素（ID）
| ID | 要素 | 操作 |
|---|---|---|
| dropArea | div | ドラッグの見た目（over クラス） |
| file | input type=file | change で loadFile |
| fileInfo | p | 情報の表示 |
| splitMin | select | change で updateEstimate |
| estimate | span | 分割数の表示 |
| memWarn | div | メモリ警告（hidden で切り替え） |
| start | button | click で run |
| cancel | button | click で abortCtl.abort() |
| prog | progress | 進捗（hidden で切り替え） |
| status | div（aria-live） | 状態文 |
| errBox | div（role=alert） | エラー文（hidden で切り替え） |
| result | textarea（readonly） | 結果 |
| copy、save | button | copyText、saveText |

#### 2.2.3 関数の仕様
| 関数 | 入力 | 出力・副作用 | 例外・注意 |
|---|---|---|---|
| configOK | — | 真偽値 | endpoint が http(s) の絶対URLでなければ偽（1.4）。apiKey に「ここに」を含むと偽 |
| setProgress | done、total、text | prog.max、prog.value、status | — |
| enableOutputs | on | copy、save の disabled | — |
| setBusy | b | busy、start、cancel、file の状態 | start は configOK と source を見る |
| updateEstimate | — | estimate の文字 | source が無いと空 |
| loadFile | file | source、fileName、表示 | busy 中は何もしない。読み込みに通し番号（loadSeq）を付け、後から始まった読み込みだけを採用（1.4）。例外は握って案内に変える |
| encodeSegment | offsetSec、durSec | Blob（audio/wav） | source が必要 |
| callAzure | wav、outerSignal | 文字列 | 失敗時は status（HTTP）、detail（先頭200字）を持つ Error。本文の読み取り（通信）は await res.text() で行い、JSON の解析の失敗は InvalidResponse（1.4）。タイムアウトは TimeoutError |
| sleep | ms、signal | Promise | 中止で AbortError |
| callWithRetry | wav、signal | 文字列 | 最後の例外を投げる |
| run | — | ui.result、状態、結果の保存可否 | 二重実行しない。区間が0件（分割単位が不正）なら送信せず案内（1.4）。認識結果が空の区間は「この区間に認識結果はありませんでした」（1.4）。finally で busy を解除 |
| copyText | — | クリップボードへ、status | 失敗時は選択 |
| saveText | — | ダウンロード | 名前は拡張子を除いた名前＋.txt |

### 2.3 build.js
| 項目 | 内容 |
|---|---|
| 入力 | src/index.html、src/lib.js |
| 出力 | index.html |
| 処理 | マーカー `<!--@INLINE lib-->` を `<script>` 付きの lib.js の内容で置き換える |
| 失敗 | マーカーが無い場合は例外で止まる |
| 置換の方式 | 関数形式（`$` の解釈を避けるため） |

### 2.4 mock-server.js
| 項目 | 仕様 |
|---|---|
| 待ち受け | localhost:8787 |
| 既定の鍵 | `mock-key` |
| CORS | Access-Control-Allow-Origin: *。OPTIONS は 204 |
| 経路 | POST `/speechtotext/transcriptions:transcribe` 以外は 404 |
| 認証 | ヘッダーの鍵が一致しなければ 401 |
| 失敗の模倣 | 環境変数 FAIL_EVERY の回数ごとに 429 |
| 正常応答 | 1.2 秒後に `combinedPhrases` を返す（【モック】と受信MB、通番を含む）|

### 2.5 make-test-wav.js
| 項目 | 仕様 |
|---|---|
| 引数 | 分（省略時は 2） |
| 出力 | test/sample-(分)min.wav（16kHz、モノラル、16bit、440Hz の音） |

### 2.6 scripts/check-secrets.js
| 検査 | 内容 |
|---|---|
| 対象 | index.html、src/index.html、src/lib.js、config.example.js |
| 規則1 | `apiKey: "値"` の値が、プレースホルダー（空、「ここにキーを入力」、mock-key、wrong-key）以外なら NG |
| 規則2 | 32桁の16進数が含まれたら NG |

### 2.7 scripts/e2e_smoke.py
| フェーズ | 操作 | 記録する AC |
|---|---|---|
| A 正常系 | 投入、分割単位の変更、開始、保存 | AC-01a、AC-05、AC-03、AC-06、AC-08、AC-09a、AC-09b、UX-01 |
| B 認証誤り | 鍵を wrong-key にして開始 | AC-10b（401） |
| C 再試行 | FAIL_EVERY=2 で起動して開始 | AC-10a |
| D 中止 | 1区間の完了後に中止 | AC-11 |
| E 接続不可 | モックを停止して開始 | AC-10b（接続） |
| 共通 | コンソールエラーの確認 | AC-10b（想定外のエラーなし） |

- 本番の config.js は使わない。一時フォルダに試験用の設定を作る。
- 出力行の形式：`[合] AC-xx 内容` または `[否] AC-xx 内容`。回収スクリプトがこの形式を読む。

### 2.8 scripts/measure_memory.py
| 項目 | 仕様 |
|---|---|
| 引数 | `[wav\|mp3] 分 [分 ...]` |
| 音声の生成 | wav は標準ライブラリで生成。mp3 は ffmpeg（lavfi の sine）で生成 |
| 計測 | 投入から完了までの、ブラウザの子プロセスの RSS 合計を 0.2 秒ごとに記録 |
| 単位 | 測定ごとに新しいブラウザを起動 |

### 2.9 scripts/collect-evidence.js
| 項目 | 仕様 |
|---|---|
| 出力先 | test/results/YYYY-MM-DD_HHMM/ |
| 手順 | `npm run verify`、（--e2e で）e2e、（--measurements で）計測結果のコピー |
| 生成物 | verify.log、e2e.log、manifest.json、report.md、git-status.txt、成果物の控え |
| 判定 | 「不合格」「未完了」「自動試験は合格（人の確認が必要）」のいずれか |
| 終了コード | 不合格または秘密情報の問題があれば 1 |
| 禁止 | config.js、config.real.js、*.wav を回収しない |

## 3. 実装時の注意（既知の落とし穴）
| 注意 | 理由 |
|---|---|
| select の選択肢と config の既定値を合わせる | 無い値は選ばれず、分割数が NaN になる |
| 中止（AbortError）とタイムアウト（TimeoutError）を区別する | 表示が変わる（過去の不具合） |
| decodeAudioData は ArrayBuffer を消費する | 同じバッファを二度使わない |
| OfflineAudioContext の長さは整数にする（ceil） | 端数の欠落を防ぐ |
| 区間の描画の後は、結果の文字列だけを保持する | メモリを抑える |
| BOM は保存時だけ付ける | 画面の結果欄に BOM を入れない |

## 4. 変更の受け入れ条件（実装者の確認）
- [ ] 上記の仕様どおりに動く
- [ ] 単体テストが通る（npm test）
- [ ] build 後の index.html が最新
- [ ] 秘密情報の検査が通る（npm run check）
- [ ] 画面に関係する変更は e2e が通る（npm run e2e）
