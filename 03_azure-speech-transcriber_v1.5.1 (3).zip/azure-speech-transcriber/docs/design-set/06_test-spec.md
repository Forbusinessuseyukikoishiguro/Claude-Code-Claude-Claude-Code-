# 06 テスト仕様書

## 1. 試験の目的
- 受け入れ基準（AC、docs/spec.md）を満たすことを確認する。
- 変更による不具合（回帰）を早く見つける。
- 試験の結果を、再現できる形で記録する（証跡）。

## 2. 試験の階層
| 階層 | 手段 | 対象 | 件数（現行） | 実行コマンド |
|---|---|---|---|---|
| 単体 | node:test | src/lib.js の関数 | 23 | `npm test` |
| 静的検査 | 秘密情報の検査 | 配布対象のファイル | 2規則 | `npm run check` |
| ビルド | build.js | index.html の生成 | 1 | `npm run build` |
| 画面（自動） | Python＋Chromium＋モック | 画面の操作と表示 | 13 | `npm run e2e` |
| 画面（手動） | TEST手順書 | 操作性、表示、ドロップ | 18（TC-01〜TC-18） | 手順書に従う |
| 性能 | Chromium＋計測 | メモリ | 音声の長さごと | `npm run measure -- mp3 60` |
| 実環境 | 実Azure | 応答、CORS、課金 | 1（1分・1回） | 手順書 §9 |
| 一括 | 回収 | 上記の結果の記録 | — | `npm run collect:e2e` |

## 3. 単体試験（AC-UT）
| ID | 対象 | 入力 | 期待する結果 | 要件 |
|---|---|---|---|---|
| AC-UT-01a | fmtTime | 3725、3600、0、59.9 | 01:02:05、01:00:00、00:00:00、00:00:59 | FR-08 |
| AC-UT-01b | fmtTime | NaN、Infinity、undefined、−5 | すべて 00:00:00 | FR-08 |
| AC-UT-02 | fmtSize | 12582912、1048576、500、10240 | 12.0 MB、1.0 MB、1 KB、10 KB | FR-01 |
| AC-UT-03 | wavFromFloat | 100 サンプル、16000Hz | 長さ 244 バイト、RIFF/WAVE、PCM、モノラル、16000Hz、16bit、データ長 200 | FR-07 |
| AC-UT-04 | wavFromFloat | [2, −2, 0] | 32767、−32768、0 | FR-07 |
| AC-UT-05a | buildSegments | (3725, 600) | 7区間。最後は offset 3600、duration 125。index は 0〜6 | FR-03 |
| AC-UT-05b | buildSegments | (600, 600)、(0, 600)、(100, 0) | 1区間（600秒）、空、空 | FR-03 |
| AC-UT-06 | segmentHeader | index 0、offset 0、duration 600 | 「--- 第1部（00:00:00〜00:10:00）---」 | FR-06 |
| AC-UT-07 | isRetryable | TypeError、429、500、503、400、401、403、AbortError、undefined | 順に 真、真、真、真、偽、偽、偽、偽、偽 | FR-10 |
| AC-UT-08 | friendlyError | TypeError、401、429、413、418（detail 'x'） | 「接続」、「401」、「429」、「分割単位」、「418」と「x」を含む | FR-10 |
| AC-UT-09 | isRetryable・friendlyError | TimeoutError | 再試行しない。「タイムアウト」を含む | FR-10 |

実行結果の例（現行）：23件すべて合格。

## 4. 画面試験（AC、自動）
| フェーズ | 手順 | 合否の基準 | AC |
|---|---|---|---|
| A-1 | 2分の WAV を投入 | 「02:00」と「MB」を含む | AC-01a |
| A-2 | 分割単位を 1 分、次に 10 分にする | 「2 件」「1 件」の表示 | AC-05 |
| A-3 | 1分で開始 | 「第1部（00:00:00〜00:01:00）」と第2部の見出し。【モック】が2件 | AC-03、AC-06、AC-08 |
| A-4 | 保存 | 保存名が sample-2min.txt。先頭3バイトが EF BB BF | AC-09a、AC-09b |
| A-5 | 3操作の完了 | 上記の操作だけで完了 | UX-01 |
| B | 鍵を wrong-key にして開始 | 「401」と「APIキー」を含む案内 | AC-10b |
| C | FAIL_EVERY=2 で起動して開始 | 「再試行中」の表示があり、最後は「完了しました」、【モック】が2件 | AC-10a |
| D | 1区間の完了後に中止 | 「中止しました（1/2部」、結果が残る、コピーが有効 | AC-11 |
| E | モックを停止して開始 | 「接続できません」を含む案内 | AC-10b |
| 共通 | コンソールの確認 | 想定外のエラーがない（401・429・リソース読込失敗は除外） | AC-10b |

実行結果の例（現行）：13件すべて合格。

### 4.1 試験の仕組み
- 本番の config.js を使わない。一時フォルダに index.html と試験用設定（config.mock.js の内容を config.js として）を置く。
- モックサーバーと簡易 HTTP サーバーを起動し、終了時に停止する。
- 終了コード：全件合格で 0、不合格があれば 1。

## 5. 手動試験（TC-01〜TC-18）
TEST-PROCEDURE.md の第5章に詳細がある。自動化していない項目は、次のとおり。

| TC | 内容 | 自動化 |
|---|---|---|
| TC-01 | 設定未完了の表示 | 未（自動の範囲外） |
| TC-02 | 音声以外の拒否 | 未 |
| TC-04 | ドラッグ＆ドロップ | 未 |
| TC-09・TC-10 | コピー、保存（メモ帳で確認） | 保存は自動、コピーは未 |
| TC-15 | メモリ警告（memWarnMB を下げて確認） | 未 |
| TC-16 | フォーカス枠 | 未 |
| TC-17 | 360px 表示 | 未 |
| TC-18 | コンソールのエラー | 一部（e2e の共通検査） |

## 6. 性能試験（メモリ）
| 項目 | 方法 | 記録先 |
|---|---|---|
| 音声の長さごとのピーク | `npm run measure -- mp3 10 30 60` | docs/measurements.md |
| 180分の失敗 | `npm run measure -- mp3 180`（環境の総メモリに依存） | docs/measurements.md |
| 事前分割後の1ピース | 10分の 16kHz モノラル WAV（ffmpeg で作成） | docs/measurements.md |

> 目標値は未決定（OQ-05）。決定後は、判定の基準をこの欄に書く。

## 7. 実環境試験（TST-02）
| 項目 | 方法 | 確認すること |
|---|---|---|
| 1分の音声 | 本番の config.js で1回だけ実行 | 結果が返る。api-version と項目名を受け付ける |
| CORS | ブラウザの Console と Network | エラーが出ない（http://localhost で確認） |
| 応答の形 | Network の Response | combinedPhrases の形。違えば src/index.html を直す |
| 課金 | Azure ポータル | 利用量が想定どおり（1分程度） |

結果は docs/open-questions.md（OQ-01・OQ-02）に記録する。

## 8. 試験環境
| 項目 | 内容 |
|---|---|
| OS | Windows 10/11（利用者環境）、Linux（開発・試験の実績） |
| ブラウザ | Chromium 153（試験の実績）。Chrome・Edge は未試験（NFR-01） |
| Node.js | 22 |
| Python | 3.12 以上、playwright |
| 補助 | ffmpeg（mp3 生成、分割）|
| Docker | 任意。Dockerfile で同じ条件を再現（実行は未検証） |

## 9. 合否の判定
| 判定 | 条件 |
|---|---|
| 合格 | 単体、画面（自動）が全件合格。手動の重要項目（TC-03、TC-07、TC-08、TC-10、TC-12、TC-13、TC-14）が合格 |
| 条件付き合格 | 重要項目は合格。軽微な表示の不具合のみ |
| 不合格 | 重要項目に1つでも不合格 |

> 自動判定（回収スクリプト）は「候補」。最終判定は人が行う（report.md §6）。

## 10. 不具合の記録
| 項目 | 記録する内容 |
|---|---|
| 番号 | 不具合の番号（BUG-yyyymmdd-nn） |
| 発生した試験 | AC 番号、TC 番号 |
| 現象 | 画面の表示、Console のエラー |
| 再現手順 | 操作の手順（最小限） |
| 原因 | 判明した範囲で |
| 対処 | 修正したファイル、追加したテスト |
| 確認 | 再試験の結果 |

## 11. 試験の追加方法
1. 要件番号（FR・NFR）と AC を決める（docs/spec.md）。
2. 単体で確かめられるもの（純粋関数）は `test/unit/lib.test.js` に `test("AC-UT-xx ...")` を書く。
3. 画面の流れは `scripts/e2e_smoke.py` のフェーズに追加する。出力行は `[合] AC-xx 内容` の形式にする。
4. 試験の表（本書の §3、§4）を更新する。
5. `npm run verify` と `npm run e2e` を実行する。

## 12. デバッグのための試験の使い方
- 単体：`node --test test/unit/lib.test.js` で、個別の失敗を確認する。
- 画面：`python scripts/e2e_smoke.py` の出力で、どのフェーズで失敗したかを見る。
- 模倣サーバーの異常：`FAIL_EVERY=2 node mock-server.js`。
- 記録：`npm run collect:e2e` で、報告書（report.md）と manifest.json を作る。


## 13. 追加した試験（1.4）
| 区分 | 件数 | 目的 | 実体 |
|---|---|---|---|
| 単体（境界・性質） | 12 | 浮動小数点、不正値、乱数による性質の確認 | test/unit/lib.edge.test.js |
| 結合 | 7（I-01〜I-07） | 機能どうしの連携、中止と再実行、再試行、途中失敗 | test/browser/suite.py |
| 壊しに行く | 24（A-01〜A-24） | 不正なファイル、不正な応答、連打、競合、注入 | test/browser/suite.py |
| モンキー | 3（M-01〜M-03、各60手） | ランダム操作で不変条件を確認 | test/browser/suite.py |

実行：`npm test`（単体）、`python3 test/browser/suite.py`（ブラウザ）、`npm run e2e`（画面の総合）。
結果の記録と Excel 化：`python3 scripts/run_all_tests.py`、`python3 scripts/make_checklist_xlsx.py`。


## 14. 1.4 の実行結果（記録）
| 区分 | 件数 | 合格 | 不合格 |
|---|---|---|---|
| 単体（U） | 23 | 23 | 0 |
| 総合・画面（S、既存 e2e） | 13 | 13 | 0 |
| 結合（I） | 7 | 7 | 0 |
| 壊しに行く（A） | 24 | 24 | 0 |
| モンキー（M） | 3 | 3 | 0 |
| 合計 | 70 | 70 | 0 |

環境：Linux、Node.js 22、Python 3、Chromium（Playwright）。実Azure・Edge・Windows では未実行。
試験で見つけた不具合（11件）と、仕様の矛盾（8件）、直せないもの（8件）は、試験チェックリスト（Excel）と docs/test-report/ を参照。
