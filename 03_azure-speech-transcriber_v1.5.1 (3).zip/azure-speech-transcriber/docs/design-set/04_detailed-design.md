# 04 詳細設計書

## 1. 設計の方針
1. **配布は1ファイル**：`index.html` 単体で動く（NFR-05）。
2. **ロジックは分けて試験する**：純粋関数を `src/lib.js` に置き、単体テストできるようにする（ADR-005）。
3. **通信は直列**：区間を1つずつ送る（ADR-006）。
4. **失敗しても結果を残す**：途中の失敗・中止でも、完了した区間は画面に残す。
5. **秘密情報を分離する**：APIキーは config.js だけに置く（NFR-04）。

## 2. 構成
### 2.1 構成図（論理）
```
利用者
  │ 操作（ファイル、分割単位、開始、中止、コピー、保存）
  ▼
┌──────────────────────────── index.html ────────────────────────────┐
│ UI 層      : DOM 要素の表示・操作（textContent のみ）              │
│ 制御層     : loadFile / run / callWithRetry / callAzure / 出力      │
│ 音声層     : AudioContext.decodeAudioData / OfflineAudioContext     │
│ 純粋関数   : window.AzureLib（src/lib.js を埋め込み）              │
└──────────────┬─────────────────────────────────────────────────────┘
               │ fetch（POST, multipart）
               ▼
     Azure Speech（Fast transcription）  または  mock-server.js（試験）
```

### 2.2 配置
| 配置 | 内容 |
|---|---|
| 利用者のPC（ブラウザ） | index.html、config.js |
| Azure | Speech リソース（利用者の契約） |
| 開発者のPC | 開発環境（VS Code、Node.js、Python、Git） |
| GitHub（任意） | ソースの保管、CI による自動検証 |

## 3. 処理の詳細

### 3.1 読み込み（loadFile）
| 手順 | 内容 | 失敗時 |
|---|---|---|
| 1 | 処理中なら何もしない | — |
| 2 | 表示をリセットし、開始を無効にする | — |
| 3 | 音声か判定（MIME `audio/*` または拡張子）| 「音声ファイルを選択してください。」 |
| 4 | `arrayBuffer` を読み、`AudioContext({sampleRate:16000})` で `decodeAudioData` | 「読み込めませんでした」 |
| 5 | 展開後のメモリ量（秒数×チャンネル数×4）を計算し、しきい値と比べる | 警告を表示（失敗ではない） |
| 6 | 情報（名前、容量、再生時間）と分割数の目安を表示 | — |

### 3.2 区間の作成（buildSegments）
- 区間数 = ceil(全長 ÷ 分割単位)。
- 各区間：`offset = i × 分割単位`、`duration = min(分割単位, 全長 − offset)`。
- 境界：全長が 0 以下、または分割単位が 0 以下なら空の配列（区間なし）。

### 3.3 区間の変換（encodeSegment → wavFromFloat）
| 項目 | 値 |
|---|---|
| 出力 | モノラル、16000Hz、16bit PCM、RIFF/WAVE |
| 描画 | OfflineAudioContext(1, ceil(duration × 16000), 16000)、start(0, offset, duration) |
| クリッピング | −1〜1 に収めてから Int16 に変換（負は×0x8000、正は×0x7fff） |
| ヘッダー長 | 44 バイト。データ長は 2 × サンプル数 |

### 3.4 送信と再試行（callAzure、callWithRetry）
| 項目 | 内容 |
|---|---|
| 試行回数 | 最大 3（初回を含む） |
| 再試行する | TypeError（通信失敗）、429、5xx |
| 再試行しない | 400、401、403、AbortError（中止）、TimeoutError（タイムアウト） |
| 待ち時間 | 2000 × 試行回数（ミリ秒）。中止に応じて途中で打ち切る |
| タイムアウト | requestTimeoutMs（既定 300000）。超過で TimeoutError |

### 3.5 全体の制御（run）
1. 設定と音声の有無、処理中でないことを確認する。
2. 区間一覧を作る。`parts` と結果欄を空にする。
3. 区間ごとに：中止の確認 → 変換 → 送信（再試行あり）→ 見出し付きで追加 → 結果欄を更新 → 進捗を更新。
4. 正常終了：「完了しました（n部）」。コピーと保存を有効にする。
5. 中止：「中止しました（k/n部まで完了）」。完了分があれば、コピーと保存を有効にする。
6. エラー：`friendlyError` の文言を表示。完了分があれば、その件数も表示する。
7. 最後に、処理中の状態を解除する（finally）。

### 3.6 出力（copyText、saveText）
- コピー：Clipboard API。失敗時は結果欄を選択状態にして、手動コピーを促す。
- 保存：Blob（text/plain; charset=utf-8）の先頭に BOM（U+FEFF）を付け、`<元の名前>.txt` として保存する。

## 4. 状態遷移
```
            ファイル投入            開始               完了
  [初期] ───────────▶ [読込中] ──▶ [準備完了] ──▶ [処理中] ──▶ [完了]
                          │ 失敗      ▲                │  │
                          ▼           │ 再投入          │  │ 中止
                       [エラー] ◀────┘                 │  ▼
                          ▲                             │ [中止]
                          └───────── 失敗（区間で）─────┘
```
| 状態 | 開始ボタン | 中止 | ファイル選択 | コピー・保存 |
|---|---|---|---|---|
| 初期 | 無効 | 無効 | 有効 | 無効 |
| 準備完了 | 有効（設定済みの場合） | 無効 | 有効 | 無効 |
| 処理中 | 無効 | 有効 | 無効 | 無効 |
| 完了 | 有効 | 無効 | 有効 | 有効 |
| 中止・エラー | 有効 | 無効 | 有効 | 完了分があれば有効 |

## 5. データ設計
### 5.1 設定（window.APP_CONFIG）
| キー | 型 | 既定値 | 用途 |
|---|---|---|---|
| endpoint | 文字列 | 例：https://japaneast.api.cognitive.microsoft.com | 送信先 |
| apiKey | 文字列 | 「ここにキーを入力」 | 認証 |
| apiVersion | 文字列 | 2024-11-15 | URL の api-version |
| locale | 文字列 | ja-JP | 認識言語 |
| defaultSegmentMinutes | 数値 | 10 | 分割単位の初期値 |
| memWarnMB | 数値 | 1500 | メモリ警告のしきい値 |
| requestTimeoutMs | 数値 | 300000 | 1リクエストの上限 |

### 5.2 区間（Segment）
| 項目 | 型 | 意味 |
|---|---|---|
| index | 整数 | 0 から始まる番号 |
| offset | 秒（数値） | 元の音声での開始位置 |
| duration | 秒（数値） | 区間の長さ |
| total | 整数 | 区間の総数 |

### 5.3 結果の形式（テキスト）
```
--- 第1部（00:00:00〜00:10:00）---
（認識されたテキスト。文ごとに改行）

--- 第2部（00:10:00〜00:20:00）---
（認識されたテキスト）
```
区間どうしは空行で区切る。

### 5.4 Azure への送信（論理）
| 項目 | 形式 |
|---|---|
| メソッド | POST |
| URL | `{endpoint}/speechtotext/transcriptions:transcribe?api-version={apiVersion}` |
| ヘッダー | `Ocp-Apim-Subscription-Key: {apiKey}` |
| 本文 | multipart/form-data：`audio`（WAV）、`definition`（`{"locales":["ja-JP"],"profanityFilterMode":"None"}`） |
| 応答 | `{"combinedPhrases":[{"text":"..."}], ...}`（【仮定】OQ-01） |

## 6. エラー設計
| 種類 | 検出 | 文言の作り | 再試行 |
|---|---|---|---|
| 読み込み失敗 | decodeAudioData の例外 | 固定文言 | なし |
| 設定の不備 | configOK | 固定文言 | 開始不可 |
| HTTP エラー | res.ok が偽 | 状態コードごとの文言（friendlyError） | 429・5xx のみ |
| 通信失敗 | TypeError | 接続の確認を促す文言 | 最大3回 |
| タイムアウト | timedOut の記録 | 「時間内に返りませんでした」 | なし |
| 中止 | AbortError | 「中止しました」 | なし |
| 想定外 | 上記以外 | 例外のメッセージ | なし |

## 7. 性能・メモリ設計
- **音声全体の展開**：`decodeAudioData` は音声全体を展開するため、メモリは長さに比例する（実測は docs/measurements.md）。
- **区間の描画**：区間ごとに OfflineAudioContext を作るため、追加のメモリは区間の長さに比例する。
- **直列処理**：同時に保持する区間は1つ。
- **16kHz での展開**：送信形式と揃え、展開後のデータを減らす（ADR-008。効果は限定的）。
- **運用対策**：長い音声は事前に 10 分のピースに分割する（ADR-009）。

## 8. セキュリティ設計
| 脅威 | 対策 |
|---|---|
| APIキーの混入（ソース、リポジトリ） | config.js に限定。.gitignore と .dockerignore で除外。npm run check で検出 |
| 結果の画面への注入（XSS） | 表示は textContent のみ。innerHTML を使わない |
| 音声の漏えい | 外部送信の注意を画面に表示。社内規程に従う（OQ-07） |
| 試験での課金 | モックで試験。実Azure は 1分・1回に限定（TST-02） |
| 配布物の混入 | zip の作成時に、config.js・音声・結果を除外。検査で確認 |

## 9. 配布と構成管理
- 生成：`npm run build` が `src/index.html` と `src/lib.js` から `index.html` を作る。
- 検証：`npm run verify`（build、単体テスト、秘密情報検査）。
- 画面試験：`npm run e2e`（実ブラウザ、モック）。
- 記録：`npm run collect`（回収フォルダと報告書）。
- 版：docs/spec.md の変更履歴、Git のコミット。

## 10. 試験との対応
| 設計要素 | 試験 |
|---|---|
| lib.js の各関数 | 単体テスト AC-UT-01〜09 |
| 画面の流れ、再試行、中止、エラー、保存 | e2e フェーズ A〜E（13件） |
| 操作性、表示 | 手動試験 TC-01〜TC-18（TEST手順書） |
| 実Azure の応答 | TST-02（未実施） |
