# 07 VS Code 手順書（初回と次回）

対象：Windows 10/11、VS Code、Git、Node.js 22、Python 3.12、（任意）Docker Desktop。
詳細な導入手順は `docs/setup-guide.md` を参照する。本書は、VS Code で行う操作を中心に書く。

---

## A. 初回（一度だけ）

### A-1 環境を確認する
1. 次のコマンドを PowerShell で実行し、すべてバージョンが表示されることを確認する。
   ```powershell
   git --version
   node -v
   python --version
   ```
2. Python が表示されない、または Microsoft Store が開く場合は、Python を入れ直して「Add python.exe to PATH」を有効にする。

### A-2 フォルダを開く
1. 展開した `azure-speech-transcriber` フォルダを、VS Code の `File → Open Folder` で開く。
2. 右下に出る「推奨拡張機能」の通知で `Install` を押す（Claude Code、Docker、GitHub PR）。

### A-3 VS Code の画面の見方
| 場所 | 役割 | 操作 |
|---|---|---|
| 左端のアイコン | エクスプローラー、検索、Git、拡張機能 | アイコンを押して切り替える |
| エクスプローラー | ファイルの一覧 | ダブルクリックで開く |
| エディタ | ファイルの中身 | 保存は `Ctrl + S` |
| 統合ターミナル | コマンドの実行 | `Ctrl + @` で開く（PowerShell） |
| 問題（Problems） | 構文エラーの一覧 | `Ctrl + Shift + M` |
| 出力（Output） | 拡張機能の出力 | `Ctrl + Shift + U` |

### A-4 Git を用意する
ターミナルで次を実行する（フォルダの中で）。
```powershell
git init -b main
git config user.name "自分の名前"
git config user.email "登録したメール"
git add .
git status
```
- `git status` の一覧に `config.js`、`*.wav`、`test/results/` が**無いこと**を確認する。
- 問題がなければ `git commit -m "初回コミット"` を実行する。

### A-5 GitHub と接続する
1. GitHub で**プライベート**のリポジトリを作る（README は作らない）。
2. 表示されたコマンドを実行する（`git remote add origin ...`、`git push -u origin main`）。
3. 初回の push で、ブラウザが開いて認証を求められる。承認する。

### A-6 設定と検証
1. ターミナルで次を実行する。
   ```powershell
   powershell -ExecutionPolicy Bypass -File .\scripts\windows\setup.ps1
   ```
2. `config.js` が作られたら、VS Code で開いて `endpoint` と `apiKey` を入れる（Git には入らない）。
3. 次の順に実行する。
   ```powershell
   npm run verify
   npm run e2e
   ```
4. `npm run verify` は、タスクからも実行できる（§B-2 参照）。

### A-7 Docker を使う（任意）
- Docker Desktop を起動してから、ターミナルで `docker build -t azure-speech-test .`。
- 詳細は `docs/setup-guide.md` の §6。

---

## B. 次回以降（毎回）

### B-1 作業を始める
1. VS Code でフォルダを開く（最近使ったフォルダから選べる）。
2. ターミナルで次を実行する。
   ```powershell
   git status
   git pull
   ```
3. 未コミットの変更がある場合は、先にその状態を確認する（残っている作業か、不要な変更か）。

### B-2 タスクで検証する（推奨）
1. `Ctrl + Shift + P` → 「Tasks: Run Task」。
2. 次のいずれかを選ぶ。
   | タスク | 内容 |
   |---|---|
   | 検証（build・単体テスト・秘密情報検査） | 日々の確認 |
   | 証跡を回収（verify ＋ ブラウザ試験） | 報告書を作るとき |
   | 証跡を回収（ブラウザ試験 ＋ メモリ計測の結果を含める） | 計測結果を含めるとき |

### B-3 変更する
1. 要件番号を決め、`docs/spec.md` を先に更新する（02 の §1 を参照）。
2. `src/` のファイルを編集する。`index.html` は編集しない。
3. 編集後、`Ctrl + S` で保存する。
4. ターミナルで `npm run verify` を実行する。失敗は「問題」タブと、ターミナルの赤い行で確認する。

### B-4 保存する（コミットと push）
1. 左端の Git アイコン（Source Control）を開く。
2. 変更したファイルの `+`（ステージ）を押す。`config.js` や `*.wav` が一覧に**無い**ことを確認する。
3. 上の入力欄に、要件番号つきのメッセージを書く（例：`FR-06: 区間見出しを修正（AC-UT-06）`）。
4. `Commit` を押し、続けて `Sync Changes`（または `git push`）で GitHub へ送る。

### B-5 確認する
- GitHub の `Actions` タブで、最新の verify が緑であることを確認する。
- 赤の場合は、ログの失敗した手順を開く。

### B-6 作業を終える
1. `git status` で、未コミットの変更がないことを確認する。
2. 試験結果を回収する（`npm run collect:e2e`、または回収タスク）。
3. 回収フォルダの zip を、社内の規程に従って保管する（GitHub にはアップロードしない）。

---

## C. よく使う VS Code の操作
| 操作 | キー・方法 |
|---|---|
| ファイルを探す | `Ctrl + P` にファイル名 |
| 文字列を全体から探す | `Ctrl + Shift + F` |
| 定義へ移動 | 関数名の上で `F12` |
| 行のコメント切替 | `Ctrl + /` |
| 整形 | `Shift + Alt + F` |
| コマンドパレット | `Ctrl + Shift + P` |
| 右の画面を分割 | `Ctrl + \` |
| 統合ターミナルの切替 | `Ctrl + @` |

## D. トラブル時の確認
| 症状 | 確認 |
|---|---|
| ターミナルでコマンドが見つからない | 新しいターミナルを開く。PATH を確認 |
| 日本語が文字化けする | ターミナルで `chcp 65001` |
| push が拒否される | `git pull` を先に行う。競合は手で解消する |
| 推奨拡張機能が出ない | 拡張機能（Ctrl + Shift + X）で「@recommended」を検索 |
| 保存したのに動かない | `npm run build` を実行（index.html の再生成） |
