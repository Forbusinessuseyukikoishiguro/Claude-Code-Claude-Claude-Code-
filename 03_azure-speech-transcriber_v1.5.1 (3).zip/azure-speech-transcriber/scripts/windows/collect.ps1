# ============================================================================
# collect.ps1 — Windows で証跡を回収し、zip にまとめる
# 使い方: powershell -ExecutionPolicy Bypass -File .\scripts\windows\collect.ps1
# 内容: ブラウザ試験込みで回収 → 最新の回収フォルダを zip 化 → 機密ファイルが無いことを確認
# ============================================================================
$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..\..")

node scripts/collect-evidence.js --e2e
$code = $LASTEXITCODE

$latest = Get-ChildItem "test\results" -Directory | Sort-Object Name -Descending | Select-Object -First 1
if (-not $latest) { Write-Host "回収フォルダが見つかりません。" -ForegroundColor Red; exit 1 }

$zip = "$($latest.FullName).zip"
if (Test-Path $zip) { Remove-Item $zip }
Compress-Archive -Path $latest.FullName -DestinationPath $zip

# 機密ファイルが混入していないことを確認する
$bad = Get-ChildItem $latest.FullName -Recurse -Include "config.js","config.real.js","*.wav" -ErrorAction SilentlyContinue
if ($bad) { Write-Host "機密ファイルが含まれています。zip を共有しないでください: $($bad.Name -join ', ')" -ForegroundColor Red; exit 1 }

Write-Host "zip を作成しました: $zip" -ForegroundColor Green
exit $code
