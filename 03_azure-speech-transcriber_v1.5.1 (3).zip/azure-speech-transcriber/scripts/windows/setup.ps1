# ============================================================================
# setup.ps1 — Windows の初回セットアップ（PowerShell）
# ----------------------------------------------------------------------------
# 使い方（プロジェクトのフォルダで）:
#   powershell -ExecutionPolicy Bypass -File .\scripts\windows\setup.ps1
# 内容:
#   1. 必要なツールの有無を確認する（Git・Node.js・Python 必須、Docker は任意）
#   2. config.js が無ければ config.example.js から作る（APIキーは後で入力）
#   3. ブラウザ試験用の Python パッケージと Chromium を入れる
#   4. npm run verify を実行する
# ============================================================================
$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..\..")

function Test-Tool($name, $hint, $required) {
    if (Get-Command $name -ErrorAction SilentlyContinue) {
        Write-Host "OK   $name" -ForegroundColor Green
        return $true
    }
    $color = "Yellow"; $label = "注意"
    if ($required) { $color = "Red"; $label = "NG" }
    Write-Host "$label   $name が見つかりません。$hint" -ForegroundColor $color
    return (-not $required)
}

$ok = $true
$ok = (Test-Tool "git"    "Git for Windows を導入してください（https://git-scm.com/）" $true) -and $ok
$ok = (Test-Tool "node"   "Node.js 22 LTS を導入してください（https://nodejs.org/）" $true) -and $ok
$ok = (Test-Tool "python" "Python 3.12 以上を導入し、PATH に追加してください" $true) -and $ok
[void](Test-Tool "docker" "（任意）Docker Desktop を使う場合のみ必要です" $false)

if (-not $ok) {
    Write-Host "必須ツールが不足しています。上の NG を解消してから、もう一度実行してください。" -ForegroundColor Red
    exit 1
}

if (-not (Test-Path "config.js")) {
    Copy-Item "config.example.js" "config.js"
    Write-Host "config.js を作成しました。endpoint と apiKey を編集してください（Git には入れません）。" -ForegroundColor Yellow
}

python -m pip install --user --quiet playwright
python -m playwright install chromium

npm run verify
if ($LASTEXITCODE -ne 0) { Write-Host "verify が失敗しました。verify.log と docs/setup-guide.md の §8 を確認してください。" -ForegroundColor Red; exit 1 }
Write-Host "初回セットアップが完了しました。" -ForegroundColor Green
