#!/usr/bin/env python3
"""
make_checklist_xlsx.py — 試験結果と仕様照合を、Excel のチェックリストにまとめる

入力: docs/spec.md（要件の表）、test/results/latest/all.json（run_all_tests.py の結果）
出力: test/results/latest/test-checklist.xlsx

シート:
  概要        ：全体の集計（数式）と読み方
  仕様照合    ：要件ごとに、対応する試験の結果を数式で引く（INDEX/MATCH）
  テスト結果  ：自動試験の全件（run_all_tests.py の出力）
  集計        ：区分ごとの件数（COUNTIFS）
  不具合      ：見つけた不具合、直した内容、再試験の結果
  仕様の矛盾  ：文書どうしの食い違いと、事実（根拠）
  直せないもの：この環境では直せない項目と、必要な作業
  手動チェック：人が操作して記録する項目（TC-01〜18）

数式は必ず生きた値として書く（集計・判定は結果を変えれば自動で変わる）。
"""
import json, os, re, sys, time
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RES = os.path.join(ROOT, "test", "results", "latest", "all.json")
OUT = os.path.join(ROOT, "test", "results", "latest", "test-checklist.xlsx")
FONT = "Arial"
HDR_FILL = PatternFill("solid", fgColor="1F3864")
SUB_FILL = PatternFill("solid", fgColor="D9E2F3")
OK_FILL = PatternFill("solid", fgColor="E2EFDA")
NG_FILL = PatternFill("solid", fgColor="F8CBAD")
thin = Side(style="thin", color="8EA9DB")
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
WRAP = Alignment(wrap_text=True, vertical="top")

# 仕様の要件 → 主に対応する試験ID（先頭が主）。対応が無いものは空欄（＝自動化なし）
MAP = {
    "FR-01": ["AC-01a", "A-01", "A-04"], "FR-02": [], "FR-03": ["AC-UT-05a", "I-01"],
    "FR-04": [], "FR-05": ["I-01", "AC-05"], "FR-06": ["AC-03", "AC-UT-06", "I-02"],
    "FR-07": ["AC-UT-03", "I-03"], "FR-08": ["AC-08", "I-04"], "FR-09": ["AC-09a", "AC-09b", "A-22"],
    "FR-10": ["AC-10a", "AC-10b", "AC-UT-07", "A-09", "A-12", "A-13"], "FR-11": ["AC-11", "A-14", "I-02"],
    "FR-12": [], "NFR-01": [], "NFR-02": [], "NFR-03": [], "NFR-04": [], "NFR-05": [],
    "NFR-06": [], "NFR-07": [], "UX-01": ["UX-01"], "UX-02": [], "UX-03": [],
    "TST-01": ["AC-UT-01a"], "TST-02": [],
}

# 不具合（発見した試験・原因・対処）。事実だけを書く
BUGS = [
    ("BUG-01", "AC-UT-05a（回帰）・単体の境界値試験", "区間の長さが分割単位の倍数よりわずかに大きいと、長さ約0秒の余分な区間が作られる（例：600.0000000000001 → 2区間）。Azure に1サンプルだけ送ることになり、処理が失敗しうる",
     "浮動小数点の誤差。切り上げの前に許容差が無かった", "buildSegments に 1e-6 の許容差を入れた", "修正済み", "合格"),
    ("BUG-02", "AC-UT-01c（境界）", "fmtTime(1e308) が「2.7e+304:58:56」のような崩れた文字列を返す", "有限の巨大な数を、そのまま計算していた", "1e9 秒（約31年）以上は 00:00:00 として扱う", "修正済み", "合格"),
    ("BUG-03", "AC-UT-02b（境界）", "fmtSize(NaN) が「NaN KB」、fmtSize(-5) が「1 KB」を返す", "不正値の検査が無かった", "NaN・負数・無限大は「不明」と表示", "修正済み", "合格"),
    ("BUG-04", "A-18（壊しに行く）", "分割単位の値を書き換えると、区間が0件になり、0部の「完了」と表示されうる", "区間が0件のときの検査が無かった", "区間が0件なら、送信せずに「分割単位の値が不正」と表示", "修正済み", "合格"),
    ("BUG-05", "A-20（競合）", "連続してファイルを選ぶと、後から終わった古い読み込みが情報を上書きしうる（理論上。試験では再現せず）", "読み込みを識別する番号が無かった", "読み込みの番号を付け、古い結果を捨てる（防御的な修正）", "修正済み（再現せず）", "合格"),
    ("BUG-06", "A-08（壊しに行く）", "endpoint が http(s) の URL でないと、相対URLとして送信し、別サーバーの応答（HTML）をエラーとして表示する", "endpoint の形式を検査していなかった", "endpoint が http(s) の絶対URLでなければ、開始を無効にして設定不備を案内", "修正済み", "合格"),
    ("BUG-07", "A-11（壊しに行く）", "200 でも本文が JSON でないと、「Unexpected token '<'」という生のエラー文が出る", "JSON の解析失敗を、想定外の例外として扱っていた", "専用の種類（InvalidResponse）にし、「応答を読み取れませんでした」と案内。再試行しない", "修正済み", "合格"),
    ("BUG-08", "A-13（壊しに行く）", "本文の途中で接続が切れると、通信の失敗ではなく「応答の不備」と誤判定し、再試行しなかった", "本文の読み取りと JSON の解析を、同じ例外の扱いにしていた", "本文の読み取り（通信）と JSON の解析（応答）を分け、通信の失敗は再試行する", "修正済み", "合格"),
    ("BUG-09", "A-16（空の応答）", "認識結果が空の区間は、見出しだけが出て、無言になる", "空のときの文言が無かった", "「この区間に認識結果はありませんでした」と表示", "修正済み", "合格"),
    ("BUG-10", "（構成の確認）", "npm test が新しい単体テストを実行していなかった（node --test の指定が不足）", "package.json の指定の不足", "test スクリプトに edge のファイルを追加", "修正済み", "合格"),
    ("BUG-11", "（文書の確認）", "TEST手順書の TC-15 の期待値「約8MB」は誤り（実測は約7MB）", "文書の数値の計算違い", "約7MB に修正し、計算の根拠を併記", "修正済み", "－"),
]

# 仕様の矛盾（文書どうしの食い違い・根拠つき）
SPECS = [
    ("SPEC-01", "TEST-PROCEDURE.md（TC-15）", "期待値を「約8MB」と書いていた", "試験音声（2分・モノラル16kHz）の値は 7.3MB。アプリは四捨五入して 7 と表示する", "約7MB に修正", "修正済み"),
    ("SPEC-02", "docs/design-set/06_test-spec.md", "AC-UT-01a/01b/05a/05b を参照していたが、テストの名前が AC-UT-01・05 のままだった", "テストの名前と仕様のIDが一致しない（追跡できない）", "テストの名前を 01a/01b/05a/05b に改名", "修正済み"),
    ("SPEC-03", "docs/spec-integrated.md と docs/spec.md", "版番号が二重に管理されていた（1.0.1 と 1.3 が併存）", "どちらが最新か分からない", "仕様書を 1.4 とし、履歴を spec.md と一致させた", "修正済み"),
    ("SPEC-04", "複数の文書", "単体テストの件数が「11件」のまま（実際は 23 件）", "件数の記述が古い", "全文書の件数を 23 件に更新", "修正済み"),
    ("SPEC-05", "docs/design-set/05_implementation-spec.md", "fmtTime・fmtSize の不正値の扱いを書いていなかった", "実装と仕様が食い違っていた", "不正値の扱いを仕様に追記（1.4）", "修正済み"),
    ("SPEC-06", "docs/spec.md（FR-10）", "失敗の種類の案内に「応答の不備」が無かった", "新しい種類（InvalidResponse）が仕様に無い", "仕様に追記（1.4）", "修正済み"),
    ("SPEC-07", "docs/spec.md（NFR-06）", "「外部ライブラリを使わない」と、開発用の docx（devDependencies）の関係が書かれていなかった", "利用者への配布物には含まれないが、文書に無い", "NFR-06 の注記は次版で追記（要対応）", "未対応"),
    ("SPEC-08", "docs/spec.md（AC-NFR01〜07）", "AC-NFR 系は自動試験の対応が無い。一部は文書の確認で代える", "自動で確かめられていない受け入れ基準がある", "手動の確認として「直せないもの」に記載", "未対応"),
]

# 直せないもの（この環境・私の作業では直せない。あなたが行う作業）
CANNOT = [
    ("CANT-01", "実Azure での動作（api-version、フォーム項目名、応答の形、CORS）", "APIキーと課金が要る。この環境からは Azure へ接続できない", "1分の音声で1回だけ実行し、結果を docs/open-questions.md（OQ-01・OQ-02）に記録。違えば src/index.html の callAzure と mock-server.js を直す", "開発者", "最優先"),
    ("CANT-02", "3時間の音声（FR-04）の処理", "ブラウザは音声全体を展開するため、メモリが足りない（実測で 60分の mp3 が増分 2.6GB、180分は失敗）。設計の変更が要る", "事前分割の運用（docs/operations.md）。根本対策は、段階的な処理（WebCodecs など）への設計変更（ADR-004 の A）", "設計者", "高"),
    ("CANT-03", "Edge・Windows での動作（NFR-01）", "この環境は Linux と Chromium のみ", "Windows と Edge で e2e と suite.py を実行する（scripts/windows/setup.ps1 のあと）", "試験担当", "高"),
    ("CANT-04", "手動の試験（TC-04 ドロップ、TC-16 フォーカス枠、TC-17 360px 表示）", "画面の見た目と操作感は人が見る必要がある", "TEST手順書の手順で確認し、「手動チェック」シートに記録", "試験担当", "中"),
    ("CANT-05", "ピースの時刻の連続化（FR-12）", "未実装の機能。仕様は決まっているが、作業は次版", "ピースの開始時刻を入力できるようにし、結果を連結する（要件の追加が必要）", "開発者", "中"),
    ("CANT-06", "Docker と GitHub Actions の実行", "この環境に Docker が無く、GitHub にも接続していない", "docker build、Actions の緑を確認。失敗したら、ログの該当行を見て直す", "開発者", "中"),
    ("CANT-07", "利用料金と社内規程（OQ-06、OQ-07）", "社内の判断と、契約の情報が要る", "管理者が確認し、docs/open-questions.md を更新", "管理者", "高"),
    ("CANT-08", "分割した音声の処理後の削除（運用）", "機密の管理は社内の運用に依存する", "運用ルールを決め、docs/evidence-guide.md に反映", "運用担当", "中"),
]

# 手動チェック（TC-01〜18）
MANUAL = [
    ("TC-01", "設定未完了の表示", "config.js の apiKey を初期値のまま開く", "「設定未完了」が赤枠で出る。開始が押せない"),
    ("TC-02", "音声以外の拒否", "memo.txt を選ぶ", "「音声ファイルを選択してください」"),
    ("TC-03", "音声の情報表示", "sample-2min.wav を選ぶ", "名前、容量（3.7MB）、再生時間（02:00）が出る"),
    ("TC-04", "ドラッグ＆ドロップ", "音声を画面の任意の場所へドロップ", "TC-03 と同じ表示になる"),
    ("TC-05", "分割数の目安", "分割単位を 1分 にする", "「2 件」と表示"),
    ("TC-06", "分割数の目安（変更）", "分割単位を 5分 にする", "「1 件」と表示"),
    ("TC-07", "実行", "1分で開始", "第1/2部 → 第2/2部 → 完了"),
    ("TC-08", "結果の見出し", "TC-07 の結果欄", "見出し付きで2部。本文がある"),
    ("TC-09", "コピー", "「コピー」を押し、メモ帳に貼る", "結果が貼り付く"),
    ("TC-10", "保存（文字化け）", "「テキストで保存」し、メモ帳で開く", "日本語が崩れない"),
    ("TC-11", "再試行", "モックを FAIL_EVERY=2 で起動し、開始", "「再試行中」が出て、最後まで完了"),
    ("TC-12", "認証誤り", "apiKey を wrong-key にして開始", "401 の案内が出る"),
    ("TC-13", "接続不可", "モックを止めて開始", "「接続できません」が出る"),
    ("TC-14", "中止", "1部完了後に中止", "「中止しました（1/2部」。完了分が残る"),
    ("TC-15", "メモリ警告", "memWarnMB を 5 にして 2分の音声を読む", "「約7MB」の警告が出る（終わったら 1500 に戻す）"),
    ("TC-16", "フォーカス枠", "Tab キーで全部のボタンを移動", "各要素にオレンジの枠が見える"),
    ("TC-17", "360px 表示", "開発者ツールで幅を 360px にする", "横スクロールなし。崩れなし"),
    ("TC-18", "コンソールのエラー", "F12 → Console を見る", "赤いエラーが無い"),
]


def style_header(ws, row, ncol):
    for c in range(1, ncol + 1):
        cell = ws.cell(row=row, column=c)
        cell.font = Font(name=FONT, bold=True, color="FFFFFF")
        cell.fill = HDR_FILL
        cell.alignment = Alignment(wrap_text=True, vertical="center")
        cell.border = BORDER


def body(ws, r1, r2, ncol):
    for r in range(r1, r2 + 1):
        for c in range(1, ncol + 1):
            cell = ws.cell(row=r, column=c)
            cell.font = Font(name=FONT, size=10)
            cell.alignment = WRAP
            cell.border = BORDER


def widths(ws, ws_widths):
    for i, w in enumerate(ws_widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w


def title(ws, text, sub=None):
    ws["A1"] = text
    ws["A1"].font = Font(name=FONT, size=14, bold=True, color="1F3864")
    if sub:
        ws["A2"] = sub
        ws["A2"].font = Font(name=FONT, size=9, color="595959")


def main():
    doc = json.load(open(RES, encoding="utf-8"))
    results = doc["results"]
    wb = Workbook()

    # ---------- テスト結果 ----------
    wt = wb.active
    wt.title = "テスト結果"
    title(wt, "自動試験の結果（全件）", f"実行日時：{doc['generatedAt']}　環境：{doc['environment']}")
    cols = ["ID", "区分", "試験名", "期待する結果", "結果", "詳細", "時間(ms)"]
    for c, h in enumerate(cols, 1):
        wt.cell(row=4, column=c, value=h)
    style_header(wt, 4, len(cols))
    CAT = {"U": "単体", "S": "総合（画面）", "I": "結合", "A": "壊しに行く", "M": "モンキー"}
    for i, x in enumerate(results):
        r = 5 + i
        vals = [x["id"], x["cat"], x["title"], x["expected"], x["result"], x["detail"], x["ms"]]
        for c, v in enumerate(vals, 1):
            wt.cell(row=r, column=c, value=v)
    last = 4 + len(results)
    body(wt, 5, last, len(cols))
    for r in range(5, last + 1):
        wt.cell(row=r, column=2).value = wt.cell(row=r, column=2).value  # 区分コードのまま（集計で使う）
    widths(wt, [14, 8, 46, 36, 10, 40, 10])
    wt.freeze_panes = "A5"
    wt.auto_filter.ref = f"A4:G{last}"
    RES_LAST = last

    # ---------- 仕様照合 ----------
    ws = wb.create_sheet("仕様照合", 0)
    title(ws, "仕様照合：要件ごとの試験の結果", "結果は「テスト結果」シートから数式で引く。試験の結果を変えると、判定が自動で変わる。")
    hdr = ["要件ID", "優先", "要件（docs/spec.md）", "仕様上の状態", "主な試験ID", "試験の結果（自動）", "判定"]
    for c, h in enumerate(hdr, 1):
        ws.cell(row=4, column=c, value=h)
    style_header(ws, 4, len(hdr))
    spec_text = open(os.path.join(ROOT, "docs", "spec.md"), encoding="utf-8").read()
    rows = []
    for line in spec_text.splitlines():
        m = re.match(r"^\| (FR|NFR|UX|TST)-(\d+) \| (P\d) \| (.+?) \| (.+?) \| (.+?) \|\s*$", line)
        if m:
            rid = f"{m.group(1)}-{m.group(2)}"
            rows.append((rid, m.group(3), m.group(4), m.group(6).strip(), re.sub(r"<br>", " ", m.group(5))))
    r = 5
    for rid, prio, req, state, ac in rows:
        ids = MAP.get(rid, [])
        main_id = ids[0] if ids else "（対応する試験なし）"
        ws.cell(row=r, column=1, value=rid)
        ws.cell(row=r, column=2, value=prio)
        ws.cell(row=r, column=3, value=req)
        ws.cell(row=r, column=4, value=state)
        ws.cell(row=r, column=5, value=", ".join(ids) if ids else "（なし）")
        ws.cell(row=r, column=6, value=f'=IF(COUNTIF(\'テスト結果\'!$A$5:$A${RES_LAST},"{ids[0] if ids else "@@none@@"}")=0,"自動化なし",INDEX(\'テスト結果\'!$E$5:$E${RES_LAST},MATCH("{ids[0] if ids else "@@none@@"}",\'テスト結果\'!$A$5:$A${RES_LAST},0)))')
        ws.cell(row=r, column=7, value=f'=IF(F{r}="合格","合格",IF(F{r}="自動化なし","手動で確認",IF(F{r}="不合格","要対応","確認")))')
        r += 1
    body(ws, 5, r - 1, len(hdr))
    widths(ws, [10, 7, 52, 30, 30, 16, 14])
    ws.freeze_panes = "A5"
    SPEC_LAST = r - 1

    # ---------- 集計（概要） ----------
    sm = wb.create_sheet("概要", 0)
    title(sm, "試験チェックリスト：概要", "Azure Speech 文字起こしツール（1.4）。数式は、テスト結果と仕様照合の値から自動で計算される。")
    sm["A4"] = "区分"; sm["B4"] = "件数"; sm["C4"] = "合格"; sm["D4"] = "不合格"; sm["E4"] = "合格率"
    style_header(sm, 4, 5)
    cats = [("U", "単体（node:test）"), ("S", "総合（画面 e2e）"), ("I", "結合"), ("A", "壊しに行く"), ("M", "モンキー")]
    for i, (code, label) in enumerate(cats):
        rr = 5 + i
        sm.cell(row=rr, column=1, value=label)
        sm.cell(row=rr, column=2, value=f"=COUNTIF('テスト結果'!$B$5:$B${RES_LAST},\"{code}\")")
        sm.cell(row=rr, column=3, value=f"=COUNTIFS('テスト結果'!$B$5:$B${RES_LAST},\"{code}\",'テスト結果'!$E$5:$E${RES_LAST},\"合格\")")
        sm.cell(row=rr, column=4, value=f"=COUNTIFS('テスト結果'!$B$5:$B${RES_LAST},\"{code}\",'テスト結果'!$E$5:$E${RES_LAST},\"不合格\")")
        sm.cell(row=rr, column=5, value=f"=IFERROR(C{rr}/B{rr},0)")
    tr = 5 + len(cats)
    sm.cell(row=tr, column=1, value="合計")
    for c in (2, 3, 4):
        L = get_column_letter(c)
        sm.cell(row=tr, column=c, value=f"=SUM({L}5:{L}{tr-1})")
    sm.cell(row=tr, column=5, value=f"=IFERROR(C{tr}/B{tr},0)")
    body(sm, 5, tr, 5)
    for c in range(1, 6):
        sm.cell(row=tr, column=c).font = Font(name=FONT, bold=True, size=10)
        sm.cell(row=tr, column=c).fill = SUB_FILL
    for rr in range(5, tr + 1):
        sm.cell(row=rr, column=5).number_format = "0%"
    k = tr + 2
    sm.cell(row=k, column=1, value="要件の判定（仕様照合）").font = Font(name=FONT, bold=True)
    labels = [("合格", "合格"), ("手動で確認", "手動で確認"), ("要対応", "要対応")]
    for i, (lab, key) in enumerate(labels):
        sm.cell(row=k + 1 + i, column=1, value=lab)
        sm.cell(row=k + 1 + i, column=2, value=f"=COUNTIF('仕様照合'!$G$5:$G${SPEC_LAST},\"{key}\")")
    body(sm, k + 1, k + len(labels), 2)
    b = k + len(labels) + 2
    sm.cell(row=b, column=1, value="不具合（件数）")
    sm.cell(row=b, column=2, value="=COUNTA('不具合'!A5:A50)")
    sm.cell(row=b + 1, column=1, value="仕様の矛盾（件数）")
    sm.cell(row=b + 1, column=2, value="=COUNTA('仕様の矛盾'!A5:A50)")
    sm.cell(row=b + 2, column=1, value="直せないもの（件数）")
    sm.cell(row=b + 2, column=2, value="=COUNTA('直せないもの'!A5:A50)")
    body(sm, b, b + 2, 2)
    n = b + 4
    notes = [
        "読み方",
        "・「不合格」は、その試験の期待を満たさなかったもの。修正後の再試験の結果は「不具合」シートに記録。",
        "・「手動で確認」は、自動の試験が無い要件。「手動チェック」シートで記録する。",
        "・「直せないもの」は、この環境（Azure接続・Windows・Docker）や設計の判断が要るもの。",
        "・自動試験は、この環境（Linux・Chromium・モックのAzure）での結果。実Azure・Edge・Windowsの結果ではない。",
    ]
    for i, t in enumerate(notes):
        sm.cell(row=n + i, column=1, value=t).font = Font(name=FONT, size=10, bold=(i == 0))
    widths(sm, [34, 12, 12, 12, 12])

    # ---------- 不具合 ----------
    wbug = wb.create_sheet("不具合")
    title(wbug, "不具合の記録（見つけて、直したもの）", "再試験の結果は、修正後に試験を実行した結果（合格＝直った）")
    bh = ["不具合ID", "発見した試験", "現象（事実）", "原因", "対処", "修正の状態", "再試験の結果"]
    for c, h in enumerate(bh, 1):
        wbug.cell(row=4, column=c, value=h)
    style_header(wbug, 4, len(bh))
    for i, row in enumerate(BUGS):
        for c, v in enumerate(row, 1):
            wbug.cell(row=5 + i, column=c, value=v)
    body(wbug, 5, 4 + len(BUGS), len(bh))
    widths(wbug, [10, 26, 58, 34, 44, 16, 14])
    wbug.freeze_panes = "A5"

    # ---------- 仕様の矛盾 ----------
    wsp = wb.create_sheet("仕様の矛盾")
    title(wsp, "文書と実装の食い違い（スパルタレビュー）", "事実（根拠）を併記。対処欄の「修正済み」は、この版で直したもの")
    sh_ = ["ID", "文書", "内容", "事実（根拠）", "対処", "状態"]
    for c, h in enumerate(sh_, 1):
        wsp.cell(row=4, column=c, value=h)
    style_header(wsp, 4, len(sh_))
    for i, row in enumerate(SPECS):
        for c, v in enumerate(row, 1):
            wsp.cell(row=5 + i, column=c, value=v)
    body(wsp, 5, 4 + len(SPECS), len(sh_))
    widths(wsp, [10, 34, 52, 52, 40, 14])
    wsp.freeze_panes = "A5"

    # ---------- 直せないもの ----------
    wc = wb.create_sheet("直せないもの")
    title(wc, "直せないもの（あなたが直す・判断する）", "この環境で私が直せないものと、必要な作業。優先度の高い順に並べている")
    ch = ["ID", "項目", "直せない理由", "必要な作業", "担当", "優先度"]
    for c, h in enumerate(ch, 1):
        wc.cell(row=4, column=c, value=h)
    style_header(wc, 4, len(ch))
    for i, row in enumerate(CANNOT):
        for c, v in enumerate(row, 1):
            wc.cell(row=5 + i, column=c, value=v)
    body(wc, 5, 4 + len(CANNOT), len(ch))
    widths(wc, [10, 40, 50, 60, 12, 10])
    wc.freeze_panes = "A5"

    # ---------- 手動チェック ----------
    wm = wb.create_sheet("手動チェック")
    title(wm, "手動チェック（TC-01〜18）", "記入方法：「結果」列で 合格／不合格／未実施 を選ぶ。備考・担当者・日付を記入する。記入例は右の説明を参照。")
    mh = ["TC", "内容", "手順の要点", "期待する結果", "結果", "担当者", "実施日", "備考（不具合の番号など）"]
    for c, h in enumerate(mh, 1):
        wm.cell(row=4, column=c, value=h)
    style_header(wm, 4, len(mh))
    for i, (tc, what, step, exp) in enumerate(MANUAL):
        rr = 5 + i
        for c, v in enumerate([tc, what, step, exp, "未実施", "", "", ""], 1):
            wm.cell(row=rr, column=c, value=v)
    mlast = 4 + len(MANUAL)
    body(wm, 5, mlast, len(mh))
    dv = DataValidation(type="list", formula1='"合格,不合格,未実施"', allow_blank=False)
    wm.add_data_validation(dv)
    dv.add(f"E5:E{mlast}")
    for rr in range(5, mlast + 1):
        wm.cell(row=rr, column=7).number_format = "yyyy-mm-dd"
    wm.cell(row=mlast + 2, column=1, value="凡例").font = Font(name=FONT, bold=True)
    wm.cell(row=mlast + 3, column=1, value="・「結果」は、プルダウンから選ぶ（合格／不合格／未実施）。")
    wm.cell(row=mlast + 4, column=1, value="・不合格のときは、備考欄に不具合の内容と再現手順の要点を書く。")
    wm.cell(row=mlast + 5, column=1, value="・記入例：TC-03 ／ 結果：合格 ／ 担当者：（氏名）／ 実施日：（日付）／ 備考：（空欄可）")
    widths(wm, [8, 22, 40, 44, 12, 12, 12, 28])
    wm.freeze_panes = "A5"
    dv.add(f"E5:E{mlast}")

    # 並び順：概要, 仕様照合, テスト結果, 不具合, 仕様の矛盾, 直せないもの, 手動チェック
    order = ["概要", "仕様照合", "テスト結果", "不具合", "仕様の矛盾", "直せないもの", "手動チェック"]
    wb._sheets = [wb[n] for n in order]

    # 全体のフォント（Arial）
    for w in wb.worksheets:
        for row in w.iter_rows():
            for cell in row:
                if cell.font and cell.font.name != FONT:
                    cell.font = Font(name=FONT, size=cell.font.size or 10, bold=cell.font.bold,
                                     color=cell.font.color)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    wb.save(OUT)
    print("保存しました:", OUT)


if __name__ == "__main__":
    main()
