#!/usr/bin/env python3
"""
run_all_tests.py — すべての自動試験を実行し、結果を1つの JSON にまとめる

実行する試験:
  U 単体      : node --test（lib.test.js・lib.edge.test.js）
  S 総合（画面）: scripts/e2e_smoke.py（実ブラウザ、モック、13件）
  I・A・M      : test/browser/suite.py（結合・壊しに行く・モンキー）
出力: test/results/latest/all.json（make_checklist_xlsx.py が読む）
終了コード: 1 = 不合格あり
"""
import json, os, platform, re, subprocess, sys, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(ROOT, "test", "results", "latest")
os.makedirs(OUT, exist_ok=True)
results = []


def sh(cmd):
    return subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)


# ---------- U：単体（TAP 形式で読む） ----------
t0 = time.time()
r = sh(["node", "--test", "--test-reporter=tap",
        "test/unit/lib.test.js", "test/unit/lib.edge.test.js"])
for line in r.stdout.splitlines():
    m = re.match(r"^(ok|not ok) \d+ - (.+)$", line)
    if not m:
        continue
    name = m.group(2)
    tid = re.match(r"(AC-UT-\w+)", name)
    tid = tid.group(1) if tid else "AC-UT-?"
    title = name[len(tid):].strip()
    results.append({"cat": "U", "id": tid, "title": title,
                    "expected": "単体テストが合格すること",
                    "result": "合格" if m.group(1) == "ok" else "不合格",
                    "detail": "" if m.group(1) == "ok" else "node --test の失敗（test/results の TAP を参照）",
                    "ms": 0})

# ---------- S：総合（画面、既存の13件） ----------
r = sh([sys.executable, "scripts/e2e_smoke.py"])
for line in r.stdout.splitlines():
    m = re.match(r"^\[(合|否)\] (\S+) (.*)$", line)
    if m:
        results.append({"cat": "S", "id": m.group(2), "title": m.group(3)[:60],
                        "expected": "画面の確認項目を満たすこと",
                        "result": "合格" if m.group(1) == "合" else "不合格",
                        "detail": "" if m.group(1) == "合" else m.group(3), "ms": 0})
open(os.path.join(OUT, "e2e.log"), "w", encoding="utf-8").write(r.stdout + r.stderr)

# ---------- I・A・M：結合・壊しに行く・モンキー（suite.py が browser.json を書く） ----------
r = sh([sys.executable, "test/browser/suite.py"])
open(os.path.join(OUT, "browser.log"), "w", encoding="utf-8").write(r.stdout + r.stderr)
bpath = os.path.join(OUT, "browser.json")
if os.path.exists(bpath):
    for b in json.load(open(bpath, encoding="utf-8")):
        b["cat"] = b["cat"]  # I / A / M
        results.append(b)

env = {"platform": f"{platform.system()} {platform.release()}",
       "node": sh(["node", "-v"]).stdout.strip(),
       "python": platform.python_version()}
doc = {"generatedAt": time.strftime("%Y-%m-%d %H:%M:%S"), "environment": env,
       "results": results}
json.dump(doc, open(os.path.join(OUT, "all.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)

fails = [x for x in results if x["result"] != "合格"]
print(f"合計 {len(results)} 件 / 合格 {len(results) - len(fails)} / 不合格 {len(fails)}")
for x in fails:
    print(f"  不合格: {x['id']} {x['title']}  {x['detail'][:80]}")
sys.exit(1 if fails else 0)
