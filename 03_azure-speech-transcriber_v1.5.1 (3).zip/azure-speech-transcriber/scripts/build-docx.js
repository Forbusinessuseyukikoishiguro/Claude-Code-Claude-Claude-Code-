#!/usr/bin/env node
/* ============================================================================
 * build-docx.js — Markdown の文書群を、1つの Word（.docx）にまとめる
 * ----------------------------------------------------------------------------
 * 使い方:
 *   node scripts/build-docx.js <入力フォルダ> <出力ファイル.docx> [タイトル]
 *   例: node scripts/build-docx.js "docs/design-set" "docs/design-set/design-set.docx" "設計書一式"
 *
 * 仕様:
 *   - 入力フォルダの .md を、ファイル名の順に並べる（00_, 01_ … の番号で順番を決める）
 *   - 各ファイルは改ページで始まる（先頭ファイルを除く）
 *   - 対応する記法: 見出し（#〜####）、段落、箇条書き（-、2段目は字下げ）、番号つき行、
 *     表（| 区切り）、コードブロック（```）、引用（>）、区切り線（---）、
 *     インライン（**太字**、`コード`）
 *   - 対応しない記法（画像、リンクの体裁、HTML）は、そのままの文字として出る
 *   - 用紙は A4 縦、余白 2cm、フォントは游ゴシック（Windows の既定の日本語フォント）
 *
 * 依存: docx（npm）。開発用の道具であり、アプリ本体（index.html）には含まれない。
 * ============================================================================ */
"use strict";

const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  WidthType, ShadingType, AlignmentType, Footer, Header, PageNumber,
  LevelFormat, BorderStyle, PageBreak,
} = require("docx");

const [, , inDir, outFile, titleArg] = process.argv;
if (!inDir || !outFile) {
  console.error("使い方: node scripts/build-docx.js <入力フォルダ> <出力.docx> [タイトル]");
  process.exit(2);
}
const TITLE = titleArg || path.basename(inDir);

// A4 縦、余白 2cm（1cm ≒ 567 DXA）。本文の幅 = 11906 − 1134 × 2 = 9638 DXA
const PAGE_W = 11906, PAGE_H = 16838, MARGIN = 1134, TEXT_W = PAGE_W - MARGIN * 2;
const FONT = "Yu Gothic";
const MONO = "Consolas";

// ---------- インライン記法（**太字**、`コード`） ----------
function inlineRuns(text, base = {}) {
  const runs = [];
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g).filter((p) => p !== "");
  for (const p of parts) {
    if (p.startsWith("**") && p.endsWith("**")) {
      runs.push(new TextRun({ text: p.slice(2, -2), bold: true, font: FONT, ...base }));
    } else if (p.startsWith("`") && p.endsWith("`")) {
      runs.push(new TextRun({ text: p.slice(1, -1), font: MONO, size: 19, ...base }));
    } else {
      runs.push(new TextRun({ text: p, font: FONT, ...base }));
    }
  }
  return runs.length ? runs : [new TextRun({ text: "", font: FONT })];
}

// ---------- 表 ----------
function splitRow(line) {
  let cells = line.trim().split("|").map((c) => c.trim());
  if (cells[0] === "") cells.shift();
  if (cells.length && cells[cells.length - 1] === "") cells.pop();
  return cells;
}
function buildTable(lines) {
  const rows = lines.map(splitRow).filter((r, i) => !(i === 1 && r.every((c) => /^:?-{2,}:?$/.test(c))));
  const cols = Math.max(...rows.map((r) => r.length));
  // 列の幅：中身の長さに比例（最低 6 文字分）。合計が本文の幅になるよう調整する
  const weight = Array.from({ length: cols }, (_, c) =>
    Math.max(6, ...rows.map((r) => (r[c] || "").replace(/`|\*/g, "").length)));
  const sum = weight.reduce((a, b) => a + b, 0);
  const widths = weight.map((w) => Math.floor((w / sum) * TEXT_W));
  widths[cols - 1] += TEXT_W - widths.reduce((a, b) => a + b, 0);

  const border = { style: BorderStyle.SINGLE, size: 4, color: "8EA9DB" };
  const borders = { top: border, bottom: border, left: border, right: border };
  const trs = rows.map((r, ri) => new TableRow({
    tableHeader: ri === 0,
    children: Array.from({ length: cols }, (_, c) => new TableCell({
      width: { size: widths[c], type: WidthType.DXA },
      borders,
      shading: ri === 0 ? { type: ShadingType.CLEAR, fill: "D9E2F3", color: "auto" } : undefined,
      margins: { top: 60, bottom: 60, left: 90, right: 90 },
      children: [new Paragraph({
        spacing: { before: 0, after: 0 },
        children: inlineRuns(r[c] || "", { size: 18, bold: ri === 0 }),
      })],
    })),
  }));
  return new Table({
    width: { size: TEXT_W, type: WidthType.DXA },
    columnWidths: widths,
    rows: trs,
  });
}

// ---------- Markdown → 要素 ----------
function convert(md) {
  const out = [];
  const lines = md.replace(/\r\n/g, "\n").split("\n");
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];

    // コードブロック
    if (/^```/.test(line)) {
      i++;
      while (i < lines.length && !/^```/.test(lines[i])) {
        out.push(new Paragraph({
          spacing: { before: 0, after: 0 },
          shading: { type: ShadingType.CLEAR, fill: "F2F2F2", color: "auto" },
          children: [new TextRun({ text: lines[i] || " ", font: MONO, size: 17 })],
        }));
        i++;
      }
      out.push(new Paragraph({ spacing: { after: 120 }, children: [] }));
      i++;
      continue;
    }

    // 表（| で始まる行が続く）
    if (/^\s*\|/.test(line)) {
      const block = [];
      while (i < lines.length && /^\s*\|/.test(lines[i])) { block.push(lines[i]); i++; }
      out.push(buildTable(block));
      out.push(new Paragraph({ spacing: { after: 120 }, children: [] }));
      continue;
    }

    // 見出し
    const h = line.match(/^(#{1,4})\s+(.*)$/);
    if (h) {
      const level = h[1].length;
      const heading = [null, "Heading1", "Heading2", "Heading3", "Heading4"][level];
      out.push(new Paragraph({ heading, children: inlineRuns(h[2]) }));
      i++;
      continue;
    }

    // 区切り線
    if (/^---+\s*$/.test(line)) {
      out.push(new Paragraph({
        spacing: { before: 120, after: 120 },
        border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: "8EA9DB", space: 1 } },
        children: [],
      }));
      i++;
      continue;
    }

    // 引用
    if (/^>\s?/.test(line)) {
      out.push(new Paragraph({
        indent: { left: 360 },
        border: { left: { style: BorderStyle.SINGLE, size: 12, color: "8EA9DB", space: 8 } },
        children: inlineRuns(line.replace(/^>\s?/, ""), { italics: true, color: "404040" }),
      }));
      i++;
      continue;
    }

    // 箇条書き（- ）。字下げ2つ以上は2段目
    const bullet = line.match(/^(\s*)-\s+(.*)$/);
    if (bullet) {
      const level = bullet[1].length >= 2 ? 1 : 0;
      out.push(new Paragraph({
        numbering: { reference: "bullets", level },
        children: inlineRuns(bullet[2]),
      }));
      i++;
      continue;
    }

    // 番号つき行（番号はそのまま文字として出す）
    const num = line.match(/^(\d+)\.\s+(.*)$/);
    if (num) {
      out.push(new Paragraph({
        indent: { left: 360, hanging: 360 },
        children: inlineRuns(`${num[1]}. ${num[2]}`),
      }));
      i++;
      continue;
    }

    // 空行
    if (line.trim() === "") { i++; continue; }

    // 通常の段落（連続する行は1段落にまとめる）
    const para = [line.trim()];
    i++;
    while (i < lines.length && lines[i].trim() !== "" && !/^(#{1,4}\s|```|\s*\||\s*-\s|>|---+\s*$|\d+\.\s)/.test(lines[i])) {
      para.push(lines[i].trim());
      i++;
    }
    out.push(new Paragraph({ spacing: { after: 120 }, children: inlineRuns(para.join(" ")) }));
  }
  return out;
}

// ---------- 入力の読み込み ----------
const files = fs.readdirSync(inDir).filter((f) => f.endsWith(".md")).sort();
if (files.length === 0) { console.error(`.md が見つかりません: ${inDir}`); process.exit(1); }

const body = [];
files.forEach((f, idx) => {
  if (idx > 0) body.push(new Paragraph({ children: [new PageBreak()] }));
  body.push(...convert(fs.readFileSync(path.join(inDir, f), "utf8")));
});

// ---------- 文書の組み立て ----------
const cover = [
  new Paragraph({ spacing: { before: 3000, after: 240 }, alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: TITLE, font: FONT, size: 52, bold: true })] }),
  new Paragraph({ spacing: { after: 120 }, alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: "設計書（要件定義・詳細設計・実装仕様・テスト仕様）", font: FONT, size: 26 })] }),
  new Paragraph({ spacing: { after: 960 }, alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: `作成日：${new Date().toLocaleDateString("ja-JP")}　／　構成：${files.length} 文書`, font: FONT, size: 20, color: "595959" })] }),
  new Paragraph({ children: [new PageBreak()] }),
];

const doc = new Document({
  creator: "build-docx.js",
  title: TITLE,
  styles: {
    default: { document: { run: { font: FONT, size: 21 }, paragraph: { spacing: { line: 320 } } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 32, bold: true, color: "1F3864" },
        paragraph: { spacing: { before: 240, after: 160 }, keepNext: true, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 27, bold: true, color: "2F5496" },
        paragraph: { spacing: { before: 280, after: 120 }, keepNext: true, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 23, bold: true, color: "2F5496" },
        paragraph: { spacing: { before: 200, after: 100 }, keepNext: true, outlineLevel: 2 } },
      { id: "Heading4", name: "Heading 4", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 21, bold: true },
        paragraph: { spacing: { before: 160, after: 80 }, keepNext: true, outlineLevel: 3 } },
    ],
  },
  numbering: {
    config: [{
      reference: "bullets",
      levels: [
        { level: 0, format: LevelFormat.BULLET, text: "・", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 360, hanging: 260 } } } },
        { level: 1, format: LevelFormat.BULLET, text: "－", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 260 } } } },
      ],
    }],
  },
  sections: [{
    properties: { page: { size: { width: PAGE_W, height: PAGE_H },
      margin: { top: MARGIN, bottom: MARGIN, left: MARGIN, right: MARGIN } } },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT,
      children: [new TextRun({ text: TITLE, font: FONT, size: 16, color: "7F7F7F" })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: ["- ", PageNumber.CURRENT, " -"], font: FONT, size: 18 })] })] }) },
    children: [...cover, ...body],
  }],
});

Packer.toBuffer(doc).then((buf) => {
  fs.mkdirSync(path.dirname(outFile), { recursive: true });
  fs.writeFileSync(outFile, buf);
  console.log(`作成しました: ${outFile}（${files.length} 文書、${(buf.length / 1024).toFixed(0)} KB）`);
});
