/* ============================================================================
 * check-secrets.js — APIキーの混入を検出する（NFR-04）
 * ----------------------------------------------------------------------------
 * 検査内容:
 *   1. 配布・編集対象のファイルで、apiKey に実値らしき文字列が入っていないか
 *   2. 32桁の16進数（Azureキーの形式に近い文字列）が含まれていないか
 * 検査対象は、リポジトリにコミットされるファイルだけです（config.js は .gitignore 対象）。
 * 見つかった場合は終了コード 1 を返します。
 * ============================================================================ */
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const files = ["index.html", "src/index.html", "src/lib.js", "config.example.js"];

// 許可するプレースホルダー（これらは実値ではない）
const PLACEHOLDER = /^$|ここにキーを入力|mock-key|wrong-key/;

let bad = 0;
for (const f of files) {
  const full = path.join(root, f);
  if (!fs.existsSync(full)) continue;
  const txt = fs.readFileSync(full, "utf8");

  // 1. apiKey: "..." の値を確認
  const re = /apiKey:\s*"([^"]*)"/g;
  let m;
  while ((m = re.exec(txt))) {
    if (!PLACEHOLDER.test(m[1])) {
      console.error(`NG ${f}: apiKey に実値らしき文字列があります`);
      bad++;
    }
  }

  // 2. 32桁の16進数
  if (/\b[0-9a-f]{32}\b/i.test(txt)) {
    console.error(`NG ${f}: 32桁の16進数（キーの可能性）が含まれています`);
    bad++;
  }
}

if (bad === 0) console.log("OK: 秘密情報の混入は検出されませんでした");
process.exit(bad ? 1 : 0);
