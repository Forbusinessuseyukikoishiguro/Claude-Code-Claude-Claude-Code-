/* ============================================================================
 * lib.test.js — src/lib.js の単体テスト（Node.js 標準の node:test を使用）
 * ----------------------------------------------------------------------------
 * 実行: npm test
 * 命名: テスト名の先頭に AC番号（docs/spec.md）を付け、要件との対応を追えるようにする。
 * ============================================================================ */
const test = require("node:test");
const assert = require("node:assert/strict");
const L = require("../../src/lib.js");

test("AC-UT-01a fmtTime: 秒を hh:mm:ss にする（FR-08）", () => {
  assert.equal(L.fmtTime(3725), "01:02:05");
  assert.equal(L.fmtTime(3600), "01:00:00");
  assert.equal(L.fmtTime(0), "00:00:00");
  assert.equal(L.fmtTime(59.9), "00:00:59");
});

test("AC-UT-01b fmtTime: 不正値は 00:00:00 として扱う（NaN・Infinity・undefined・負数）", () => {
  assert.equal(L.fmtTime(NaN), "00:00:00");
  assert.equal(L.fmtTime(Infinity), "00:00:00");
  assert.equal(L.fmtTime(undefined), "00:00:00");
  assert.equal(L.fmtTime(-5), "00:00:00");
});

test("AC-UT-02 fmtSize: MB と KB を正しく表示する（FR-01）", () => {
  assert.equal(L.fmtSize(12582912), "12.0 MB");
  assert.equal(L.fmtSize(1048576), "1.0 MB");
  assert.equal(L.fmtSize(500), "1 KB");
  assert.equal(L.fmtSize(10240), "10 KB");
});

test("AC-UT-03 wavFromFloat: WAVヘッダーとサイズが仕様どおり（FR-07）", () => {
  const n = 100;
  const buf = L.wavFromFloat(new Float32Array(n), 16000);
  const v = new DataView(buf);
  const str = (o, len) => String.fromCharCode(...new Uint8Array(buf, o, len));

  assert.equal(buf.byteLength, 44 + n * 2);
  assert.equal(str(0, 4), "RIFF");
  assert.equal(str(8, 4), "WAVE");
  assert.equal(v.getUint16(20, true), 1, "形式コード 1 = PCM");
  assert.equal(v.getUint16(22, true), 1, "モノラル");
  assert.equal(v.getUint32(24, true), 16000, "サンプリング周波数");
  assert.equal(v.getUint16(34, true), 16, "16bit");
  assert.equal(v.getUint32(40, true), n * 2, "データ長");
});

test("AC-UT-04 wavFromFloat: 範囲外の値は -1〜1 に収めて変換する（クリッピング）", () => {
  const buf = L.wavFromFloat(new Float32Array([2, -2, 0]), 16000);
  const v = new DataView(buf);
  assert.equal(v.getInt16(44, true), 32767);
  assert.equal(v.getInt16(46, true), -32768);
  assert.equal(v.getInt16(48, true), 0);
});

test("AC-UT-05a buildSegments: 端数を含む区間を作り、最後は残りの長さにする（FR-03）", () => {
  const segs = L.buildSegments(3725, 600);
  assert.equal(segs.length, 7);
  assert.equal(segs[0].offset, 0);
  assert.equal(segs[6].offset, 3600);
  assert.equal(segs[6].duration, 125);
  assert.deepEqual(segs.map((s) => s.index), [0, 1, 2, 3, 4, 5, 6]);
});

test("AC-UT-05b buildSegments: 境界値（ちょうど分割・長さ0・分割単位0）", () => {
  assert.equal(L.buildSegments(600, 600).length, 1);
  assert.equal(L.buildSegments(600, 600)[0].duration, 600);
  assert.deepEqual(L.buildSegments(0, 600), []);
  assert.deepEqual(L.buildSegments(100, 0), []);
});

test("AC-UT-06 segmentHeader: 結合時の見出しを仕様どおりに作る（FR-06）", () => {
  const h = L.segmentHeader({ index: 0, offset: 0, duration: 600 });
  assert.equal(h, "--- 第1部（00:00:00〜00:10:00）---");
});

test("AC-UT-07 isRetryable: 再試行する失敗としない失敗を分ける（FR-10）", () => {
  assert.equal(L.isRetryable({ name: "TypeError" }), true);
  assert.equal(L.isRetryable({ status: 429 }), true);
  assert.equal(L.isRetryable({ status: 500 }), true);
  assert.equal(L.isRetryable({ status: 503 }), true);
  assert.equal(L.isRetryable({ status: 400 }), false);
  assert.equal(L.isRetryable({ status: 401 }), false);
  assert.equal(L.isRetryable({ status: 403 }), false);
  assert.equal(L.isRetryable({ name: "AbortError" }), false);
  assert.equal(L.isRetryable(undefined), false);
});

test("AC-UT-08 friendlyError: 失敗の種類ごとに案内を出す（FR-10）", () => {
  assert.ok(L.friendlyError({ name: "TypeError" }).includes("接続"));
  assert.ok(L.friendlyError({ status: 401 }).includes("401"));
  assert.ok(L.friendlyError({ status: 429 }).includes("429"));
  assert.ok(L.friendlyError({ status: 413 }).includes("分割単位"));
  const other = L.friendlyError({ status: 418, detail: "x" });
  assert.ok(other.includes("418") && other.includes("x"));
});

test("AC-UT-09 TimeoutError: 再試行せず、タイムアウトと案内する（FR-10）", () => {
  const t = { name: "TimeoutError" };
  assert.equal(L.isRetryable(t), false);
  assert.ok(L.friendlyError(t).includes("タイムアウト"));
});
