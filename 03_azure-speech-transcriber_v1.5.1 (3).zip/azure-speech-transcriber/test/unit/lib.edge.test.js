/* ============================================================================
 * lib.edge.test.js — 境界値・不正値・性質（プロパティ）の単体テスト
 * ----------------------------------------------------------------------------
 * 目的: 基本のテスト（lib.test.js）では見つからない不具合を探す。
 *   - 浮動小数点の誤差、極端な数値、不正な入力
 *   - 「どんな入力でも守られるべき性質」を、乱数で多数の入力に当てはめる
 * 実行: npm test
 * 乱数は固定の種（seed）を使うため、失敗したときに同じ入力で再現できる。
 * ============================================================================ */
const test = require("node:test");
const assert = require("node:assert/strict");
const L = require("../../src/lib.js");

// 固定の種の乱数（再現性のため）
function rng(seed) {
  let x = seed >>> 0;
  return () => ((x = (Math.imul(x, 1664525) + 1013904223) >>> 0) / 4294967296);
}

test("AC-UT-05c buildSegments: 浮動小数点の誤差で余分な区間を作らない（D1 の回帰）", () => {
  assert.equal(L.buildSegments(600.0000000000001, 600).length, 1);
  assert.equal(L.buildSegments(1200.0000000001, 600).length, 2);
  assert.equal(L.buildSegments(120.00000000000001, 60).length, 2);
});

test("AC-UT-05c buildSegments: 0.3 ÷ 0.1 の誤差でも3区間になる", () => {
  assert.equal(L.buildSegments(0.3, 0.1).length, 3);
});

test("AC-UT-05d buildSegments: 性質。区間の長さの合計は全長に一致し、各区間は正で、分割単位以下", () => {
  const r = rng(42);
  for (let k = 0; k < 2000; k++) {
    const dur = r() * 20000 + 0.5;
    const seg = [60, 300, 600, 1200][Math.floor(r() * 4)];
    const segs = L.buildSegments(dur, seg);
    const sum = segs.reduce((a, s) => a + s.duration, 0);
    assert.ok(Math.abs(sum - dur) < 1e-6, `合計が全長に一致しない（dur=${dur}, seg=${seg}, sum=${sum}）`);
    for (const s of segs) {
      assert.ok(s.duration > 0 && s.duration <= seg + 1e-9, `区間の長さが不正（${s.duration}）`);
    }
    segs.forEach((s, i) => {
      assert.equal(s.index, i);
      assert.ok(Math.abs(s.offset - i * seg) < 1e-9, "開始位置が連続していない");
    });
  }
});

test("AC-UT-05d buildSegments: 不正な分割単位（NaN・文字列・負数）は空の配列", () => {
  assert.deepEqual(L.buildSegments(100, NaN), []);
  assert.deepEqual(L.buildSegments(100, -5), []);
  assert.deepEqual(L.buildSegments(100, "abc"), []);
  assert.deepEqual(L.buildSegments(NaN, 60), []);
});

test("AC-UT-01c fmtTime: 指数表記にならない（巨大な値は 00:00:00）", () => {
  assert.equal(L.fmtTime(1e308), "00:00:00");
  assert.equal(L.fmtTime(1e9), "00:00:00");
  assert.match(L.fmtTime(999999), /^\d{2,}:\d{2}:\d{2}$/);
});

test("AC-UT-01d fmtTime: 性質。秒数を書き出してから読み戻すと元に戻る（整数秒）", () => {
  const r = rng(7);
  for (let k = 0; k < 2000; k++) {
    const sec = Math.floor(r() * 300000);
    const [h, m, s] = L.fmtTime(sec).split(":").map(Number);
    assert.equal(h * 3600 + m * 60 + s, sec, `往復が一致しない: ${sec}`);
  }
});

test("AC-UT-02b fmtSize: 不正値（NaN・負数）は「不明」", () => {
  assert.equal(L.fmtSize(NaN), "不明");
  assert.equal(L.fmtSize(-5), "不明");
  assert.equal(L.fmtSize(Infinity), "不明");
});

test("AC-UT-03b wavFromFloat: 性質。長さは 44 + 2n バイト、データ長は 2n", () => {
  const r = rng(99);
  for (let k = 0; k < 200; k++) {
    const n = Math.floor(r() * 5000);
    const buf = L.wavFromFloat(new Float32Array(n), 16000);
    const v = new DataView(buf);
    assert.equal(buf.byteLength, 44 + 2 * n);
    assert.equal(v.getUint32(40, true), 2 * n);
    assert.equal(v.getUint32(4, true), 36 + 2 * n);
  }
});

test("AC-UT-04b wavFromFloat: 性質。すべての出力は Int16 の範囲に収まる（NaN を含む入力でも崩れない）", () => {
  const input = new Float32Array([NaN, Infinity, -Infinity, 0.5, -0.5, 1e9, -1e9]);
  const buf = L.wavFromFloat(input, 16000);
  const v = new DataView(buf);
  for (let i = 0; i < input.length; i++) {
    const x = v.getInt16(44 + i * 2, true);
    assert.ok(x >= -32768 && x <= 32767);
  }
});

test("AC-UT-07b isRetryable: 中止・タイムアウト・不正な応答は、どれも再試行しない", () => {
  assert.equal(L.isRetryable({ name: "InvalidResponse", status: 200 }), false);
  assert.equal(L.isRetryable({ name: "TimeoutError" }), false);
  assert.equal(L.isRetryable({ name: "AbortError" }), false);
});

test("AC-UT-08b friendlyError: 性質。どんな入力でも、空でない日本語の文字列を返す", () => {
  const r = rng(3);
  const names = ["TypeError", "AbortError", "TimeoutError", "InvalidResponse", "Error", "RangeError", ""];
  const statuses = [undefined, 0, 200, 400, 401, 403, 413, 418, 429, 500, 503];
  for (let k = 0; k < 500; k++) {
    const e = {
      name: names[Math.floor(r() * names.length)],
      status: statuses[Math.floor(r() * statuses.length)],
      detail: r() < 0.5 ? "x".repeat(Math.floor(r() * 300)) : undefined,
      message: r() < 0.5 ? "msg" : undefined,
    };
    const msg = L.friendlyError(e);
    assert.equal(typeof msg, "string");
    assert.ok(msg.length > 0, "空の文言");
    assert.ok(!/undefined|NaN|\[object/.test(msg), `文言が壊れている: ${msg}`);
  }
});

test("AC-UT-08c friendlyError: 不正な応答（200 だが本文が JSON でない）を案内する", () => {
  assert.ok(L.friendlyError({ name: "InvalidResponse", status: 200 }).includes("読み取れ"));
});
