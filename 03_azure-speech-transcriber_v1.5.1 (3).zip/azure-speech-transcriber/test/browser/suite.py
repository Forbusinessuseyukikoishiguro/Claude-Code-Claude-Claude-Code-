#!/usr/bin/env python3
"""
suite.py — ブラウザ試験のスイート（結合・壊しに行く試験・モンキーテスト）

カテゴリ:
  I  結合試験    ：実際の機能どうしの連携（模倣サーバーの応答を制御して確かめる）
  A  壊しに行く試験：不正な入力・想定外の応答・操作の順番違い・連打で、壊れないことを確かめる
  M  モンキーテスト：ランダムな操作を大量に行い、常に守られるべき条件（不変条件）が保たれるかを確かめる

仕組み:
  - 実際の index.html を、一時フォルダから Chromium で開く（配布物そのものを試験する）
  - 模倣サーバー（fault_server）は応答の内容・遅延・失敗の仕方を、試験ごとに切り替えられる
  - 本番のAzure には接続しない（課金なし）

実行:
  python3 test/browser/suite.py            # すべて
  python3 test/browser/suite.py I A        # 一部のカテゴリ
結果: test/results/latest/browser.json（機械可読）と、標準出力（人が読む表）
"""
import json
import os
import random
import shutil
import socket
import subprocess
import sys
SCRIPTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "scripts")
import tempfile
import threading
import time
import urllib.request
from functools import partial
from http.server import BaseHTTPRequestHandler, SimpleHTTPRequestHandler, ThreadingHTTPServer

from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
sys.path.insert(0, SCRIPTS_DIR)
from browser_launch import launch_browser

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
STATIC_PORT, MOCK_PORT, FAULT_PORT = 8100, 8787, 8790
RESULTS = []

# ============================================================================
# 模倣サーバー（応答を試験ごとに切り替えられる）
# ============================================================================
FAULT = {"mode": "ok", "fail_times": 0, "delay": 0.0, "count": 0, "ok_before_fail": 0}
FAULT_LOCK = threading.Lock()


class FaultHandler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Ocp-Apim-Subscription-Key, Content-Type")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS, GET")

    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        # 試験の制御用：/__set?mode=...&fail_times=N&delay=秒 ／ /__count
        from urllib.parse import urlparse, parse_qs
        u = urlparse(self.path)
        if u.path == "/__set":
            q = parse_qs(u.query)
            with FAULT_LOCK:
                FAULT["mode"] = q.get("mode", ["ok"])[0]
                FAULT["fail_times"] = int(q.get("fail_times", ["0"])[0])
                FAULT["delay"] = float(q.get("delay", ["0"])[0])
                FAULT["ok_before_fail"] = int(q.get("ok_before_fail", ["0"])[0])
                FAULT["count"] = 0
            return self._json(200, {"ok": True})
        if u.path == "/__count":
            with FAULT_LOCK:
                return self._json(200, {"count": FAULT["count"]})
        self.send_response(404); self.end_headers()

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0) or 0)
        self.rfile.read(length)  # 本文は読み捨てる（中身は解析しない）
        with FAULT_LOCK:
            FAULT["count"] += 1
            n, mode, fail_times = FAULT["count"], FAULT["mode"], FAULT["fail_times"]
            ok_before = FAULT["ok_before_fail"]
            delay = FAULT["delay"]
        if self.headers.get("Ocp-Apim-Subscription-Key") != "mock-key":
            return self._json(401, {"error": {"code": "401", "message": "Access denied"}})
        if delay:
            time.sleep(delay)
        if mode == "ok":
            return self._json(200, {"combinedPhrases": [{"text": f"【F】応答{n}"}]})
        if mode == "429_once":
            if n <= fail_times:
                return self._json(429, {"error": {"code": "429"}})
            return self._json(200, {"combinedPhrases": [{"text": f"【F】応答{n}"}]})
        if mode == "500_after_ok":
            if n <= ok_before:
                return self._json(200, {"combinedPhrases": [{"text": f"【F】応答{n}"}]})
            return self._json(500, {"error": "boom"})
        if mode == "500":
            return self._json(500, {"error": "boom"})
        if mode == "429":
            return self._json(429, {"error": {"code": "429"}})
        if mode == "400_long":
            return self._json(400, {"error": "x" * 5000})
        if mode == "401":
            return self._json(401, {"error": "bad key"})
        if mode == "nonjson":
            body = b"<html>not json</html>"
            self.send_response(200); self._cors()
            self.send_header("Content-Type", "text/html"); self.send_header("Content-Length", str(len(body)))
            self.end_headers(); self.wfile.write(body)
            return
        if mode == "empty":
            return self._json(200, {"combinedPhrases": []})
        if mode == "xss":
            return self._json(200, {"combinedPhrases": [{"text": '<img src=x onerror="window.__xss=1">'}]})
        if mode == "huge":
            return self._json(200, {"combinedPhrases": [{"text": "あ" * 5000}]})
        if mode == "close":
            # 途中で接続を切る（本文の途中で終わる）
            self.send_response(200); self._cors()
            self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", "500")
            self.end_headers(); self.wfile.write(b'{"combi')
            self.wfile.flush()
            self.connection.close()
            return
        return self._json(500, {"error": "unknown mode"})


class QuietStatic(SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass


def serve(handler_cls, port):
    srv = ThreadingHTTPServer(("127.0.0.1", port), handler_cls)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def fault_set(mode, fail_times=0, delay=0.0, ok_before_fail=0):
    urllib.request.urlopen(
        f"http://127.0.0.1:{FAULT_PORT}/__set?mode={mode}&fail_times={fail_times}&delay={delay}&ok_before_fail={ok_before_fail}",
        timeout=5).read()


def fault_count():
    return json.loads(urllib.request.urlopen(f"http://127.0.0.1:{FAULT_PORT}/__count", timeout=5).read())["count"]


# ============================================================================
# 試験用のサイト（一時フォルダに index.html・config.js・音声を置く）
# ============================================================================
class Site:
    def __init__(self):
        self.dir = tempfile.mkdtemp(prefix="suite-")
        shutil.copy(os.path.join(ROOT, "index.html"), self.dir)
        src = os.path.join(ROOT, "test")
        wav2 = os.path.join(src, "sample-2min.wav")
        if not os.path.exists(wav2):
            subprocess.run(["node", os.path.join(ROOT, "make-test-wav.js"), "2"], cwd=ROOT, check=True)
        wav10 = os.path.join(src, "sample-10min.wav")
        if not os.path.exists(wav10):
            subprocess.run(["node", os.path.join(ROOT, "make-test-wav.js"), "10"], cwd=ROOT, check=True)
        self.files = {}
        for name, path in [("w2", wav2), ("w10", wav10)]:
            dst = os.path.join(self.dir, os.path.basename(path))
            shutil.copy(path, dst)
            self.files[name] = dst
        # 壊れた・不正なファイル
        p = os.path.join(self.dir, "fake.mp3"); open(p, "w", encoding="utf-8").write("これは音声ではありません")
        self.files["fake_mp3"] = p
        p = os.path.join(self.dir, "zero.wav"); open(p, "wb").close(); self.files["zero"] = p
        p = os.path.join(self.dir, "trunc.wav")
        with open(wav2, "rb") as f, open(p, "wb") as g:
            g.write(f.read(1000))
        self.files["trunc"] = p
        p = os.path.join(self.dir, "memo.txt"); open(p, "w", encoding="utf-8").write("メモ")
        self.files["txt"] = p
        p = os.path.join(self.dir, "a" * 200 + ".wav")
        shutil.copy(wav2, p); self.files["longname"] = p
        p = os.path.join(self.dir, "<img src=x onerror=window.__xss=1>.wav")
        shutil.copy(wav2, p); self.files["xssname"] = p

    def config(self, endpoint=f"http://localhost:{FAULT_PORT}", key="mock-key", timeout=60000,
               mem=1500, minutes=1):
        js = f"""window.APP_CONFIG = Object.freeze({{
  endpoint: "{endpoint}",
  apiKey: "{key}",
  apiVersion: "2024-11-15",
  locale: "ja-JP",
  defaultSegmentMinutes: {minutes},
  memWarnMB: {mem},
  requestTimeoutMs: {timeout},
}});"""
        open(os.path.join(self.dir, "config.js"), "w", encoding="utf-8").write(js)

    def close(self):
        shutil.rmtree(self.dir, ignore_errors=True)


SITE = None
BROWSER = None


def open_app(**cfg):
    """新しいブラウザの文脈で、設定を書き換えてアプリを開く"""
    SITE.config(**cfg)
    ctx = BROWSER.new_context()
    page = ctx.new_page()
    errors = []
    page.on("pageerror", lambda e: errors.append(f"pageerror: {e}"))
    page.on("console", lambda m: errors.append(f"console: {m.text}") if m.type == "error" else None)
    page.goto(f"http://localhost:{STATIC_PORT}/index.html?t={time.time()}")
    page.wait_for_load_state("load")
    return ctx, page, errors


def load(page, path):
    page.set_input_files("#file", path)


def wait_info(page, timeout=20000):
    page.wait_for_function("document.getElementById('info-name') || document.getElementById('fileInfo').textContent.length>0", timeout=timeout)
    time.sleep(0.2)


def wait_text(page, sel, sub, timeout=60000):
    page.wait_for_function(f"document.querySelector('{sel}') && document.querySelector('{sel}').textContent.includes({json.dumps(sub)})",
                           timeout=timeout)


def status(page):
    return page.inner_text("#status")


def errtext(page):
    return page.inner_text("#errBox") if page.is_visible("#errBox") else ""


def enabled(page, sel):
    return not page.is_disabled(sel)


def js_click(page, sel):
    page.evaluate("s => document.querySelector(s).click()", sel)


def wait_idle(page, timeout=60000):
    page.wait_for_function("document.getElementById('start').textContent.includes('文字起こしを開始') && !document.getElementById('cancel').disabled === false", timeout=timeout)


def pport_responsive(page):
    return page.evaluate("1+1") == 2


# ============================================================================
# 試験の登録
# ============================================================================
def test(cat, tid, title, expected):
    def deco(fn):
        fn._meta = (cat, tid, title, expected)
        TESTS.append(fn)
        return fn
    return deco


TESTS = []

# ---------------------------------------------------------------- 結合試験 I
@test("I", "I-01", "分割単位を変えると目安が変わり、その値で実行される", "1分→2件、5分→1件。5分で1部になる")
def i01():
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.select_option("#splitMin", "1"); a = page.inner_text("#estimate")
        page.select_option("#splitMin", "5"); b = page.inner_text("#estimate")
        page.click("#start"); wait_text(page, "#status", "完了しました", 60000)
        r = page.input_value("#result")
        ok = "2 件" in a and "1 件" in b and r.count("--- 第") == 1 and "00:00:00〜00:02:00" in r
        return ok, f"{a} / {b} / 見出し数={r.count('--- 第')}"
    finally:
        ctx.close()


@test("I", "I-02", "中止の後、同じ画面で再実行すると、前回の残りが混ざらない", "2部の結果が正しく並び、重複しない")
def i02():
    fault_set("ok", delay=1.0)  # 中止ボタンを押す時間を確保する
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.click("#start")
        page.wait_for_function("document.getElementById('prog').value >= 1", timeout=60000)
        page.click("#cancel"); wait_text(page, "#status", "中止しました", 30000)
        page.click("#start"); wait_text(page, "#status", "完了しました", 60000)
        r = page.input_value("#result")
        ok = r.count("--- 第") == 2 and r.count("--- 第1部") == 1
        return ok, f"見出し数={r.count('--- 第')}"
    finally:
        ctx.close()


@test("I", "I-03", "一時的な429の後、再試行して最後まで完了する", "区間数分の成功と、送信は1回多い（再試行1回）")
def i03():
    fault_set("429_once", fail_times=1)
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.click("#start"); wait_text(page, "#status", "完了しました", 60000)
        r = page.input_value("#result")
        n = fault_count()
        return r.count("--- 第") == 2 and n == 3, f"見出し={r.count('--- 第')}、送信回数={n}"
    finally:
        ctx.close()


@test("I", "I-04", "2回目の実行で、結果欄が前回の内容に追加されない", "見出しは常に区間数と一致")
def i04():
    fault_set("ok")
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.click("#start"); wait_text(page, "#status", "完了しました", 60000)
        page.click("#start"); wait_text(page, "#status", "完了しました", 60000)
        return page.input_value("#result").count("--- 第") == 2, "2回目の見出し数"
    finally:
        ctx.close()


@test("I", "I-05", "途中で失敗しても、完了した部分は残り、その旨を案内する", "1部だけ残り、案内に「1/2部」と出る。コピーは有効")
def i05():
    fault_set("500_after_ok", ok_before_fail=1)
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.click("#start")
        page.wait_for_function("!document.getElementById('errBox').hidden", timeout=60000)
        msg = errtext(page); r = page.input_value("#result")
        ok = r.count("--- 第") == 1 and "1/2部までの結果は残しています" in msg and enabled(page, "#copy")
        return ok, msg[-40:]
    finally:
        ctx.close()


@test("I", "I-06", "メモリのしきい値を超えると警告、下回れば非表示", "しきい値 1MB で警告が出る")
def i06():
    ctx, page, errs = open_app(mem=1, minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        shown = page.is_visible("#memWarn")
        return shown, f"警告表示={shown}"
    finally:
        ctx.close()


@test("I", "I-07", "APIキーが初期値のままなら、開始できず案内が出る", "開始は無効、状態に「設定未完了」")
def i07():
    ctx, page, errs = open_app(key="ここにキーを入力", minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        dis = not enabled(page, "#start")
        return dis and "設定未完了" in (status(page) + errtext(page)), f"開始無効={dis}"
    finally:
        ctx.close()

# ---------------------------------------------------------------- 壊しに行く試験 A
@test("A", "A-01", "拡張子が mp3 でも中身が音声でなければ、読み込みを拒否する", "「読み込めませんでした」。開始は無効")
def a01():
    ctx, page, errs = open_app()
    try:
        load(page, SITE.files["fake_mp3"]); page.wait_for_function("!document.getElementById('errBox').hidden", timeout=20000)
        return "読み込めませんでした" in errtext(page) and not enabled(page, "#start"), errtext(page)[:30]
    finally:
        ctx.close()


@test("A", "A-02", "0バイトの WAV を拒否する", "読み込みエラー。アプリが止まらない")
def a02():
    ctx, page, errs = open_app()
    try:
        load(page, SITE.files["zero"]); page.wait_for_function("!document.getElementById('errBox').hidden", timeout=20000)
        return "読み込めませんでした" in errtext(page), errtext(page)[:30]
    finally:
        ctx.close()


@test("A", "A-03", "途中で切れた WAV（先頭1000バイト）で、画面が固まらない", "エラーか、何らかの状態表示が出る。例外で止まらない")
def a03():
    ctx, page, errs = open_app()
    try:
        load(page, SITE.files["trunc"])
        time.sleep(3)
        responsive = pport_responsive(page)
        shown = (not page.is_hidden("#errBox")) or ("" != page.inner_text("#fileInfo")) or ("" != status(page))
        return responsive and shown, f"応答={responsive}"
    finally:
        ctx.close()


@test("A", "A-04", "音声以外のファイル（.txt）を拒否する", "「音声ファイルを選択してください」")
def a04():
    ctx, page, errs = open_app()
    try:
        load(page, SITE.files["txt"]); page.wait_for_function("!document.getElementById('errBox').hidden", timeout=10000)
        return "音声ファイルを選択" in errtext(page), errtext(page)[:30]
    finally:
        ctx.close()


@test("A", "A-05", "ファイル名に HTML を含んでも、画面に実行されず文字として表示される", "img 要素が作られない。__xss は未定義")
def a05():
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["xssname"]); wait_text(page, "#fileInfo", "再生時間")
        imgs = page.evaluate("document.querySelectorAll('#fileInfo img').length")
        xss = page.evaluate("typeof window.__xss")
        text_ok = "<img" in page.inner_text("#fileInfo")
        return imgs == 0 and xss == "undefined" and text_ok, f"img={imgs} xss={xss}"
    finally:
        ctx.close()


@test("A", "A-06", "開始ボタンを連打しても、二重に実行されない", "送信は区間数（2）と一致")
def a06():
    fault_set("ok")
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        for _ in range(5):
            js_click(page, "#start")
        wait_text(page, "#status", "完了しました", 60000)
        n = fault_count()
        return n == 2, f"送信回数={n}"
    finally:
        ctx.close()


@test("A", "A-07", "処理中にファイルを差し替えようとしても、拒否される", "状態に「文字起こし中」。表示のファイル名は変わらない")
def a07():
    fault_set("ok", delay=1.0)
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.click("#start")
        page.wait_for_function("document.getElementById('cancel').disabled === false", timeout=10000)
        load(page, SITE.files["longname"]); time.sleep(0.5)
        msg = status(page); name = page.inner_text("#info-name") if page.is_visible("#info-name") else page.inner_text("#fileInfo")
        ok = "文字起こし中" in msg and "sample-2min.wav" in name
        page.click("#cancel"); time.sleep(0.5)
        return ok, f"状態={msg[:20]}"
    finally:
        ctx.close()


@test("A", "A-08", "接続先が不正（http(s) の URL でない）なら、送信せずに設定の不備を案内する", "開始は無効。「設定未完了」。送信は0回")
def a08():
    fault_set("ok")
    ctx, page, errs = open_app(endpoint="not a url", minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        dis = not enabled(page, "#start")
        msg = status(page) + errtext(page)
        return dis and "設定未完了" in msg and fault_count() == 0, msg[:30]
    finally:
        ctx.close()


@test("A", "A-09", "常に500が返る場合、3回で打ち切り、理由を示す", "送信は3回。エラーに 500 を含む")
def a09():
    fault_set("500")
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.click("#start")
        page.wait_for_function("!document.getElementById('errBox').hidden", timeout=60000)
        n = fault_count()
        return n == 3 and "500" in errtext(page), f"送信={n}"
    finally:
        ctx.close()


@test("A", "A-10", "400 の長い本文は、表示を200文字程度で切る", "エラー文が 300 文字以内")
def a10():
    fault_set("400_long")
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.click("#start")
        page.wait_for_function("!document.getElementById('errBox').hidden", timeout=60000)
        L = len(errtext(page))
        return L <= 300, f"文字数={L}"
    finally:
        ctx.close()


@test("A", "A-11", "200 でも本文が JSON でなければ、専門の案内を出す（生のエラー文を出さない）", "「読み取れませんでした」を含む。Unexpected token を含まない")
def a11():
    fault_set("nonjson")
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.click("#start")
        page.wait_for_function("!document.getElementById('errBox').hidden", timeout=60000)
        msg = errtext(page)
        return "読み取れませんでした" in msg and "Unexpected" not in msg, msg[:30]
    finally:
        ctx.close()


@test("A", "A-12", "応答が制限時間を超えたら、タイムアウトとして扱い、再試行しない", "「タイムアウト」。送信は1回")
def a12():
    fault_set("ok", delay=4.0)
    ctx, page, errs = open_app(timeout=1500, minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.click("#start")
        page.wait_for_function("!document.getElementById('errBox').hidden", timeout=60000)
        n = fault_count()
        return "タイムアウト" in errtext(page) and n == 1, f"送信={n}"
    finally:
        ctx.close()


@test("A", "A-13", "本文の途中で接続が切れても、接続エラーとして扱い、3回で止まる", "「接続できません」。送信は3回")
def a13():
    fault_set("close")
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.click("#start")
        page.wait_for_function("!document.getElementById('errBox').hidden", timeout=90000)
        n = fault_count()
        return "接続できません" in errtext(page) and n == 3, f"送信={n} 案内={errtext(page)[:12]}"
    finally:
        ctx.close()


@test("A", "A-14", "再試行の待ち時間に中止すると、すぐ止まり、以後の送信がない", "中止後 1.5 秒以内に「中止しました」。送信数は増えない")
def a14():
    fault_set("429")
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.click("#start")
        page.wait_for_function("document.getElementById('status').textContent.includes('再試行中')", timeout=30000)
        before = fault_count()
        t0 = time.time(); page.click("#cancel")
        page.wait_for_function("document.getElementById('status').textContent.includes('中止しました')", timeout=5000)
        dt = time.time() - t0
        time.sleep(3)
        after = fault_count()
        return dt < 1.5 and after == before, f"中止まで{dt:.2f}秒、送信 {before}→{after}"
    finally:
        ctx.close()


@test("A", "A-15", "中止ボタンを大量に押しても、例外が出ない", "ページエラーなし")
def a15():
    fault_set("ok", delay=1.0)
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.click("#start")
        for _ in range(20):
            js_click(page, "#cancel")
        time.sleep(2)
        return not any(e.startswith("pageerror") for e in errs), "; ".join(errs)[:80]
    finally:
        ctx.close()


@test("A", "A-16", "認識結果が空の区間は、空だと分かる文言を出す", "「認識結果はありませんでした」")
def a16():
    fault_set("empty")
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.click("#start"); wait_text(page, "#status", "完了しました", 60000)
        return "認識結果はありませんでした" in page.input_value("#result"), "結果欄"
    finally:
        ctx.close()


@test("A", "A-17", "応答に HTML が含まれても、実行されず文字として表示される", "結果欄に <img が文字で出る。img 要素と __xss はない")
def a17():
    fault_set("xss")
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.click("#start"); wait_text(page, "#status", "完了しました", 60000)
        val = page.input_value("#result")
        xss = page.evaluate("typeof window.__xss")
        return "<img" in val and xss == "undefined" and page.evaluate("document.querySelectorAll('#result img').length") == 0, f"xss={xss}"
    finally:
        ctx.close()


@test("A", "A-18", "分割単位の値を書き換えられても、0部の「完了」にならず、止まる", "「分割単位の値が不正」。送信は0回")
def a18():
    fault_set("ok")
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.evaluate("document.getElementById('splitMin').value = 'x'")
        page.click("#start")
        page.wait_for_function("!document.getElementById('errBox').hidden", timeout=20000)
        n = fault_count()
        return "分割単位の値が不正" in errtext(page) and n == 0 and "完了しました" not in status(page), f"送信={n}"
    finally:
        ctx.close()


@test("A", "A-19", "メモリ警告のしきい値が0でも、処理は続けられる（警告のみ）", "警告が出て、開始は押せる")
def a19():
    ctx, page, errs = open_app(mem=0, minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        return page.is_visible("#memWarn") and enabled(page, "#start"), "警告と開始"
    finally:
        ctx.close()


@test("A", "A-20", "連続して別のファイルを選ぶと、最後に選んだファイルの情報が残る（競合の防止）", "情報欄は最後のファイル名")
def a20():
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w10"])
        load(page, SITE.files["w2"])
        wait_text(page, "#fileInfo", "sample-2min.wav", 60000)
        time.sleep(4)  # 遅い方の読み込みが後から終わる余地を与える
        info = page.inner_text("#fileInfo")
        return "sample-2min.wav" in info and "10min" not in info, info[:40]
    finally:
        ctx.close()


@test("A", "A-21", "5000文字の応答でも画面は応答し、全文が結果欄に入る", "結果の文字数が 5000 以上")
def a21():
    fault_set("huge")
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["w2"]); wait_text(page, "#fileInfo", "再生時間")
        page.click("#start"); wait_text(page, "#status", "完了しました", 60000)
        L = len(page.input_value("#result"))
        return L >= 5000 and pport_responsive(page), f"文字数={L}"
    finally:
        ctx.close()


@test("A", "A-22", "200文字のファイル名でも、保存名が作られる", "保存名は 200 文字の名前 + .txt")
def a22():
    fault_set("ok")
    ctx, page, errs = open_app(minutes=1)
    try:
        load(page, SITE.files["longname"]); wait_text(page, "#fileInfo", "再生時間")
        page.click("#start"); wait_text(page, "#status", "完了しました", 60000)
        with page.expect_download(timeout=20000) as dl:
            page.click("#save")
        name = dl.value.suggested_filename
        return name == "a" * 200 + ".txt", f"保存名の長さ={len(name)}"
    finally:
        ctx.close()


@test("A", "A-23", "結果がまだ無いときは、コピーと保存が押せない", "両方とも無効")
def a23():
    ctx, page, errs = open_app(minutes=1)
    try:
        return (not enabled(page, "#copy")) and (not enabled(page, "#save")), "初期状態"
    finally:
        ctx.close()


@test("A", "A-24", "ファイルを選ぶ前に Space を押しても、何も起きない", "再生の状態にならず、例外もない")
def a24():
    ctx, page, errs = open_app(minutes=1)
    try:
        page.keyboard.press("Space"); time.sleep(0.5)
        return not any(e.startswith("pageerror") for e in errs), "例外の有無"
    finally:
        ctx.close()

# ---------------------------------------------------------------- モンキーテスト M
ACTIONS = ["load", "load", "split", "start", "start", "cancel", "copy", "save", "space", "digit", "mode", "wait", "reload"]
MODES = ["ok", "ok", "429", "500", "nonjson", "empty", "xss", "huge", "400_long"]


def invariants(page, errs, step, log):
    problems = []
    if any(e.startswith("pageerror") for e in errs):
        problems.append("ページの例外: " + [e for e in errs if e.startswith("pageerror")][-1][:80])
    try:
        if not pport_responsive(page):
            problems.append("応答しない")
    except Exception as e:
        problems.append(f"評価できない: {str(e)[:60]}")
        return problems
    body = page.inner_text("body")
    for bad in ("undefined", "NaN", "[object"):
        if bad in body:
            problems.append(f"画面に '{bad}' が出ている")
    cancel_on = enabled(page, "#cancel")
    if cancel_on and enabled(page, "#start"):
        problems.append("処理中なのに開始が押せる")
    if cancel_on and enabled(page, "#file"):
        problems.append("処理中なのにファイルを選べる")
    if enabled(page, "#copy") and not page.input_value("#result").strip():
        problems.append("結果が空なのにコピーが押せる")
    if page.evaluate("typeof window.__xss") != "undefined":
        problems.append("HTML が実行された")
    return problems


def monkey_run(seed, steps):
    rnd = random.Random(seed)
    fault_set("ok")
    ctx, page, errs = open_app(minutes=1, timeout=8000)
    log, problems = [], []
    file_keys = ["w2", "fake_mp3", "zero", "trunc", "txt", "longname"]
    try:
        for step in range(steps):
            act = rnd.choice(ACTIONS)
            try:
                if act == "load":
                    k = rnd.choice(file_keys); load(page, SITE.files[k]); log.append(f"load:{k}")
                elif act == "split":
                    v = rnd.choice(["1", "5", "10", "x"])
                    if v == "x":
                        page.evaluate("document.getElementById('splitMin').value = 'x'")
                    else:
                        page.select_option("#splitMin", v)
                    log.append(f"split:{v}")
                elif act == "start":
                    js_click(page, "#start"); log.append("start")
                elif act == "cancel":
                    js_click(page, "#cancel"); log.append("cancel")
                elif act == "copy":
                    js_click(page, "#copy"); log.append("copy")
                elif act == "save":
                    js_click(page, "#save"); log.append("save")
                elif act == "space":
                    page.keyboard.press("Space"); log.append("space")
                elif act == "digit":
                    d = rnd.choice("123456789"); page.keyboard.press(d); log.append(f"key:{d}")
                elif act == "mode":
                    m = rnd.choice(MODES); fault_set(m, fail_times=1, delay=0.2 if m == "ok" and rnd.random() < 0.3 else 0)
                    log.append(f"mode:{m}")
                elif act == "wait":
                    time.sleep(rnd.uniform(0, 0.4)); log.append("wait")
                elif act == "reload":
                    page.reload(); page.wait_for_load_state("load"); log.append("reload")
            except PWTimeout:
                log.append("timeout(操作対象が無い・無効)")
            except Exception as e:
                # 操作の失敗そのものは試験の失敗ではないが、記録する
                log.append(f"op-error:{type(e).__name__}")
            time.sleep(rnd.uniform(0, 0.15))
            for p in invariants(page, errs, step, log):
                problems.append(f"step {step} after {log[-1]}: {p}")
                if len(problems) >= 3:
                    break
            if len(problems) >= 3:
                break
        # 最後に、処理中なら中止して、収束することを確かめる
        if enabled(page, "#cancel"):
            js_click(page, "#cancel")
            page.wait_for_function("!document.getElementById('cancel').disabled", timeout=30000)
        if not pport_responsive(page):
            problems.append("最後まで応答しない")
    finally:
        ctx.close()
    return problems, log


@test("M", "M-01", "ランダム操作（seed=1、60手）で、画面の不変条件が保たれる", "不変条件違反なし、例外なし")
def m01():
    p, log = monkey_run(1, 60)
    return not p, (p[0] if p else f"{len(log)}手完了")


@test("M", "M-02", "ランダム操作（seed=2、60手）で、画面の不変条件が保たれる", "不変条件違反なし、例外なし")
def m02():
    p, log = monkey_run(2, 60)
    return not p, (p[0] if p else f"{len(log)}手完了")


@test("M", "M-03", "ランダム操作（seed=3、60手）で、画面の不変条件が保たれる", "不変条件違反なし、例外なし")
def m03():
    p, log = monkey_run(3, 60)
    return not p, (p[0] if p else f"{len(log)}手完了")

# ============================================================================
# 実行
# ============================================================================
def record(meta, ok, detail, ms):
    cat, tid, title, expected = meta
    RESULTS.append({"cat": cat, "id": tid, "title": title, "expected": expected,
                    "result": "合格" if ok else "不合格", "detail": str(detail)[:300], "ms": ms})
    print(f"[{'合' if ok else '否'}] {tid} {title}  ({ms} ms) {detail if not ok else ''}", flush=True)


def main():
    global SITE, BROWSER
    only = set(sys.argv[1:]) or {"I", "A", "M"}
    SITE = Site()
    serve(partial(QuietStatic, directory=SITE.dir), STATIC_PORT)
    serve(FaultHandler, FAULT_PORT)
    time.sleep(0.5)
    try:
        with sync_playwright() as p:
            BROWSER = launch_browser(p)
            for fn in TESTS:
                cat = fn._meta[0]
                if cat not in only:
                    continue
                t0 = time.time()
                try:
                    ok, detail = fn()
                except Exception as e:
                    ok, detail = False, f"例外: {type(e).__name__}: {str(e)[:120]}"
                record(fn._meta, bool(ok), detail, int((time.time() - t0) * 1000))
            BROWSER.close()
    finally:
        out_dir = os.path.join(ROOT, "test", "results", "latest")
        os.makedirs(out_dir, exist_ok=True)
        with open(os.path.join(out_dir, "browser.json"), "w", encoding="utf-8") as f:
            json.dump(RESULTS, f, ensure_ascii=False, indent=2)
        SITE.close()
    fails = [r for r in RESULTS if r["result"] != "合格"]
    print(f"\n== ブラウザ試験：合格 {len(RESULTS) - len(fails)} / {len(RESULTS)} ==")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
