/* config.example.js — 設定ファイルの雛形（リポジトリにはこちらをコミットする）
 * 使い方: このファイルを config.js にコピーし、endpoint と apiKey を入れる。
 * config.js は .gitignore 対象のため、コミットされません（NFR-04）。 */
window.APP_CONFIG = Object.freeze({
  endpoint: "https://japaneast.api.cognitive.microsoft.com",
  apiKey: "ここにキーを入力",
  apiVersion: "2024-11-15",          // OQ-01 未確定。公式で確認すること
  locale: "ja-JP",
  defaultSegmentMinutes: 10,
  memWarnMB: 1500,
  requestTimeoutMs: 300000,
});
