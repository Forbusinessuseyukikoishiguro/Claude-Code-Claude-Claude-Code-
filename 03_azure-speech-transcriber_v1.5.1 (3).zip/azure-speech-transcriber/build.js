/* ============================================================================
 * build.js — 配布用 index.html を生成する
 * ----------------------------------------------------------------------------
 * 入力:  src/index.html（テンプレート）と src/lib.js（純粋関数）
 * 出力:  index.html（配布用・単一ファイル。直接編集しないこと）
 *
 * 仕組み:
 *   テンプレート内のマーカー <!--@INLINE lib--> を、lib.js の中身に置き換える。
 *   これにより、開発時はモジュールとして分けつつ、配布時は1枚のHTMLにまとまる（NFR-05）。
 *
 * 使い方: node build.js
 * ============================================================================ */
const fs = require("fs");
const path = require("path");

const root = __dirname;
const MARK = "<!--@INLINE lib-->";

const tpl = fs.readFileSync(path.join(root, "src", "index.html"), "utf8");
const lib = fs.readFileSync(path.join(root, "src", "lib.js"), "utf8");

if (!tpl.includes(MARK)) {
  throw new Error(`テンプレートに ${MARK} がありません（src/index.html を確認）`);
}

// 関数形式で置換する（文字列置換だと lib 内の $ が特殊扱いされるのを防ぐ）
const out = tpl.replace(MARK, () => `<script>\n${lib}\n</script>`);
fs.writeFileSync(path.join(root, "index.html"), out, "utf8");
console.log(`built index.html（${out.length} 文字）`);
