---
name: evidence-collect
description: Azure Speech 文字起こしツールの試験結果と証跡を回収し、報告書（report.md）と manifest.json にまとめる。「回収して」「証跡をまとめて」「試験結果を報告書に」「テスト結果を集めて」「報告書を作って」などの依頼で使う。APIキー・音声ファイルは回収しない。合否の確定は人が行う。
---

# 証跡の回収（evidence-collect）

このスキルは、試験を実行し、その結果を `test/results/<日時>/` に回収する。
**新しい試験の内容は作らない。既存の試験（npm run verify、scripts/e2e_smoke.py）を実行して記録する。**

## 前提
- 作業フォルダは `azure-speech-transcriber/`（`package.json` と `scripts/collect-evidence.js` がある）
- Node.js 18 以上。ブラウザ試験には Python 3 と `playwright`、Chromium が必要
- 実Azureへの接続はしない（課金を発生させない）

## 手順
1. **前提の確認**
   - `scripts/collect-evidence.js` と `docs/spec.md` が存在するか確認する。無ければ中止して利用者に伝える。
   - `git ls-files config.js config.real.js` の結果が空であることを確認する。空でなければ、回収を止めて利用者に報告する（APIキーが追跡されている恐れ）。
2. **回収の実行**
   - 既定：`node scripts/collect-evidence.js`（verify のみ）
   - ブラウザ試験も含める：`node scripts/collect-evidence.js --e2e`
   - メモリ計測の結果も含める：`node scripts/collect-evidence.js --e2e --measurements`
   - 利用者が「ブラウザ試験は不要」と言った場合は `--e2e` を付けない。
3. **結果の読み取り**
   - `test/results/<日時>/manifest.json` の `judgment`、`steps`、`e2e`、`secretScan` を読む。
   - `report.md` の内容を確認する。
4. **利用者への報告（日本語・簡潔に）**
   - 自動判定（候補）と、手順ごとの合否を伝える。
   - 不合格の手順は、ログ（verify.log / e2e.log）の該当行を**最初のエラーだけ**引用する。
   - 「この回収では確認していない項目」（report.md の §5）を必ず添える。
   - 合格と書くのは、実行した手順だけ。未実行の項目は「未実行」と書く。

## 禁止事項
- `config.js`・`config.real.js`・`*.wav` を結果フォルダへコピーしない。
- 試験結果を推測で書かない。ログにない結果を「合格」と書かない。
- 失敗した試験を、回収のついでに直さない。修正は別の作業として、利用者に依頼を確認する。
- 秘密情報が検出された場合、フォルダを共有しないよう利用者に伝え、manifest.json の `secretScan` を示す。
- 判定欄（report.md §6）は人が記入する。スキルが「合格」と確定させない。

## 失敗時の一次切り分け
| 失敗した手順 | 確認場所 | よくある原因 |
|---|---|---|
| verify（build） | verify.log の先頭 | src/ の構文エラー、テンプレートのマーカー欠落 |
| verify（test） | verify.log の `not ok` | lib.js の変更と単体テストの不一致 |
| verify（check） | verify.log と report.md §3 | apiKey に実値、32桁の16進数の混入 |
| e2e | e2e.log の `[否]` 行 | 画面の変更、モックの未起動、Chromium 未導入 |

## 参照
- 手順書：`docs/evidence-guide.md`
- 仕様：`docs/spec.md`（AC番号は報告書の表と対応させる）
