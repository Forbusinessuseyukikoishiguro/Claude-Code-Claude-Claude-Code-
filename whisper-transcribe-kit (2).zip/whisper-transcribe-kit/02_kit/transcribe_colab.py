"""③ Google Colab 用（large-v3 / T4 GPU）。セルごとに貼り付けて実行。

■ 事前: ランタイム → ランタイムのタイプを変更 → T4 GPU
■ 注意: 音声は Google のサービス上にアップロードされます（機密音声は使わない）
■ 終了時: ランタイムを切断し、アップロードした音声と result.txt を削除

--- セル1 ---
!pip install -q faster-whisper==1.2.1

--- セル2（以下） ---
"""
from faster_whisper import WhisperModel

model = WhisperModel("large-v3", device="cuda", compute_type="float16")

segments, info = model.transcribe(
    "sample.mp3", language="ja", beam_size=5,
    vad_filter=True,            # 無音区間での誤認識を減らす
    # initial_prompt="専門用語1, 専門用語2",
)

lines = []
for seg in segments:
    line = f"[{seg.start:.1f}s - {seg.end:.1f}s] {seg.text.strip()}"
    print(line)
    lines.append(line)

with open("result.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(lines))
