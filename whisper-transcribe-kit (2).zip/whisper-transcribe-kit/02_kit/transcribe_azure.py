"""② Azure OpenAI で文字起こし（model= にはデプロイ名を指定）
使い方:  python transcribe_azure.py sample.mp3
認証:    既定は API キー。キーレス（Entra ID）にしたい場合は USE_ENTRA=1 を環境変数に設定
"""
import os
import sys

from dotenv import load_dotenv
from openai import AzureOpenAI

from common import check_size, collect_files, save_text


def build_client() -> AzureOpenAI:
    endpoint = os.environ["AZURE_OPENAI_ENDPOINT"]
    version = os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-01")
    if os.environ.get("USE_ENTRA") == "1":
        from azure.identity import DefaultAzureCredential, get_bearer_token_provider

        provider = get_bearer_token_provider(
            DefaultAzureCredential(), "https://cognitiveservices.azure.com/.default"
        )
        return AzureOpenAI(azure_endpoint=endpoint, api_version=version,
                           azure_ad_token_provider=provider, timeout=120, max_retries=3)
    return AzureOpenAI(azure_endpoint=endpoint, api_version=version,
                       api_key=os.environ["AZURE_OPENAI_API_KEY"], timeout=120, max_retries=3)


def main() -> None:
    if len(sys.argv) < 2:
        sys.exit("使い方: python transcribe_azure.py <音声ファイル or フォルダ>")
    load_dotenv()
    required = ["AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_DEPLOYMENT"]
    if os.environ.get("USE_ENTRA") != "1":
        required.append("AZURE_OPENAI_API_KEY")
    for key in required:
        if not os.environ.get(key):
            sys.exit(f"[エラー] .env に {key} がありません")
    files = collect_files(sys.argv[1])
    check_size(files)

    client = build_client()
    deployment = os.environ["AZURE_OPENAI_DEPLOYMENT"]  # モデル名ではなくデプロイ名
    texts = []
    for f in files:
        print(f"処理中: {f.name}")
        with open(f, "rb") as fp:
            result = client.audio.transcriptions.create(model=deployment, file=fp, language="ja")
        texts.append(result.text)

    out = save_text("\n".join(texts), files[0].stem)
    print(f"完了 → {out}")


if __name__ == "__main__":
    main()
