"""④ ローカル（faster-whisper）で文字起こし。音声は外部に送信されません。
使い方:
  python transcribe_local.py sample.mp3                       （CPU / small）
  python transcribe_local.py sample.mp3 --device cuda --model large-v3
  python transcribe_local.py sample.mp3 --prompt "Whisper, Azure, VSCode"   （用語ヒント）
"""
import argparse

from faster_whisper import WhisperModel

from common import collect_files, save_text


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("target", help="音声ファイル or フォルダ")
    ap.add_argument("--model", default="small", help="small / medium / large-v3 など")
    ap.add_argument("--device", default="cpu", choices=["cpu", "cuda"])
    ap.add_argument("--prompt", default=None, help="専門用語のヒント（initial_prompt）")
    ap.add_argument("--no-vad", action="store_true", help="無音除去（VAD）を切る")
    args = ap.parse_args()

    compute = "float16" if args.device == "cuda" else "int8"
    print(f"モデル読み込み: {args.model} / {args.device} / {compute}（初回はダウンロードあり）")
    model = WhisperModel(args.model, device=args.device, compute_type=compute)

    files = collect_files(args.target)
    lines = []
    for f in files:
        print(f"処理中: {f.name}")
        segments, info = model.transcribe(
            str(f), language="ja", beam_size=5,
            vad_filter=not args.no_vad,        # 無音区間での誤認識（幻覚）を減らす
            initial_prompt=args.prompt,
        )
        for seg in segments:
            line = f"[{seg.start:7.1f}s - {seg.end:7.1f}s] {seg.text.strip()}"
            print(line)
            lines.append(line)

    out = save_text("\n".join(lines), files[0].stem)
    print(f"完了 → {out}")


if __name__ == "__main__":
    main()
