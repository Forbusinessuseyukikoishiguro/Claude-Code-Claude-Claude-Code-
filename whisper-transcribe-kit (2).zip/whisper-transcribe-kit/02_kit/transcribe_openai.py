"""① OpenAI API で文字起こし
使い方:  python transcribe_openai.py sample.mp3
         python transcribe_openai.py parts      （フォルダ指定：名前順に連結）
"""
import sys

import os

from dotenv import load_dotenv
from openai import OpenAI

from common import check_size, collect_files, save_text

MODEL = "whisper-1"  # 新しいモデルは公式ドキュメントで確認して差し替え


def main() -> None:
    if len(sys.argv) < 2:
        sys.exit("使い方: python transcribe_openai.py <音声ファイル or フォルダ>")
    load_dotenv()
    if not os.environ.get("OPENAI_API_KEY"):
        sys.exit("[エラー] OPENAI_API_KEY がありません。.env を確認してください（.env.example を参照）")
    files = collect_files(sys.argv[1])
    check_size(files)

    client = OpenAI(timeout=120, max_retries=3)  # OPENAI_API_KEY を自動で読む
    texts = []
    for f in files:
        print(f"処理中: {f.name}")
        with open(f, "rb") as fp:
            result = client.audio.transcriptions.create(model=MODEL, file=fp, language="ja")
        texts.append(result.text)

    out = save_text("\n".join(texts), files[0].stem)
    print(f"完了 → {out}")


if __name__ == "__main__":
    main()
