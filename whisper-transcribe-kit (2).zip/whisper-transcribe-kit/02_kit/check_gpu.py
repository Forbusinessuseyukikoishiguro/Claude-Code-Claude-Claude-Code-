"""GPU を使えるかの事前確認（④で large-v3 を GPU 実行する前に）"""
import ctranslate2

n = ctranslate2.get_cuda_device_count()
print(f"CUDA デバイス数: {n}")
if n == 0:
    print("→ GPU を使えません。device='cpu'（small 推奨）か、Colab（③）を使ってください。")
else:
    print("→ GPU を認識しています。transcribe_local.py --device cuda --model large-v3 を試せます。")
    print("  ※ 実行時に cublas / cudnn の DLL エラーが出る場合は、教材の「GPU 手順」を確認。")
