"""長い音声を、API の上限（25MB）に収まるよう分割する（ffmpeg が必要）

使い方:  python split_audio.py 会議.mp3 [分割秒数(既定600)]
出力:    parts/ フォルダに part_000.mp3, part_001.mp3 ...
方式:    モノラル・64kbps の mp3 に変換して、指定秒数ごとに分割
注意:    時間で機械的に切るため、区切り位置で単語が欠けることがある
"""
import shutil
import subprocess
import sys
from pathlib import Path


def main() -> None:
    if len(sys.argv) < 2:
        sys.exit("使い方: python split_audio.py <音声ファイル> [分割秒数]")
    src = Path(sys.argv[1])
    seconds = int(sys.argv[2]) if len(sys.argv) > 2 else 600
    if not src.is_file():
        sys.exit(f"[エラー] 見つかりません: {src}")
    if shutil.which("ffmpeg") is None:
        sys.exit("[エラー] ffmpeg が見つかりません。PowerShell で: winget install Gyan.FFmpeg（入れ直し後に VSCode を再起動）")

    out_dir = Path("parts")
    out_dir.mkdir(exist_ok=True)
    for old in out_dir.glob("part_*.mp3"):  # 前回の分割結果が混ざらないよう削除
        old.unlink()
    cmd = [
        "ffmpeg", "-y", "-loglevel", "error", "-i", str(src),
        "-vn", "-ac", "1", "-c:a", "libmp3lame", "-b:a", "64k",
        "-f", "segment", "-segment_time", str(seconds), "-reset_timestamps", "1",
        str(out_dir / "part_%03d.mp3"),
    ]
    subprocess.run(cmd, check=True)
    parts = sorted(out_dir.glob("part_*.mp3"))
    for p in list(parts):  # 末尾に生じる極小ファイル（2KB未満）は API エラーの元なので削除
        if p.stat().st_size < 2048:
            p.unlink()
            parts.remove(p)
    print(f"{len(parts)} 個に分割しました（{out_dir}/）")
    for p in parts:
        print(f"  {p.name}: {p.stat().st_size / 1024 / 1024:.1f} MB")


if __name__ == "__main__":
    main()
