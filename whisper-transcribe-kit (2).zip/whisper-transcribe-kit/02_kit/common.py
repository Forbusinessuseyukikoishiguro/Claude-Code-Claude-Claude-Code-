"""共通処理：ファイル収集・サイズチェック・結果保存"""
import sys
from pathlib import Path

MAX_BYTES = 25 * 1024 * 1024  # OpenAI / Azure OpenAI のファイル上限（25MB）
AUDIO_EXT = {".mp3", ".wav", ".m4a", ".mp4", ".mpeg", ".mpga", ".webm", ".ogg", ".flac"}


def collect_files(target: str) -> list[Path]:
    """ファイル1つ、またはフォルダ内の音声ファイルを名前順で返す"""
    p = Path(target)
    if not p.exists():
        sys.exit(f"[エラー] 見つかりません: {p}")
    if p.is_file():
        return [p]
    files = sorted(f for f in p.iterdir() if f.suffix.lower() in AUDIO_EXT)
    if not files:
        sys.exit(f"[エラー] 音声ファイルがありません: {p}")
    return files


def check_size(files: list[Path]) -> None:
    """25MB を超えるファイルがあれば、分割手順を案内して終了"""
    big = [f for f in files if f.stat().st_size > MAX_BYTES]
    if big:
        names = ", ".join(f.name for f in big)
        sys.exit(
            f"[エラー] 25MB を超えています: {names}\n"
            "  → python split_audio.py <ファイル> で分割してから、parts フォルダを指定してください。"
        )


def save_text(text: str, name: str) -> Path:
    out_dir = Path("out")
    out_dir.mkdir(exist_ok=True)
    out = out_dir / f"{name}.txt"
    out.write_text(text, encoding="utf-8")
    return out
