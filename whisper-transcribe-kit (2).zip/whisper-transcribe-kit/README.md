# whisper-transcribe-kit

Windows + VSCode で Whisper による音声文字起こしを学び、実務で使うための教材・スクリプト一式です。
（OpenAI API / Azure OpenAI / Google Colab / ローカル faster-whisper）

## フォルダ構成（番号順に使う）

```text
whisper-transcribe-kit/
├─ README.md
├─ 01_docs/                              ドキュメント
│  ├─ 01_zenn_article_kit.md             教材本体（Zenn用・Mermaid図解つき・Step0〜8）
│  ├─ 02_qiita_article_kit.md            同内容（Qiita用）
│  ├─ 03_qiita_article_oneshot_commented.md   1ファイル版の全行コメント解説（Qiita用）
│  ├─ 04_security_checklist.md           外部送信前の情報セキュリティ確認シート
│  └─ 05_verification_log.md             検証ログ（実施済み／未実施／公開時の再確認）
├─ 02_kit/                               教材用スクリプト一式（4方式を個別に学ぶ）
│  ├─ requirements.txt / .env.example
│  ├─ common.py / check_gpu.py / split_audio.py
│  ├─ transcribe_openai.py / transcribe_azure.py / transcribe_local.py / transcribe_colab.py
│  └─ sample_script.txt                  録音用の読み上げ原稿
└─ 03_oneshot/                           実務用の1ファイル版（全行コメント付き）
   ├─ whisper_transcribe.py
   ├─ requirements.txt
   └─ .env.example
```

## 使い方

**学ぶとき（教材）：** `01_docs/01_zenn_article_kit.md` を読みながら、`02_kit/` で実行します。

```powershell
cd 02_kit
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python transcribe_local.py sample.mp3
```

**使うとき（実務）：** `03_oneshot/` で、1ファイルのスクリプトを使います。

```powershell
cd 03_oneshot
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python whisper_transcribe.py 会議.mp3 --engine local
```

API 方式（openai / azure）は、`.env.example` を `.env` にコピーして、キーなどを記入します。

## GitHub へのアップロード手順

GitHub 上で空のリポジトリ（例：`whisper-transcribe-kit`）を作ってから、次を実行します。

```powershell
cd whisper-transcribe-kit
git init
git add .
git status          # .env や音声ファイルが含まれていないことを確認
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<ユーザー名>/whisper-transcribe-kit.git
git push -u origin main
```

アップロード前の確認：

- [ ] `.env`（キー）が `git status` に出ていない
- [ ] 音声ファイル（`*.mp3` など）が含まれていない
- [ ] 社内情報・顧客情報を含むファイルが無い

## 文字化けを防ぐために

- フォルダ名・ファイル名は、**半角英数字・`_`・`-` のみ**にしています（Zip・Git・Windows で化けないため）
- 文書とコードは **UTF-8（BOM なし）・改行 LF** です（`.editorconfig` / `.gitattributes` で固定）
- VSCode で開いたとき、右下の文字コード表示が `UTF-8` であることを確認してください
- 日本語のファイル名の音声（例：`会議.mp3`）を扱うときは、可能なら半角英数字にリネームしてください

## 検証状況（重要）

- 実施済み：ライブラリ導入、構文、25MB 超の検出と分割、エラー表示、API・モデルを模擬した処理の流れ、Mermaid 図の構文
- **未実施：API への実送信、モデルによる文字起こし、Windows 実機、GPU**
- 配布・公開の前に、`01_docs/05_verification_log.md` の B 表を、実機で埋めてください
- 変わりやすい情報（モデル名・api-version・料金・無料枠）は、公開時に公式で再確認してください
