# 動作検証ログ

## A. 実施済み（2026-11-12 / サンドボックス：Linux, Python 3.12.3）

| 項目 | 結果 |
|---|---|
| `pip install`（requirements.txt の固定版）と import | OK |
| 全スクリプトの構文チェック | OK |
| `check_gpu.py`（GPU なし環境） | 「GPU を使えません」と正しく案内 |
| 25MB 超ファイル（36.6MB）を `transcribe_openai.py` に渡す | 分割を案内して終了（想定どおり） |
| `split_audio.py`（40分・36.6MB → 10分ごと） | 4 分割・各 4.6MB、極小の端数ファイルは自動削除 |
| 分割後のフォルダのサイズチェック | 全件通過 |
| キー未設定時（OpenAI / Azure） | 分かりやすいエラーで終了 |
| Azure クライアント生成（キー方式 / Entra 方式） | 生成 OK（通信なし） |
| Zenn 記事の Mermaid 図 10 枚の構文チェック（mermaid.parse） | 全件 OK（※構文のみ。Zenn 上の見た目は未確認） |

## A2. 実施済み：1ファイル版 `03_oneshot/whisper_transcribe.py`（2026-11-12 / Linux, Python 3.12.3）

> API クライアントとモデルを**模擬（モック）**した状態での確認です。実送信・実モデルは未実施。

| 項目 | 結果 |
|---|---|
| 構文チェック、全コード行にコメントがあること | OK（コメントの無いコード行 0） |
| 36.6MB の音声を `--engine openai` で処理 | 25MB 超を検出し、4 分割して順に送信・連結（OK） |
| フォルダ（2 ファイル）を `--engine azure` で処理 | デプロイ名を `model` に渡し、見出し付きで結合（OK） |
| `--engine local`（faster-whisper を模擬） | `--device cuda` で float16 / large-v3、`--no-vad`、`--prompt` が渡る（OK） |
| キー未設定、Azure 設定不足、存在しないファイル、空フォルダ | 日本語のエラーで終了（OK） |
| 実クライアントの生成（OpenAI / Azure キー / Azure Entra ID） | 生成 OK（通信なし） |

## B. 未実施（実機でのみ確認できる。配布前に必ず実施・記録すること）

> サンドボックスには API キー・音声・GPU・Windows がなく、モデルのダウンロード先にも接続できないため、**文字起こしの実行そのものは未検証**です。

| # | 項目 | 結果 | 実施日 | 実施者 |
|---|---|---|---|---|
| 1 | ① `transcribe_openai.py sample.mp3` が文字を出力する | | | |
| 2 | ② `transcribe_azure.py sample.mp3` が文字を出力する（デプロイ名・api_version） | | | |
| 3 | ③ Colab（T4）で large-v3 が動く | | | |
| 4 | ④ Windows CPU で `--model small` が動く | | | |
| 5 | ④ Windows GPU で `--device cuda --model large-v3` が動く（DLL 手順込み） | | | |
| 6 | Windows に `winget install Gyan.FFmpeg` し、`split_audio.py` が動く | | | |
| 7 | 読み上げ原稿の認識結果を確認（誤認識した語を記録） | | | |
| 8 | 1ファイル版 `whisper_transcribe.py` を `--engine local / openai / azure` で実行 | | | |

### 環境（実機検証時に記入）

| 項目 | 記入 |
|---|---|
| OS / ビルド | |
| Python | |
| GPU / ドライバ / CUDA / cuDNN | |
| `pip freeze` の主要バージョン | |

## C. 公開時に再確認する項目（変わりやすい情報）

- [ ] OpenAI の音声モデル名と上限（公式: speech-to-text ガイド） 確認日: ______
- [ ] Azure OpenAI：音声モデルの提供状況・利用可能リージョン・api-version 確認日: ______
- [ ] 各サービスの料金（公式料金ページ） 確認日: ______
- [ ] Colab 無料枠の条件 確認日: ______
