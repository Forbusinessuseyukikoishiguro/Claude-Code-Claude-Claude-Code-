---
title: 【法人研修向け】Whisperで音声を文字起こし：安全に始めて実務で使うまで（OpenAI API・Azure・Colab・Windows）
tags: Python Whisper OpenAI Azure GoogleColab
---

## この記事の使い方（学習ガイド）

### ゴール

読み終えると、次ができるようになります。

- 音声の機密度に応じて、**使ってよい方法を自分で選べる**
- Windows + VSCode で、Whisper による文字起こしを **4通りの方法で実行できる**
- 25MB を超える長い音声を **分割して処理できる**
- 誤認識（無音での幻覚、専門用語）への **基本的な対策を入れられる**

### 対象・前提

| 項目 | 内容 |
|---|---|
| 対象 | 業務で音声の文字起こしを使いたいエンジニア・DX 担当 |
| 前提 | Python を動かした経験（`pip install` と `python xxx.py` が分かる） |
| 環境 | Windows 10 / 11、Python 3.10 以上、VSCode |
| 所要時間の目安 | 全ステップで 2〜3 時間程度（環境により大きく変わります。あくまで目安） |

### 8つのステップ

最初に「外に送ってよいか」を決め、外に送らない方法で成功体験を作ってから、クラウド、GPU、実務へと進みます。

```mermaid
flowchart LR
    S0["Step0<br/>データ分類"] --> S1["Step1<br/>環境準備"]
    S1 --> S2["Step2<br/>音声を録る"]
    S2 --> S3["Step3<br/>ローカルCPU<br/>外に送らない"]
    S3 --> S4["Step4<br/>① OpenAI API"]
    S4 --> S5["Step5<br/>② Azure"]
    S5 --> S6["Step6<br/>③ Colab<br/>large-v3"]
    S6 --> S7["Step7<br/>④ ローカルGPU<br/>large-v3"]
    S7 --> S8["Step8<br/>長尺・品質・運用"]
```

:::note info
Step3 で一度「動いた」状態を作ってから、Step4 以降に進みます。Step4〜7 は、使いたい方法だけ読んでも構いません（Step0〜3 は必須）。
:::

### この教材の検証状況（正直な申告）

- サンドボックス（Linux）で、ライブラリの導入、全スクリプトの構文、25MB 超の検出、音声の分割、エラー表示を確認しました。
- **API への実送信、モデルによる文字起こし、Windows 実機、GPU は未検証です。** 配布前に、`05_verification_log.md` の B 表を実機で埋めてください。

---

## 全体像：4つの方法

```mermaid
flowchart LR
    F["音声ファイル"]

    subgraph PC["あなたのPC"]
        P4["④ ローカル<br/>faster-whisper"]
        P1["① transcribe_openai.py"]
        P2["② transcribe_azure.py"]
    end

    subgraph Cloud["外部サービス（音声が送信される）"]
        O["OpenAI API"]
        Z["Azure OpenAI"]
        C["③ Google Colab<br/>large-v3 + T4 GPU"]
    end

    T["テキスト"]

    F --> P4 --> T
    F --> P1 --> O --> T
    F --> P2 --> Z --> T
    F -. "アップロード" .-> C --> T
```

:::note warn
**Whisper large-v3 を使えるのは、本記事では ③ と ④ です。** ①② は API 側のモデル名（OpenAI は `whisper-1` など）を指定します。公開時点の提供モデルは、公式ドキュメントで再確認してください。
:::

### 比較表（事実ベース）

| 観点 | ① OpenAI API | ② Azure OpenAI | ③ Colab | ④ ローカル |
|---|---|---|---|---|
| 音声の送信先 | OpenAI | Azure（自社テナントのリソース） | Google | **なし** |
| 認証 | API キー | API キー / Entra ID | Google アカウント | 不要 |
| GPU | 不要 | 不要 | 無料枠の T4（変動あり） | 任意（NVIDIA） |
| 1ファイルの上限 | 25MB | 25MB | なし（セッション制限あり） | なし |
| 本記事で使うモデル | whisper-1 | デプロイした whisper | large-v3 | small / large-v3 |
| 料金 | 従量課金 | 従量課金 | 無料枠あり（条件は変動） | 無料（PC の電気代のみ） |

料金の金額は変わるため、必ず公式の料金ページで確認し、確認日を残してください。

---

## Step0：データ分類（最初に必ず）

「どの方法を使ってよいか」は、**音声の機密度で決まります。** 技術の好みで選ばないでください。

```mermaid
flowchart TD
    A["音声がある"] --> B{"個人情報・顧客情報・<br/>機密を含む？"}
    B -- "含む" --> C{"社内承認と契約が<br/>確認できている？"}
    C -- "いいえ" --> L["④ ローカルのみ"]
    C -- "はい" --> D["承認された方法のみ<br/>（②が候補になりやすい）"]
    B -- "含まない" --> E{"録音者全員の<br/>同意がある？"}
    E -- "いいえ" --> L
    E -- "はい" --> F["①②③④ のどれでも可<br/>（社内で許可されたサービス）"]
```

次の確認が必要です。詳しくは同梱の `04_security_checklist.md` を、情シスや上長と一緒に確認してください。

| 確認すること | 理由 |
|---|---|
| 録音の同意 | 録音自体が、参加者の権利に関わるため |
| 個人情報の有無 | 外部送信は、社内規程で制限されることが多いため |
| データ保持・学習利用の条件 | 契約形態によって異なる。**公式資料で確認し、確認日を残す** |
| 処理リージョン（Azure） | 社内規程で、国・地域が決まっている場合がある |
| Colab は Google 上で処理される | 機密音声は使わない。終了時にランタイムを切断し、ファイルを削除する |

### API キーの扱い

- キーは `.env` に置き、**Git に上げない**（`.gitignore` に `.env` を入れる）
- チャット・メール・スクリーンショットに載せない
- 漏れた疑いがあれば、**すぐ失効して再発行**する
- Azure は、キーを使わない認証（Entra ID）が使えることがあります。情シスに確認してください（Step5 参照）

**完了条件：** 手元の音声が、上の図のどこに当たるかを説明できる。

---

## Step1：環境準備（Windows + VSCode）

VSCode のターミナル（PowerShell）で実行します。

```powershell
mkdir whisper-demo
cd whisper-demo
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

`Activate.ps1` が実行ポリシーで止まる場合は、次を実行します。

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

> 会社の PC ではポリシーが管理されていることがあります。変更してよいか、情シスに確認してください。

VSCode で `Ctrl+Shift+P` → 「Python: Select Interpreter」→ `.venv` を選びます。

教材一式（Zip）を展開したフォルダで、ライブラリを入れます。

```powershell
pip install -r requirements.txt
```

`requirements.txt` は、動作確認した版に固定してあります（再現性のため）。

### フォルダ構成

```text
whisper-demo/
├─ .env                   APIキー（Gitに上げない）。①②で使う
├─ requirements.txt       固定バージョン
├─ common.py              共通処理（サイズチェックなど）
├─ check_gpu.py           GPU が使えるかの確認
├─ split_audio.py         長い音声の分割（ffmpeg が必要）
├─ transcribe_openai.py   ①
├─ transcribe_azure.py    ②
├─ transcribe_local.py    ④
├─ transcribe_colab.py    ③（Colab のセルに貼る）
├─ sample_script.txt      録音用の読み上げ原稿
└─ out/                   結果の出力先（自動作成）
```

**完了条件：** `python -c "import faster_whisper, openai"` がエラーなく終わる。

---

## Step2：練習用の音声を録る

練習には、**個人情報や機密を含まない自作音声**を使います。同梱の `sample_script.txt` の原稿を、30 秒ほど読み上げて録音してください。

1. Windows の「サウンドレコーダー」で録音する
2. `sample.mp3`（または保存された形式のまま）で、プロジェクトのフォルダに置く

原稿には、「ブイエスコード」「パイソン」「ウィンドウズ」など、誤認識しやすい語を入れてあります。**どの語が誤認識されたかを記録する**ことが、後の品質確認（Step8）の練習になります。

**完了条件：** 30 秒ほどの音声ファイルが、プロジェクトのフォルダにある。

---

## Step3：ローカル CPU で最初の成功体験（外に送らない）

キーも料金も不要で、音声が外に出ません。まずここで動かします。

```powershell
python transcribe_local.py sample.mp3
```

```mermaid
flowchart LR
    A["モデル読み込み<br/>small / 初回DLあり"] --> B["音声を解析<br/>VAD で無音除去"]
    B --> C["区間ごとに表示<br/>開始秒・終了秒・文字"]
    C --> D["out/sample.txt に保存"]
```

```python:transcribe_local.py
model = WhisperModel(args.model, device=args.device, compute_type=compute)
segments, info = model.transcribe(
    str(f), language="ja", beam_size=5,
    vad_filter=not args.no_vad,   # 無音区間での誤認識を減らす
    initial_prompt=args.prompt,   # 専門用語のヒント
)
```

:::note info
- 初回はモデルが自動ダウンロードされます（時間と通信量がかかります）。
- faster-whisper は、音声の読み込みに使うライブラリ（PyAV）に FFmpeg が同梱されているため、**文字起こしだけなら ffmpeg の別途インストールは不要**です。（Step8 の分割には、別途 ffmpeg が必要です）
:::

**完了条件：** `out/sample.txt` ができ、読み上げた内容が概ね読める。誤認識した語を 1 つ以上メモした。

---

## Step4：① OpenAI API

### 処理の流れ

```mermaid
sequenceDiagram
    participant PY as Pythonコード
    participant ENV as .env
    participant API as OpenAI API
    ENV->>PY: OPENAI_API_KEY を読み込み
    PY->>PY: 25MB 以下かチェック
    PY->>API: 音声を送信（model=whisper-1）
    API-->>PY: 文字起こし結果
    PY->>PY: out/ に保存
```

### 設定

[OpenAI の API キーページ](https://platform.openai.com/api-keys)でキーを発行し、`.env` に書きます（`.env.example` をコピー）。

```text:.env
OPENAI_API_KEY=sk-xxxxxxxx
```

### 実行

```powershell
python transcribe_openai.py sample.mp3
```

```python:transcribe_openai.py
client = OpenAI(timeout=120, max_retries=3)  # タイムアウトと自動リトライ
with open(f, "rb") as fp:
    result = client.audio.transcriptions.create(
        model="whisper-1", file=fp, language="ja"
    )
```

25MB を超えると、コードが分割の手順を案内して止まります（Step8）。

**完了条件：** Step3 の結果と見比べ、違いを 1 つ以上説明できる。

---

## Step5：② Azure OpenAI

### 準備の流れ

```mermaid
flowchart LR
    A["Azure ポータルで<br/>Azure OpenAI リソース作成"] --> B["音声モデルを<br/>デプロイ"]
    B --> C["デプロイ名を控える"]
    C --> D[".env に<br/>エンドポイント・デプロイ名・キー"]
    D --> E["実行"]
```

### 最大のつまずき：model= には「デプロイ名」

```mermaid
flowchart LR
    M["モデル<br/>whisper"] -- "デプロイ時に<br/>名前を付ける" --> D["デプロイ名"]
    D -- "model= に指定" --> CODE["Pythonコード"]
    M -. "× モデル名では通らない<br/>（デプロイ名と同じ名前にした場合を除く）" .-> CODE
```

### 設定

```text:.env
AZURE_OPENAI_API_KEY=xxxxxxxx
AZURE_OPENAI_ENDPOINT=https://あなたのリソース名.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=（自分で付けたデプロイ名）
AZURE_OPENAI_API_VERSION=2024-02-01
```

`api-version` は、公式クイックスタートの例（`2024-02-01`）を既定にしています。**新しい版が出ている場合があります。** ポータルと公式で確認してください。

### 実行

```powershell
python transcribe_azure.py sample.mp3
```

### キーを使わない認証（Entra ID）

会社の方針でキーを使えない場合は、環境変数 `USE_ENTRA=1` を設定すると、Entra ID で認証します。事前に、利用者へ適切なロールの割り当てが必要です（情シスに依頼）。

```powershell
$env:USE_ENTRA = "1"
python transcribe_azure.py sample.mp3
```

### 公開前・利用前に確認すること

- 音声モデルが、自分のリージョンで提供されているか（提供形態・申請の要否を含む）
- 現在デプロイできる音声モデルの種類
- 25MB を超える音声は、Azure AI Speech のバッチ文字起こしが、公式の案内にある代替手段

**完了条件：** `DeploymentNotFound` が出たとき、まず何を確認するか説明できる（答え：`model=` にデプロイ名を入れているか）。

---

## Step6：③ Google Colab（large-v3 / GPU）

PC に GPU がなくても、large-v3 を試せます。**音声は Google 上で処理される**ため、機密音声には使いません。

```mermaid
flowchart LR
    A["Colab で<br/>新規ノートブック"] --> B["ランタイムを<br/>T4 GPU に変更"]
    B --> C["sample.mp3 を<br/>アップロード"]
    C --> D["セル1<br/>pip install"]
    D --> E["セル2<br/>文字起こし"]
    E --> F["result.txt を<br/>ダウンロード"]
    F --> G["ランタイム切断<br/>音声と結果を削除"]
```

セル1:

```python
!pip install -q faster-whisper==1.2.1
```

セル2:

```python
from faster_whisper import WhisperModel

model = WhisperModel("large-v3", device="cuda", compute_type="float16")

segments, info = model.transcribe(
    "sample.mp3", language="ja", beam_size=5,
    vad_filter=True,   # 無音区間での誤認識を減らす
)

lines = []
for seg in segments:
    line = f"[{seg.start:.1f}s - {seg.end:.1f}s] {seg.text.strip()}"
    print(line)
    lines.append(line)

with open("result.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(lines))
```

:::note info
無料枠の GPU は、利用状況によって使えないことがあります。条件は変わるため、Colab の公式表示で確認してください。
:::

**完了条件：** `result.txt` を得て、終了後に音声と結果を削除した。

---

## Step7：④ ローカル GPU で large-v3（Windows）

最もつまずきやすいステップです。順番に進めてください。

> 本ステップの GPU 手順は、**Windows 実機で未検証**です。実施した結果は `05_verification_log.md` に記録してください。

```mermaid
flowchart TD
    A["nvidia-smi で<br/>GPU とドライバを確認"] --> B["python check_gpu.py"]
    B --> C{"CUDA デバイス数 ≥ 1？"}
    C -- "0" --> X["GPU 不可<br/>→ CPU（small）か Colab"]
    C -- "1以上" --> D["transcribe_local.py<br/>--device cuda --model large-v3"]
    D --> E{"DLL / cublas / cudnn<br/>のエラー？"}
    E -- "いいえ" --> OK["成功"]
    E -- "はい" --> F["CUDA 12 の cuBLAS と<br/>cuDNN 9 を導入して PATH へ"]
    F --> D
```

### 手順

1. PowerShell で `nvidia-smi` を実行し、NVIDIA GPU とドライバが表示されることを確認する
2. `python check_gpu.py` を実行する（CUDA デバイス数が 1 以上なら次へ）
3. `python transcribe_local.py sample.mp3 --device cuda --model large-v3` を実行する
4. cuBLAS / cuDNN の DLL が見つからないというエラーが出たら、下の対処を行う

### GPU で必要なライブラリ

faster-whisper の GPU 実行には、**CUDA 12 用の cuBLAS と、CUDA 12 用の cuDNN 9** が必要です。公式の pip での導入手順は Linux 向けで、Windows では、次のどちらかで DLL を用意します。

- NVIDIA の公式配布から、CUDA 12 用の cuBLAS と cuDNN 9 を入れる
- 公式 README が案内している、[Purfview のライブラリ配布](https://github.com/Purfview/whisper-standalone-win)の NVIDIA ライブラリ一式を展開し、**PATH の通ったフォルダ**に置く

どちらでも、導入後に VSCode とターミナルを再起動し、`check_gpu.py` から確認し直します。

### 時間がないとき

GPU の導入に行き詰まったら、**CPU の `--model small`（Step3）か、Colab（Step6）に切り替えて先に進んで構いません。** 環境構築で止まるより、動かして中身を理解するほうが大切です。

**完了条件：** GPU で動いた。または、動かなかった原因と、切り替えた方法を説明できる。

---

## Step8：長い音声・品質・運用

### 25MB を超える音声を分割する

会議の録音は、25MB を超えることが多くあります。①② は 25MB が上限なので、分割します。

事前に ffmpeg を入れます（PowerShell。入れたら VSCode を再起動）。

```powershell
winget install Gyan.FFmpeg
```

```powershell
python split_audio.py 会議.mp3 600
python transcribe_openai.py parts
```

```mermaid
flowchart LR
    A["会議.mp3<br/>30MB超"] --> B["split_audio.py<br/>モノラル 64kbps に変換<br/>600秒ごとに分割"]
    B --> C["parts/<br/>part_000.mp3 ..."]
    C --> D["transcribe_*.py parts<br/>名前順に処理して連結"]
    D --> E["out/part_000.txt"]
```

注意点です。

- 時間で機械的に切るため、**区切り位置で単語が欠ける**ことがあります
- 分割で音質を落とすため、聞き取りにくい音声では精度が下がる場合があります
- Azure で大きな音声を扱う場合は、Azure AI Speech のバッチ文字起こしが、公式の案内にある別の方法です

### 誤認識への基本対策

| 症状 | 対策 | 設定 |
|---|---|---|
| 無音や雑音で、存在しない文が出る（幻覚） | 無音区間を除く | `vad_filter=True`（④③。既定で有効） |
| 専門用語・固有名詞が違う | 用語のヒントを渡す | `--prompt "Whisper, Azure, VSCode"` |
| 話者が区別されない | 本記事の範囲外。話者分離に対応した方法は、公式で確認 | — |

### 品質を確認する手順

「だいたい合っている」では、業務で使えません。次の手順で確認します。

1. 正解テキストを用意する（自作音声なら、原稿そのもの）
2. 文字起こし結果と、**人の目で突き合わせる**
3. 誤りを「専門用語」「同音異義」「欠落」「幻覚」に分類して記録する
4. 用語ヒントや設定を変えて、もう一度試す

**文字起こし結果は、必ず人が確認してから使ってください。** 特に、数字・固有名詞・否定表現（「〜ではない」）の取り違えは、業務判断に直結します。

### 結果ファイルの扱い

`out/` の文字起こしも、元の音声と同じ機密レベルで管理します。不要になったら削除します。

---

## 演習と理解確認

### 演習

| # | 演習 | 完了条件 |
|---|---|---|
| 1 | Step3 で `sample.mp3` を文字起こしし、誤認識した語を 3 つ記録する | 記録表がある |
| 2 | `--prompt` に誤認識した語を入れて再実行し、結果を比べる | 改善した語・しない語を説明できる |
| 3 | 使う方法（①〜④）を 1 つ選び、**Step0 の図を使って選んだ理由**を書く | 理由が機密度に基づいている |
| 4 | 5 分以上の音声を `split_audio.py` で分割して処理する | 全パートの結果が連結されている |

### 理解確認

1. 顧客の個人情報を含む会議録音を、Colab で処理してよいか？
   **答え：** 使いません。音声が Google 上で処理されるためです。ローカル（④）か、承認された方法を使います。
2. Azure で `model=` に入れるのは、モデル名とデプロイ名のどちらか？
   **答え：** デプロイ名です。
3. 30MB の音声を①にそのまま渡すとどうなるか？ どうすればよいか？
   **答え：** 上限 25MB のため、エラーになります（本教材のコードは案内して止まります）。`split_audio.py` で分割します。
4. 無音区間で、話していない文が出た。まず試す設定は？
   **答え：** `vad_filter=True`（本教材の④③は既定で有効）です。
5. 文字起こし結果を、確認せずに議事録として配ってよいか？
   **答え：** よくありません。人が突き合わせてから使います。

---

## つまずき一覧

| 症状 | 原因と対処 |
|---|---|
| `Activate.ps1` が実行できない | 実行ポリシーを `RemoteSigned` に変更（会社の PC は情シスに確認） |
| `[エラー] OPENAI_API_KEY がありません` | `.env` を作る（`.env.example` をコピー）。ファイル名の先頭の `.` を確認 |
| `AuthenticationError` | キーの誤り・失効。キーを再確認 |
| Azure で `DeploymentNotFound` | `model=` にモデル名を入れている。**デプロイ名**に直す |
| Azure の応答エラーが続く | リージョン・提供状況・`api-version` を公式で確認 |
| 25MB を超えてエラー | `split_audio.py` で分割 |
| `split_audio.py` が「ffmpeg が見つかりません」 | `winget install Gyan.FFmpeg` を実行し、VSCode を再起動 |
| CUDA / cublas / cudnn の DLL エラー | Step7 の手順。CUDA 12 用の cuBLAS と cuDNN 9 が必要 |
| 初回が極端に遅い | モデルのダウンロード中。2 回目以降は速くなる |
| 結果が空、または極端に短い | 音量が小さい、無音が多い。`--no-vad` で比較して原因を切り分ける |

---

## 参考

- [OpenAI Speech to text ガイド](https://platform.openai.com/docs/guides/speech-to-text)
- [Azure OpenAI Whisper クイックスタート](https://learn.microsoft.com/ja-jp/azure/ai-services/openai/whisper-quickstart)
- [faster-whisper（GitHub）](https://github.com/SYSTRAN/faster-whisper)
- [whisper-standalone-win（NVIDIA ライブラリの配布。faster-whisper の README が案内）](https://github.com/Purfview/whisper-standalone-win)
- Radford, A. et al. (2022). *Robust Speech Recognition via Large-Scale Weak Supervision*. arXiv:2212.04356（Whisper の原論文）

## まとめ

- **最初に、音声の機密度で使える方法を決める。** 技術で選ばない
- 外に送らない方法（④ CPU）で、まず動かす
- Azure の `model=` は **デプロイ名**
- 25MB を超えたら**分割**。無音の幻覚には `vad_filter`
- 結果は**人が確認してから**使う
- 変わりやすい情報（モデル名・api-version・料金・無料枠）は、**確認日を付けて**公式で再確認する
