# 06 Git の基本操作

## 6-1 Git の考え方（3つの場所）
| 場所 | 意味 |
|---|---|
| 作業フォルダ | 今、編集している場所 |
| ステージ（置き場） | 次の記録に入れる変更を、選んで置く場所 |
| 履歴（コミット） | 記録された変更。いつでも戻れる |

流れ：編集 → `git add`（ステージ）→ `git commit`（履歴に記録）

## 6-2 最初の設定（一度だけ）
```bash
git config --global user.name "自分の名前"
git config --global user.email "登録したメールアドレス"
git config --global init.defaultBranch main
git config --global core.autocrlf input     # Ubuntu・Mac（Windows は後述）
```
Windows の Git では、改行の設定を次のようにする：
```powershell
git config --global core.autocrlf true
```
- 確認：`git config --list --show-origin` で、設定が出ること

## 6-3 リポジトリを作る・確かめる
```bash
git init -b main          # 今のフォルダを Git で管理し始める
git status                # 今の状態（変更、ステージ、未追跡）
git log --oneline         # 履歴を一行ずつ表示
```
- `git status` は、何度実行しても安全（変更はしない）。迷ったら、まず `git status`

## 6-4 変更を記録する（基本の流れ）
```bash
git add 変更したファイル名       # 例：git add src/lib.js
git status                       # ステージされたかを確認
git commit -m "FR-03: 区間の端数を修正（AC-UT-05a）"
```
- コミットのメッセージには、**何を・なぜ**を書く。要件の番号を入れると、後で追いやすい
- `git add .` は、意図しないファイルを含むことがある。使う前に `git status` で確かめる

## 6-5 差分を見る
```bash
git diff                  # まだステージしていない変更
git diff --staged         # ステージされた変更（次のコミットに入るもの）
git diff HEAD~1 --stat    # 直前のコミットとの差（ファイル単位）
```

## 6-6 元に戻す（場面別）
| 場面 | 命令 | 注意 |
|---|---|---|
| 編集をやめて、元の状態に戻す | `git restore ファイル名` | **編集した内容が消える**。実行前に確認 |
| ステージを取り消す | `git restore --staged ファイル名` | 編集内容は残る |
| 直前のコミットを取り消す（中身は残す） | `git reset --soft HEAD~1` | 共有済みのコミットには使わない |
| 一時的に作業を退避する | `git stash` / `git stash pop` | 戻すときは `pop` |

## 6-7 ブランチ（作業の枝）
```bash
git branch                     # 枝の一覧（* が今いる枝）
git switch -c feature/区間修正  # 新しい枝を作って移動
git switch main                 # 本線に戻る
git merge feature/区間修正      # 枝の変更を、今の枝に取り込む
```
- 枝名は英数字とハイフンにする（例：`feature/segment-fix`）。日本語の枝名は、環境によって扱いにくい

## 6-8 タグ（版の目印）
```bash
git tag -a v1.9.0 -m "v1.9.0"   # 版に目印を付ける
git tag                         # タグの一覧
git show v1.9.0 --stat          # タグの内容を見る
```

## 6-9 追跡から外す（秘密情報などを誤って入れたとき）
```bash
git rm --cached config.js       # Git の管理から外す（ファイルは残る）
git commit -m "config.js を管理対象から外す"
```
- 注意：一度でも GitHub に push したキーは、**外しても漏えいしたとみなし、キーを再発行する**
- `.gitignore` に `config.js` を書いておくと、以後は入らない

## 6-10 Git の中身を確かめる（練習の方法）
```bash
mkdir ~/git-practice && cd ~/git-practice
git init -b main
echo "hello" > a.txt
git add a.txt && git commit -m "first"
git log --oneline
```
- 確認：1行の履歴が出ること。このフォルダは練習用なので、後で `cd ~ && rm -rf ~/git-practice` で消してよい（消す前に、場所を確かめる）

## 6-11 Git の表示が、コマンドで見えないとき
- `git status` の結果の意味：
  - `Changes not staged for commit`：変更があり、まだ `git add` していない
  - `Changes to be committed`：`git add` 済みで、次のコミットに入る
  - `Untracked files`：Git がまだ管理していないファイル
