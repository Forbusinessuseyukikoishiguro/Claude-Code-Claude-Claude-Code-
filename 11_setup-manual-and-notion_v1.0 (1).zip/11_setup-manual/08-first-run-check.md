# 08 初回の動作確認（プロジェクトを動かす）

## 8-1 プロジェクトを置く場所
- **WSL（Ubuntu）の中の、自分のフォルダ**に置く（例：`~/work/azure-speech-transcriber`）
- Windows の `C:\` の下に置くと、遅くなることがある（03 を参照）

### 方法：zip を展開する（Ubuntu の中で）
```bash
mkdir -p ~/work && cd ~/work
# Windows のダウンロードフォルダの zip を、Ubuntu から見る場所：
# /mnt/c/Users/<ユーザー名>/Downloads/03_azure-speech-transcriber_v1.5.1.zip
unzip /mnt/c/Users/<ユーザー名>/Downloads/03_azure-speech-transcriber_v1.5.1.zip -d ~/work
cd ~/work/azure-speech-transcriber
ls
```
- `unzip` が無い場合：`sudo apt-get install -y unzip`
- 確認：`ls` で、`README.md`、`src`、`docs` が見えること

## 8-2 Git で管理されているかを確かめる
```bash
git status
git log --oneline -3
```
- 確認：`git status` が `nothing to commit`（変更なし）と出ること

## 8-3 Node.js を用意する（Ubuntu の場合）
```bash
node -v
```
- 表示されない、または 18 より古い場合は、nvm で Node.js 22 を入れる
  ```bash
  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash
  source ~/.bashrc
  nvm install 22
  node -v
  ```
  （上の版番号は、講座制作時点のもの。最新は公式の nvm のページで確認する）
- 確認：`v22.` が出ること

## 8-4 検証を実行する（最初の成功体験）
```bash
npm run verify
```
- 確認：最後に次の行が出ること
  - `# pass 23`、`# fail 0`
  - `OK: 秘密情報の混入は検出されませんでした`
- 失敗したら、12 のトラブル対応表を見る

## 8-5 Python の試験（API キー不要）
```bash
cd ~/work/azure-speech-transcriber/api-testing-kit
python3 -m unittest -v tests/test_api_contract.py
```
- 確認：`Ran 17 tests` と `OK`

## 8-6 ブラウザの確認（Docker を使う場合）
Docker Desktop を起動してから、Ubuntu で次を実行する。
```bash
cd ~/work/azure-speech-transcriber
docker build -f docker/dev/Dockerfile -t web-dev:1.0 .
docker run --rm --shm-size=1g -v "$PWD:/work" -w /work web-dev:1.0 python3 scripts/check_browser.py
```
- 確認：`起動できています` と表示されること（初回のビルドは 10〜20 分かかることがある）

## 8-7 画面の試験（Docker の中で）
```bash
docker run --rm --shm-size=1g -v "$PWD:/work" -w /work web-dev:1.0 sh -c "npm run e2e"
```
- 確認：`合格 13 / 13 件`

## 8-8 模倣サーバーを起動して、外から呼ぶ（練習）
```bash
cd ~/work/azure-speech-transcriber/api-testing-kit
python3 server/mock_chat_server.py &          # & は裏で動かす
sleep 1
curl -s -X POST http://127.0.0.1:8790/v1/chat/completions \
  -H "Authorization: Bearer test-key" -H "Content-Type: application/json" \
  -d '{"model":"mock-model","messages":[{"role":"user","content":"こんにちは"}]}'
kill %1                                        # 裏で動かしたものを止める
```
- 確認：返事に `【モック】` が含まれる
- キーを外すと（`Authorization` の行を消す）、`401` が返ることも確かめる

## 8-9 初回の確認チェックリスト
- [ ] `git --version`、`node -v`、`python3 --version`、`docker version` がすべて表示された
- [ ] プロジェクトを、Ubuntu の中のフォルダに置いた
- [ ] `npm run verify` が通った（pass 23、OK）
- [ ] API の試験が通った（Ran 17、OK）
- [ ] （Docker を使う場合）ブラウザの確認と、画面の試験が通った
- [ ] 模倣サーバーを起動し、外から呼べた
- [ ] 結果を、Notion の「環境構築チェックリスト」に記録した
