# 05 Docker の基本操作

## 5-1 Docker の3つの言葉
| 言葉 | 意味 | たとえ |
|---|---|---|
| イメージ | 道具一式を入れた「設計図」 | 料理のレシピ |
| コンテナ | イメージから作った、実行中の「箱」 | 料理そのもの |
| ボリューム / バインドマウント | 箱の中と外で、データを共有する仕組み | 冷蔵庫（外）と、箱の中のかご |

## 5-2 Docker が動いているかの確認
```bash
docker version
docker info
```
- 確認：`Server` の情報が出ること
- エラー例：`Cannot connect to the Docker daemon` → Docker Desktop を起動し、「Engine running」になるまで待つ

## 5-3 イメージの操作
| 命令 | 意味 | 例 |
|---|---|---|
| `docker images` | 持っているイメージの一覧 | `docker images` |
| `docker pull` | イメージを取得する | `docker pull node:22-bookworm` |
| `docker build` | 設計図（Dockerfile）から、イメージを作る | `docker build -t web-dev:1.0 .` |
| `docker rmi` | イメージを消す | `docker rmi web-dev:1.0` |

`docker build` の `-t 名前:版` は、イメージに名前を付ける。`.` は「今のフォルダの Dockerfile を使う」の意味。

## 5-4 コンテナの操作
| 命令 | 意味 | 例 |
|---|---|---|
| `docker run` | イメージから、コンテナを作って実行する | `docker run --rm web-dev:1.0 node -v` |
| `docker run -it` | 中に入って操作する（対話モード） | `docker run --rm -it web-dev:1.0 bash` |
| `docker ps` | 実行中のコンテナの一覧 | `docker ps` |
| `docker ps -a` | 止まったものも含めた一覧 | `docker ps -a` |
| `docker exec` | 実行中のコンテナの中で命令を実行 | `docker exec -it 名前 bash` |
| `docker logs` | コンテナの出力（ログ）を見る | `docker logs 名前` |
| `docker stop` | コンテナを止める | `docker stop 名前` |
| `docker rm` | 止まったコンテナを消す | `docker rm 名前` |

### 主なオプション
| オプション | 意味 |
|---|---|
| `--rm` | 終わったら、コンテナを自動で消す（おすすめ） |
| `-it` | 対話モードで中に入る（i＝入力、t＝端末） |
| `-v "ホスト側:コンテナ側"` | フォルダを共有する（例：`-v "$PWD:/work"`） |
| `-p ホスト側:コンテナ側` | ポートを開く（例：`-p 8000:8000`） |
| `-w /work` | 作業するフォルダを指定する |
| `--shm-size=1g` | ブラウザを使うときの共有メモリ（落ちないように） |

## 5-5 フォルダを共有する（最重要）
```bash
# Ubuntu / WSL（プロジェクトのフォルダで）
docker run --rm -it -v "$PWD:/work" -w /work web-dev:1.0 bash
```
```powershell
# Windows の PowerShell（プロジェクトのフォルダで）
docker run --rm -it -v "${PWD}:/work" -w /work web-dev:1.0 bash
```
- **確認**：コンテナの中で `ls` を実行すると、プロジェクトのファイルが見えること
- コンテナの中で作ったファイルは、共有したフォルダの中なら、ホストにも残る
- `-v` を付けないと、ホストのファイルは見えない

## 5-6 掃除（ディスクの空きを増やす）
```bash
docker system df          # 使っている容量の確認
docker container prune    # 止まったコンテナを消す
docker image prune        # 使っていないイメージを消す（確認の質問に y で答える）
```
- 注意：`docker system prune -a` は、使っていないイメージをすべて消す。実行前に、必要なイメージがないか確認する

## 5-7 Docker のよくある確認（デバッグで使う）
```bash
docker ps -a                  # 状態（Exited は止まったという意味）
docker logs 名前              # 止まった理由のヒント
docker inspect 名前           # 詳しい情報（マウントの確認など）
docker exec -it 名前 sh       # 中に入って確かめる（シェルがある場合）
```

## 5-8 Docker Desktop の画面
- 左の「Containers」で、コンテナの一覧と、止める・消すボタンがある
- 「Images」で、イメージの一覧が見える
- 「Settings」→「Resources」→「WSL Integration」で、Ubuntu が有効かを確認する
