# 11 チートシート（1枚でわかる命令）

## Windows（PowerShell）
| 目的 | 命令 |
|---|---|
| WSL を入れる（管理者） | `wsl --install -d Ubuntu` |
| WSL の一覧 | `wsl --list --verbose` |
| WSL を止める | `wsl --shutdown` |
| 道具の確認 | `git --version`　`node -v`　`python --version`　`docker version` |
| 場所の移動 | `Set-Location "C:\work"` |
| 命令の場所 | `Get-Command git` |
| 実行を許す（自分だけ） | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |

## Ubuntu（WSL）
| 目的 | 命令 |
|---|---|
| 場所を表示・移動 | `pwd`　`cd ~/work` |
| 一覧 | `ls -la` |
| 中身を表示 | `cat ファイル名` |
| 更新 | `sudo apt-get update && sudo apt-get upgrade -y` |
| 入れる | `sudo apt-get install -y パッケージ名` |
| Windows のエクスプローラーで開く | `explorer.exe .` |
| VS Code で開く | `code .` |

## VS Code
| 目的 | キー・操作 |
|---|---|
| ファイルを開く | `Ctrl + P` |
| 命令を探す | `Ctrl + Shift + P` |
| ターミナル | `` Ctrl + ` `` |
| 全体から検索 | `Ctrl + Shift + F` |
| 保存 | `Ctrl + S` |
| 定義へ移動 | `F12` |
| デバッグ開始 | `F5` |
| タスク実行 | `Ctrl + Shift + P` →「Tasks: Run Task」 |

## Docker
| 目的 | 命令 |
|---|---|
| 動いているか | `docker version` |
| 一覧 | `docker ps -a`　`docker images` |
| イメージを作る | `docker build -t 名前:1.0 .` |
| フォルダを共有して中に入る | `docker run --rm -it -v "$PWD:/work" -w /work 名前:1.0 bash` |
| ログを見る | `docker logs 名前` |
| 止める・消す | `docker stop 名前`　`docker rm 名前` |
| 容量を確認 | `docker system df` |

## Git
| 目的 | 命令 |
|---|---|
| 状態 | `git status` |
| 変更を入れる | `git add ファイル名` |
| 記録する | `git commit -m "要件番号: 内容"` |
| 差分 | `git diff`　`git diff --staged` |
| 履歴 | `git log --oneline` |
| 枝 | `git switch -c 名前`　`git switch main` |
| 版の目印 | `git tag -a v1.0.0 -m "v1.0.0"` |
| 送る・受け取る | `git push`　`git pull` |
| 管理から外す | `git rm --cached ファイル名` |

## GitHub（gh）
| 目的 | 命令 |
|---|---|
| ログイン | `gh auth login` |
| 状態 | `gh auth status` |
| リポジトリを作る（非公開） | `gh repo create 名前 --private --source=. --remote=origin` |
| プルリクエスト | `gh pr create --title "..." --body "..."` |
| 自動試験の結果 | `gh run list`　`gh run view --log-failed` |

## 試験（プロジェクト）
| 目的 | 命令 |
|---|---|
| まとめて検証 | `npm run verify` |
| 画面の試験 | `npm run e2e` |
| API の試験 | `python3 -m unittest -v tests/test_api_contract.py` |
| ブラウザが動くか | `python3 scripts/check_browser.py` |
