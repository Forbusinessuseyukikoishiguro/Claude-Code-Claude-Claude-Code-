# 02 コマンドプロンプトと PowerShell の基本

## 2-1 どちらを使うか
| 項目 | コマンドプロンプト（cmd） | PowerShell |
|---|---|---|
| 開き方 | スタート →「cmd」 | スタート →「PowerShell」 |
| 特徴 | 昔からある。簡単な命令 | 新しい。複雑な処理や、スクリプトに向く |
| 本マニュアルでの使い方 | 基本の移動・確認 | 主に、インストールと確認 |

> 迷ったら、PowerShell を使う。

## 2-2 基本の操作（cmd と PowerShell で、同じ意味の命令）
| やりたいこと | cmd | PowerShell |
|---|---|---|
| 今いる場所を表示 | `cd` | `Get-Location`（または `pwd`） |
| 場所を移動 | `cd /d C:\work` | `Set-Location C:\work`（または `cd C:\work`） |
| ファイルの一覧 | `dir` | `Get-ChildItem`（または `ls`） |
| 文字を表示 | `echo hello` | `Write-Output hello` |
| ファイルの中身を表示 | `type a.txt` | `Get-Content a.txt` |
| フォルダを作る | `mkdir work` | `New-Item -ItemType Directory work` |
| ファイルの存在を確認 | `if exist a.txt echo あり` | `Test-Path a.txt` |
| コマンドの場所を確認 | `where git` | `Get-Command git` |
| 環境変数を表示 | `echo %PATH%` | `$env:PATH` |

## 2-3 よく使う例
```powershell
# 作業フォルダへ移動する（日本語のフォルダでも、引用符で囲む）
Set-Location "C:\work"

# いまのフォルダにある、ファイルの一覧
Get-ChildItem

# インストールされているかを確認する（見つからないと、エラーになる）
Get-Command git
```

## 2-4 PowerShell のスクリプトが「実行できない」とき
エラー例：「このシステムではスクリプトの実行が無効になっているため…」
- 対処（自分のユーザーだけの設定。管理者は不要）
  ```powershell
  Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
  ```
  「Y」を入力して Enter を押す。
- 注意：会社の PC で、この設定が禁止されている場合は、情報システム部門に相談する。

## 2-5 環境変数（APIキーなどを渡す方法）
- 一時的（そのウィンドウだけ）
  ```powershell
  $env:MY_API_KEY = "ここにキー"
  ```
- **注意**：キーをファイルに書かない。履歴に残るため、画面の共有にも注意する。
- 確認：`echo $env:MY_API_KEY`（PowerShell）で、値が表示されること

## 2-6 コマンドの途中で止まったとき
- `Ctrl + C` で、実行中のコマンドを止める
- 画面が固まったら、`Enter` を押す。それでも反応しなければ、ウィンドウを閉じて開き直す（実行中の作業は失われることがある）

## 2-7 コピーと貼り付け
- Windows のターミナル（Windows Terminal）では、`Ctrl + Shift + C`（コピー）、`Ctrl + Shift + V`（貼り付け）
- PowerShell の既定の画面では、右クリックで貼り付けられる設定のことが多い
