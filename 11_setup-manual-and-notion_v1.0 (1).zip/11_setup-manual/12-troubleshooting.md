# 12 トラブル対応表

| No. | 症状（画面の文字） | 原因の候補 | 対処 |
|---|---|---|---|
| 1 | `'git' は、内部コマンドまたは外部コマンド…` | Git が入っていない、または PowerShell を開き直していない | PowerShell を開き直す。`winget install --id Git.Git -e` |
| 2 | `node` が見つからない | Node.js を入れた後、開き直していない | 開き直す。`winget install --id OpenJS.NodeJS.LTS -e` |
| 3 | `…スクリプトの実行が無効になっているため…` | PowerShell の実行の制限 | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |
| 4 | Microsoft Store が開く（python） | Python の PATH の設定 | Python を入れ直す（PATH に追加）。`py --version` を試す |
| 5 | `Cannot connect to the Docker daemon` | Docker Desktop が起動していない | Docker Desktop を起動し、「Engine running」を待つ |
| 6 | WSL のバージョンが 1 | WSL 2 になっていない | `wsl --set-default-version 2`、`wsl --update` |
| 7 | 仮想化が無効と出る | BIOS/UEFI の設定 | 情報システム部門に依頼（VT-x / AMD-V を有効に） |
| 8 | 日本語が文字化けする | 文字コードの違い | `chcp 65001`（cmd）。VS Code の文字コードを UTF-8 に |
| 9 | `Permission denied` | 権限の不足、所有者の違い | `sudo` を使う（必要な場合のみ）。ファイルの所有者を確認 |
| 10 | `command not found`（Ubuntu） | 入っていない、PATH に無い | `which 名前` で確認。`sudo apt-get install` |
| 11 | git push で認証を求められて進まない | 認証の情報が古い | `gh auth login` をやり直す |
| 12 | `Permission denied (publickey)` | SSH の鍵の設定 | HTTPS の URL を使う（`git remote set-url origin https://...`） |
| 13 | config.js を push してしまった | .gitignore の前に追加した | `git rm --cached config.js`、コミット、push。**キーは必ず再発行** |
| 14 | ポートが使われている（Address already in use） | 前の起動が残っている | `ss -ltnp \| grep ポート番号` で確認し、そのプロセスを止める |
| 15 | 画面が開かない（file:// で開いた） | ブラウザの制限 | `python3 -m http.server 8000` で配信し、http:// で開く |
| 16 | `npm run verify` が失敗 | 版の違い、コードの変更 | 09 の手順で、失敗した行を見る。`git diff` で変更を確認 |
| 17 | Docker のイメージのビルドが途中で止まる | ネットワーク、ディスクの空き | `docker system df` で容量を確認。通信の制限を確認 |
| 18 | ディスクの空きが少ない | Docker のイメージが多い | `docker image prune`（使っていないものを消す）。`docker system df` で確認 |
| 19 | WSL が重い | プロジェクトが /mnt/c の下 | プロジェクトを ~/ の下に移す |
| 20 | VS Code の WSL 接続が切れる | WSL が止まった | `wsl --shutdown` の後、もう一度開く |
| 21 | 改行の警告（CRLF/LF） | 改行の設定の違い | 動作には影響しない。`git config core.autocrlf` を確認 |
| 22 | Actions が赤（失敗） | 手元との環境の違い | `gh run view --log-failed` で失敗行を見る |
| 23 | 試験結果が前回と違う | 変更、時間、順番の依存 | 09 の二分探索（git bisect）で、原因の変更を探す |
