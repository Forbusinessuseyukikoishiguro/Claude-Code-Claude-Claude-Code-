# 07 GitHub の操作（ブラウザと、コマンド）

## 7-1 GitHub アカウントを作る
1. https://github.com/ を開き、「Sign up」からアカウントを作る
2. メール認証を済ませる
3. 社内の方針で、個人アカウントの利用が禁止されていないかを確認する（規程に従う）

## 7-2 認証（パスワードの代わりに、トークンやブラウザ認証を使う）
GitHub では、Git のパスワード認証は使えない。次のどちらかを使う。
- **方法A（推奨・簡単）**：GitHub CLI（gh）で、ブラウザ認証を行う（7-3）
- **方法B**：Git Credential Manager（Windows の Git に付いている）で、初回の push のときにブラウザで認証する

## 7-3 GitHub CLI（gh）を入れて、ログインする
Windows（PowerShell）：
```powershell
winget install --id GitHub.cli -e
gh --version
gh auth login
```
Ubuntu（WSL）：
```bash
sudo apt-get install -y gh     # 入らない場合は、公式の手順（https://cli.github.com/）
gh --version
gh auth login
```
`gh auth login` の質問の答え方（例）：
1. Where do you use GitHub? → **GitHub.com**
2. Preferred protocol → **HTTPS**
3. Authenticate Git with your GitHub credentials? → **Yes**
4. How would you like to authenticate? → **Login with a web browser**
5. 表示された8桁のコードを、ブラウザに入力して承認する

確認：`gh auth status` で、ログインしているアカウント名が出ること。

## 7-4 リポジトリを作る（コマンドで）
```bash
gh repo create azure-speech-transcriber --private --source=. --remote=origin
```
- `--private`：非公開（社内ツールは必ず非公開）
- 作られたら、`git remote -v` で、origin が設定されていること

## 7-5 リポジトリを作る（ブラウザで）
1. GitHub の右上の「+」→「New repository」
2. 名前を入力（英数字とハイフン）
3. 「Private」を選ぶ
4. README や .gitignore を**追加しない**（手元のファイルと衝突するため）
5. 「Create repository」

表示される命令を、手元で実行する：
```bash
git remote add origin https://github.com/アカウント名/リポジトリ名.git
git push -u origin main
```

## 7-6 送る・受け取る（push と pull）
```bash
git push                 # 手元の変更を、GitHub へ送る
git pull                 # GitHub の変更を、手元に取り込む
git fetch                # 取り込まず、状態だけ確認する
```
- **作業の前に `git pull`、作業の後に `git push`** が基本

## 7-7 タグを送る
```bash
git push origin --tags
```

## 7-8 プルリクエスト（レビューの依頼）
```bash
git switch -c feature/変更の名前
git add ファイル名
git commit -m "FR-xx: 変更の内容"
git push -u origin feature/変更の名前
gh pr create --title "FR-xx: 変更の内容" --body "対応する要件：FR-xx、AC-xx。試験：（結果を書く）。未確認：（書く）"
gh pr view --web          # ブラウザで開く
```
- 本文には、対応する要件、試験の結果、未確認の項目を書く（レビュー依頼のテンプレートを参照）

## 7-9 Actions（自動の試験）の結果を見る
```bash
gh run list               # 最近の実行の一覧
gh run view               # 最新の実行の詳細
gh run watch              # 実行の完了を待つ
```
- 赤い×（失敗）のときは、`gh run view --log-failed` で失敗した行を見る

## 7-10 Issue（課題の記録）
```bash
gh issue create --title "不具合：（現象）" --body "再現手順・期待する結果・実際の結果"
gh issue list
```

## 7-11 よくある注意
- **秘密情報を、リポジトリに入れない**。入れてしまったら、キーを再発行し、履歴からも消す（情報システム部門に相談）
- リポジトリの公開範囲（Private か Public か）を、push の前に確認する
- 社外の人にリポジトリを招待する前に、社内規程を確認する
