# Notion テンプレート一式と改修スキル（今後の開発用）

| フォルダ・ファイル | 内容 |
|---|---|
| import/pages/ | Notion に取り込む Markdown（8ページ：概要、要件、決定と未確定事項、試験、不具合と改修、会議メモ、リリース前チェック、スキルの使い方） |
| import/databases/ | Notion に取り込む CSV（5つのデータベース：要件、決定、未確定事項、試験結果、不具合） |
| copy-paste/notion-templates-copy-paste.md | 上のページを1つにまとめた、コピペ用 |
| IMPORT-GUIDE.md | 取り込みの手順（ページは一括、CSV は1ファイルずつ） |
| .claude/skills/spec-driven-change/ | 改修スキル（SKILL.md と reference/checklist.md） |

## 使う順番
1. IMPORT-GUIDE.md を読み、ページと CSV を取り込む
2. 例の行（EX-）を、実データに置き換える
3. 改修のとき、Claude Code で spec-driven-change スキルを使う（07_claude-skill-usage.md を参照）
4. 変更の後、Notion の写しを更新する（正本は docs/）
