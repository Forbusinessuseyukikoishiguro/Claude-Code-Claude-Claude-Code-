# 環境構築（初回・次回）の記録

> 手順の本体は、リポジトリの setup-manual フォルダ（00〜12）にある。このページは、進み具合と結果を記録するための写し。

## 1. 初回の進み具合（チェック）
- [ ] Windows Update を最新にした
- [ ] 仮想化が有効（Docker を使う場合）
- [ ] WSL 2 と Ubuntu を入れた（wsl --list --verbose で VERSION 2）
- [ ] Ubuntu の初回更新を行った
- [ ] Git を入れた
- [ ] Node.js 22（LTS）を入れた
- [ ] Python 3.12 以上を入れた
- [ ] VS Code を入れ、推奨拡張機能を入れた
- [ ] Docker Desktop を入れ、Engine running を確認した
- [ ] プロジェクトを Ubuntu の中（~/work）に置いた
- [ ] npm run verify が通った（pass 23）
- [ ] API の試験が通った（Ran 17、OK）
- [ ] GitHub にログインした（gh auth status）

## 2. 次回以降の確認
- [ ] git pull で、最新を取り込んだ
- [ ] 作業が終わり、git status で未コミットの変更がないことを確認した
- [ ] 試験の結果を、「試験結果」に書いた

## 3. 困ったとき
- トラブル対応表（setup-manual の 12）を見る
- 分析の手順（setup-manual の 09）に従って、事実・期待・再現・切り分けを書く
- 結果は「デバッグ記録」に残す

## 4. 注意
- APIキー、パスワード、個人情報を、このページに書かない
