# 10 次回以降の作業手順

## 10-1 作業を始める（毎回）
1. Docker Desktop を起動し、「Engine running」を確認する（使う場合）
2. Ubuntu（WSL）を開く
   ```bash
   cd ~/work/azure-speech-transcriber
   git status          # 前回の作業が残っていないか
   git pull            # GitHub の最新を取り込む
   ```
3. VS Code で、フォルダを開く（`code .`）

## 10-2 作業する
1. 変更の目的と、対応する要件の番号を決める（仕様の表で確かめる）
2. 仕様を先に直す（必要なら）
3. ソースを編集する（生成物を直接編集しない）
4. 試験を実行する
   ```bash
   npm run verify
   ```
5. 失敗したら、09 の手順で分析する

## 10-3 保存する（コミットと push）
```bash
git status                          # 変更を確認（config.js や結果ファイルが無いこと）
git add src docs scripts test       # 必要なものだけ追加
git diff --staged                   # 入る内容を最後に確認
git commit -m "FR-xx: 変更の内容（AC-xx）"
git push
```

## 10-4 確認する
- GitHub の Actions が緑（成功）であること（`gh run list`）
- 試験の結果を、Notion の「試験結果」に書いた

## 10-5 作業を終える
```bash
git status                          # 「nothing to commit」が理想
git log --oneline -3
```
- Docker のイメージが増えすぎたら、`docker system df` で確かめ、必要に応じて掃除する（05）

## 10-6 次回に持ち越すこと
- 未確認の項目（Notion の「未確定事項」に書く）
- 途中の作業（ブランチ名と、何をしたかを書く）
