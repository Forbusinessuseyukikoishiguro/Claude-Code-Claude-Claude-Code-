# 03 Ubuntu と WSL の基本

## 3-1 WSL と Ubuntu の関係
- **WSL**：Windows の中で Linux を動かす仕組み
- **Ubuntu**：その中で動く Linux の種類（OS）
- Ubuntu を開くと、黒い画面（ターミナル）が出て、`ユーザー名@PC名:~$` のような表示になる。これが「Linux の命令の場所」

## 3-2 Ubuntu を開く方法
1. スタートで「Ubuntu」と入力して開く
2. または、PowerShell で `wsl` と入力して Enter
3. 終わるときは `exit` と入力して Enter

## 3-3 WSL の命令（Windows の PowerShell で実行）
| 命令 | 意味 |
|---|---|
| `wsl --list --verbose` | 入っている Linux の一覧と、WSL の版（VERSION 2 が正しい） |
| `wsl -d Ubuntu` | Ubuntu を開く |
| `wsl --shutdown` | WSL を全部止める（Docker の調子が悪いときなどに使う） |
| `wsl --update` | WSL を最新にする |
| `wsl --status` | WSL の状態を表示する |

## 3-4 Ubuntu の基本の命令（Linux の命令）
| 命令 | 意味 | 例 |
|---|---|---|
| `pwd` | 今いる場所を表示 | `pwd` → `/home/ユーザー名` |
| `cd` | 場所を移動 | `cd ~/work`（~ は自分の家のフォルダ） |
| `ls -la` | ファイルの一覧（隠れたものも含む） | `ls -la` |
| `mkdir` | フォルダを作る | `mkdir work` |
| `cat` | ファイルの中身を表示 | `cat README.md` |
| `nano` | 簡単なエディタで開く（Ctrl+O で保存、Ctrl+X で終了） | `nano memo.txt` |
| `cp` | コピー | `cp a.txt b.txt` |
| `mv` | 移動・名前変更 | `mv a.txt b.txt` |
| `rm` | 削除（**元に戻せない**） | `rm b.txt` |
| `which` | 命令の場所を表示 | `which git` |
| `curl` | 通信の確認 | `curl -I https://example.com` |
| `sudo` | 管理者として実行（パスワードを聞かれる） | `sudo apt-get update` |

## 3-5 Windows のファイルと、Ubuntu のファイルの場所
| 場所 | Ubuntu から見た場所 | Windows から見た場所 |
|---|---|---|
| Ubuntu の家のフォルダ | `~`（例：`/home/ユーザー名`） | `\\wsl$\Ubuntu\home\ユーザー名` |
| Windows の C ドライブ | `/mnt/c` | `C:\` |

**重要**：プロジェクトは **Ubuntu の中（~ の下）に置く**。`/mnt/c` の下に置くと、遅くなり、変更の検知もうまくいかないことがある（Microsoft と Docker の公式の推奨）。

Windows のエクスプローラーで Ubuntu のフォルダを開く命令：
```bash
explorer.exe .
```

## 3-6 Ubuntu の最初の設定（一度だけ）
```bash
sudo apt-get update
sudo apt-get install -y git curl ca-certificates
git --version
```
- 確認：`git version 2.x` が出ること

## 3-7 Ubuntu で Node.js と Python を使う
```bash
sudo apt-get install -y python3 python3-venv
python3 --version
```
- Node.js は、Ubuntu の標準のものは版が古いことがある。Node.js 22 の入れ方は、`nvm`（Node の版の管理）を使う（公式：https://github.com/nvm-sh/nvm ）。講座では、Windows の Node.js と、Docker の中の Node.js を使う方法もある（08 を参照）。
