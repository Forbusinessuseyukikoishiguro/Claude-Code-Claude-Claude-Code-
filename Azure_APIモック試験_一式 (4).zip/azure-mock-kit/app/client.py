"""文字起こしAPIを呼ぶ側のコード（試験の対象）。標準ライブラリのみ。"""
import json, logging, time, urllib.request, urllib.error, uuid
from app.contract import validate

log = logging.getLogger("transcribe")
API = "/speechtotext/transcriptions:transcribe?api-version=2025-10-15"

class AuthError(Exception): pass
class ClientError(Exception): pass
class RetryExhausted(Exception): pass
class ContractError(Exception): pass

def _multipart(audio, definition):
    b = uuid.uuid4().hex
    parts = [f'--{b}\r\nContent-Disposition: form-data; name="audio"; filename="a.wav"\r\nContent-Type: audio/wav\r\n\r\n'.encode(), audio,
             f'\r\n--{b}\r\nContent-Disposition: form-data; name="definition"\r\n\r\n{json.dumps(definition)}\r\n--{b}--\r\n'.encode()]
    return b"".join(parts), f"multipart/form-data; boundary={b}"

def backoff(n, cap=30):           # 1回目の再試行=1秒、2秒、4秒…（上限 cap）。ジッターは試験の決定性のため別引数
    return min(2 ** (n - 1), cap)

def transcribe(base_url, key, audio, locales=("ja-JP",), max_tries=4, timeout=2.0, sleep=time.sleep, jitter=lambda: 0.0):
    body, ctype = _multipart(audio, {"locales": list(locales)})
    for tries in range(1, max_tries + 1):
        req = urllib.request.Request(base_url + API, data=body, method="POST",
                                     headers={"Ocp-Apim-Subscription-Key": key, "Content-Type": ctype})
        retry_after = None
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = r.read()
            try: obj = json.loads(data)
            except ValueError as e: raise ContractError(f"応答がJSONでない: {e}")
            errs = validate(obj)
            if errs: raise ContractError("; ".join(errs))
            return obj
        except urllib.error.HTTPError as e:
            if e.code == 401: raise AuthError("401")
            if e.code not in (429, 500, 502, 503, 504):
                raise ClientError(f"再試行しないエラー {e.code}")
            ra = e.headers.get("Retry-After")
            retry_after = float(ra) if ra and ra.isdigit() else None
            reason = f"HTTP {e.code}"
        except (TimeoutError, urllib.error.URLError, OSError) as e:
            reason = f"通信 {type(e).__name__}"
        if tries == max_tries:
            raise RetryExhausted(f"{max_tries}回で失敗（最後: {reason}）")
        wait = max(backoff(tries) + jitter(), retry_after or 0)   # Retry-After があれば、それ以上待つ（公式）
        log.warning("一時的エラー %s。%s秒待って再試行（%d/%d）", reason, wait, tries, max_tries)
        sleep(wait)
