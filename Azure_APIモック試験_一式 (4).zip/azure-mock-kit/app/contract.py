"""契約（AC-08）：高速文字起こしAPIの応答に最低限あるべき項目。出典＝公式の応答項目（2026-11-15 確認）。"""
def validate(resp):
    errs = []
    if not isinstance(resp, dict): return ["応答がオブジェクトではない"]
    if not isinstance(resp.get("durationMilliseconds"), int): errs.append("durationMilliseconds がない／整数でない")
    cp = resp.get("combinedPhrases")
    if not (isinstance(cp, list) and cp and isinstance(cp[0].get("text"), str)): errs.append("combinedPhrases[0].text がない")
    ph = resp.get("phrases")
    if not isinstance(ph, list): errs.append("phrases がない")
    else:
        for i, p in enumerate(ph):
            for k, t in (("offsetMilliseconds", int), ("durationMilliseconds", int), ("text", str)):
                if not isinstance(p.get(k), t): errs.append(f"phrases[{i}].{k} がない／型が違う")
    return errs
