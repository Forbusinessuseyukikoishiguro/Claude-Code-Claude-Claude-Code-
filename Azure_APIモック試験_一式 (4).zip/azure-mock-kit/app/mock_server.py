"""模倣サーバー（Azure AI Speech 高速文字起こしAPIの形を真似た、ダミー応答だけを返すもの）。
本物のAzureには接続しない。秘密は使わない（キーは固定のダミー文字列）。
制御用: POST /__mock/sequence でステータスの並びを予約、GET /__mock/requests で受信記録を取得。"""
import json, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DUMMY_KEY = "dummy-key-not-a-secret"
PATH = "/speechtotext/transcriptions:transcribe"

OK_BODY = {
    "durationMilliseconds": 2000,
    "combinedPhrases": [{"text": "こんにちは"}],
    "phrases": [{"offsetMilliseconds": 0, "durationMilliseconds": 2000, "text": "こんにちは",
                 "words": [{"text": "こんにちは", "offsetMilliseconds": 0, "durationMilliseconds": 2000}],
                 "locale": "ja-JP", "confidence": 0.95}],
}

class State:
    def __init__(self):
        self.lock = threading.Lock()
        self.sequence = []      # 例: [429, 429, 200]。空なら 200
        self.retry_after = None # 429/503 に付ける Retry-After（秒）
        self.delay = 0.0        # 応答までの遅延（秒）
        self.body_override = None  # 壊れた本文の再現用（文字列）
        self.requests = []

def make_handler(state):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def _send(self, code, body=b"", ctype="application/json", extra=None):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            for k, v in (extra or {}).items(): self.send_header(k, str(v))
            self.end_headers(); self.wfile.write(body)
        def do_GET(self):
            if self.path == "/__mock/requests":
                with state.lock: data = json.dumps(state.requests).encode()
                return self._send(200, data)
            self._send(404, b'{"error":"not found"}')
        def do_POST(self):
            n = int(self.headers.get("Content-Length", 0)); raw = self.rfile.read(n)
            if self.path == "/__mock/sequence":
                cfg = json.loads(raw or b"{}")
                with state.lock:
                    state.sequence = list(cfg.get("statuses", []))
                    state.retry_after = cfg.get("retry_after")
                    state.delay = float(cfg.get("delay", 0))
                    state.body_override = cfg.get("body_override")
                    state.requests = []
                return self._send(200, b"{}")
            path, _, query = self.path.partition("?")
            with state.lock:
                state.requests.append({"path": path, "query": query, "key": self.headers.get("Ocp-Apim-Subscription-Key"),
                                       "ctype": self.headers.get("Content-Type", "")[:19], "bytes": n})
                code = state.sequence.pop(0) if state.sequence else 200
                ra, delay, override = state.retry_after, state.delay, state.body_override
            if delay: time.sleep(delay)
            if path != PATH: return self._send(404, b'{"error":"not found"}')
            if self.headers.get("Ocp-Apim-Subscription-Key") != DUMMY_KEY:
                return self._send(401, b'{"error":{"code":"Unauthorized"}}')
            if code in (429, 503):
                extra = {"Retry-After": ra} if ra is not None else {}
                return self._send(code, json.dumps({"error": {"code": str(code)}}).encode(), extra=extra)
            if code >= 400:
                return self._send(code, json.dumps({"error": {"code": str(code)}}).encode())
            if override is not None: return self._send(200, override.encode())
            return self._send(200, json.dumps(OK_BODY, ensure_ascii=False).encode())
    return H

class _Quiet(ThreadingHTTPServer):
    def handle_error(self, request, client_address):  # 試験でクライアントが先に切断（タイムアウト試験）しても騒がない
        pass

class MockServer:
    def __init__(self):
        self.state = State()
        self.httpd = _Quiet(("127.0.0.1", 0), make_handler(self.state))
        self.url = f"http://127.0.0.1:{self.httpd.server_address[1]}"
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
    def start(self): self.thread.start(); return self
    def stop(self): self.httpd.shutdown(); self.httpd.server_close()

if __name__ == "__main__":
    s = MockServer().start(); print("mock:", s.url, " (Ctrl+C で終了)")
    try:
        while True: time.sleep(1)
    except KeyboardInterrupt: s.stop()
