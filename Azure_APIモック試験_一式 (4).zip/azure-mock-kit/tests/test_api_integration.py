import json, os, unittest, urllib.request
from app.mock_server import MockServer, DUMMY_KEY, OK_BODY
from app.client import transcribe, AuthError, ClientError, RetryExhausted, ContractError
from app.contract import validate

class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.srv = MockServer().start()
    @classmethod
    def tearDownClass(cls): cls.srv.stop()
    def setUp(self): self.waits = []
    def seq(self, statuses, **kw):
        req = urllib.request.Request(self.srv.url + "/__mock/sequence", data=json.dumps({"statuses": statuses, **kw}).encode(), method="POST")
        urllib.request.urlopen(req).read()
    def recorded(self):
        return json.loads(urllib.request.urlopen(self.srv.url + "/__mock/requests").read())
    def call(self, key=DUMMY_KEY, **kw):
        return transcribe(self.srv.url, key, b"RIFF....", sleep=self.waits.append, **kw)

class TestApiIntegration(Base):
    def test_AC_01_success_returns_text_and_sends_key_and_multipart(self):
        self.seq([])
        r = self.call()
        self.assertEqual(r["combinedPhrases"][0]["text"], "こんにちは")
        q = self.recorded()[0]
        self.assertEqual(q["key"], DUMMY_KEY); self.assertIn("multipart/form-data", q["ctype"]); self.assertIn("api-version=2025-10-15", q["query"])
    def test_AC_02_401_is_not_retried(self):
        self.seq([])
        with self.assertRaises(AuthError): self.call(key="wrong")
        self.assertEqual(len(self.recorded()), 1); self.assertEqual(self.waits, [])
    def test_AC_03_429_then_200_waits_at_least_retry_after(self):
        self.seq([429, 200], retry_after=5)
        self.assertEqual(self.call()["durationMilliseconds"], 2000)
        self.assertEqual(len(self.recorded()), 2); self.assertEqual(self.waits, [5.0])   # backoff 1秒より Retry-After 5秒が優先
    def test_AC_04_503_repeated_gives_up_after_max_tries(self):
        self.seq([503, 503, 503, 503, 503])
        with self.assertRaises(RetryExhausted): self.call(max_tries=3)
        self.assertEqual(len(self.recorded()), 3); self.assertEqual(self.waits, [1, 2])
    def test_AC_05_400_is_not_retried(self):
        self.seq([400])
        with self.assertRaises(ClientError): self.call()
        self.assertEqual(len(self.recorded()), 1)
    def test_AC_06_broken_or_incomplete_body_raises_contract_error(self):
        for body in ("not json", '{"durationMilliseconds": 1}'):
            with self.subTest(body=body):
                self.seq([], body_override=body)
                with self.assertRaises(ContractError): self.call()
    def test_AC_07_timeout_is_retried_then_gives_up(self):
        self.seq([], delay=0.4)
        with self.assertRaises(RetryExhausted): self.call(max_tries=2, timeout=0.1)
        self.assertEqual(len(self.waits), 1)
    def test_AC_08_mock_ok_body_matches_contract(self):
        self.assertEqual(validate(OK_BODY), [])
        for k in ("durationMilliseconds", "combinedPhrases", "phrases"):     # 1項目ずつ欠かして、契約が検出するか（契約が緩んでいないか）
            with self.subTest(missing=k):
                broken = {x: v for x, v in OK_BODY.items() if x != k}
                self.assertTrue(any(k in e for e in validate(broken)))

@unittest.skipUnless(os.environ.get("AZURE_SPEECH_KEY"), "実APIは未実施（AZURE_SPEECH_KEY 未設定）")
class TestRealApi(unittest.TestCase):
    def test_AC_09_real_api_smoke(self):
        self.fail("実リソースの名前・音声を用意して実装する（本講座では実行しない）")
