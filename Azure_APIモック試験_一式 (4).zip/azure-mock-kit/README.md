# azure-mock-kit（模倣サーバー × API連携試験）

Azure AI Speech 高速文字起こしAPIの「形」をまねた、ダミー応答だけの模倣サーバーと、それを呼ぶ側の試験。
Azureには接続しません。キーは固定のダミー文字列です。標準ライブラリのみ（Python 3.13で確認。Mac／Linux系。Windowsは未確認）。

1. 試験を流す：`python3 -m unittest discover -s tests -t . -v`（9件：8合格・1スキップ）
2. 模倣サーバーだけ起動：`python3 -m app.mock_server`
3. before.txt：`docs/before.txt`（変更前の結果の保存例）
4. azure/function_app.py：Azure Functions（Python v2）の模倣サーバー例。`pip install azure-functions` 後に `python function_app.py` で直接呼び出し（ローカルで確認）。Azure上での実行は未確認
5. azure/apim_mock_policy.xml：API Management のモック応答ポリシーの設計例（動作未確認）
