"""Azure Functions（Python v2）で作る模倣サーバー。ダミー応答だけを返す。
ローカル: func start → http://localhost:7071/api/transcribe  ／ 単体: python function_app.py"""
import json
import azure.functions as func

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

OK = {"durationMilliseconds": 2000, "combinedPhrases": [{"text": "こんにちは"}],
      "phrases": [{"offsetMilliseconds": 0, "durationMilliseconds": 2000, "text": "こんにちは", "locale": "ja-JP", "confidence": 0.95}]}

@app.route(route="transcribe", methods=["POST"])
def transcribe(req: func.HttpRequest) -> func.HttpResponse:
    scenario = req.headers.get("X-Mock-Scenario", "ok")       # 例: ok / throttle / error
    if scenario == "throttle":
        return func.HttpResponse(json.dumps({"error": {"code": "429"}}), status_code=429, headers={"Retry-After": "2"}, mimetype="application/json")
    if scenario == "error":
        return func.HttpResponse(json.dumps({"error": {"code": "503"}}), status_code=503, mimetype="application/json")
    return func.HttpResponse(json.dumps(OK, ensure_ascii=False), status_code=200, mimetype="application/json")

if __name__ == "__main__":
    for sc in ("ok", "throttle", "error"):
        r = transcribe(func.HttpRequest("POST", "/api/transcribe", headers={"X-Mock-Scenario": sc}, body=b""))
        print(sc, r.status_code, r.headers.get("Retry-After"))
