# モックサーバーで Azure API の経路を試験する手順（丁寧版）

対象：音声文字起こしツール（index.html）が Azure Speech（Fast transcription）へ送る経路を、**本物の Azure に接続せず**、モックサーバー（mock-server.js）で試験する手順。

---

## 0. この手順で確かめられること・確かめられないこと

| 確かめられる（モックで行える） | 確かめられない（本物が必要） |
|---|---|
| 画面から、正しい形式で送信できるか | Azure が実際に受け付けるか（api-version、項目名） |
| キーの有無・誤りで、正しく案内が出るか | Azure の応答が、モックと同じ形か |
| 認識結果を、見出し付きで結合できるか | ブラウザから Azure へ直接通信できるか（CORS） |
| 429 などの失敗で、再試行し、完了するか | 実際の認識の精度、処理時間、料金 |
| 中止、保存、コピーなど、画面の操作 | 本物の利用上限、障害時の挙動 |

> **大事なこと**：モックで合格しても、本物で合格したことにはなりません。本物の確認は、最後に1分程度の音声で1回だけ行います（手順 10）。

---

## 1. 全体の流れ（図）

```
[ブラウザ：index.html]
   │  POST http://localhost:8787/speechtotext/transcriptions:transcribe?api-version=2024-11-15
   │  ヘッダー：Ocp-Apim-Subscription-Key: mock-key
   │  本文：audio（WAV）と definition（JSON）
   ▼
[モックサーバー：mock-server.js（ポート 8787）]
   │  キーを確かめ、経路を確かめ、決まった応答（combinedPhrases）を返す
   ▼
[ブラウザ]  見出し付きの結果を表示 → コピー・保存
```

---

## 2. 前提（準備するもの）

| 道具 | 版 | 確認コマンド |
|---|---|---|
| Node.js | 18 以上（22 推奨） | `node -v` |
| Python | 3.12 以上（画面の自動試験を行う場合） | `python3 --version` |
| ターミナル | Ubuntu、または WSL 2 の Ubuntu | — |
| curl | 任意 | `curl --version` |
| Chromium（自動試験の場合） | Playwright の導入で入る | `python3 -m playwright install chromium` |

> Windows でのみ行う場合は、WSL 2 の Ubuntu で行うことを勧める（手順は開発環境構築マニュアルの 03 を参照）。

---

## 3. 用語（最初に確認）

| 用語 | 意味 |
|---|---|
| モックサーバー | 本物の代わりに、決まった規則で応答するサーバー（mock-server.js） |
| ポート | サーバーが待ち受ける番号。モックは 8787、画面の配信は 8000 |
| キー（mock-key） | モックが正しいとみなす練習用の値。本物のキーではない |
| 経路 | URL のパス（/speechtotext/transcriptions:transcribe） |
| 再試行 | 一時的な失敗（429、5xx）のあと、待ってからもう一度送ること |

---

## 4. 手順 1：作業フォルダを確かめる

```bash
cd ~/work/azure-speech-transcriber     # 自分の作業フォルダへ移動
ls mock-server.js config.mock.js index.html scripts/azure_mock_check.sh
```

- 確認：4つのファイルが表示されること
- 表示されない場合は、zip を展開した場所を確かめる（開発環境構築マニュアル 08 を参照）

---

## 5. 手順 2：設定を、練習用に切り替える

画面（index.html）は、`config.js` を読む。練習用の値は `config.mock.js` にある。

### 5-1 既存の config.js を退避する（大事）
```bash
[ -f config.js ] && cp config.js config.real.js && echo "退避しました：config.real.js"
```
- `config.real.js` は、本物の設定（キーを含む）を残すための退避先。Git の対象外、共有しない

### 5-2 練習用の設定を、config.js としてコピーする
```bash
cp config.mock.js config.js
cat config.js
```
- 確認：`endpoint: "http://localhost:8787"` と `apiKey: "mock-key"` が表示されること

> 注意：手順 9 で、必ず元に戻す（`config.real.js` を `config.js` に戻す）。

---

## 6. 手順 3：モックサーバーを起動する

### 6-1 基本の起動（ターミナル1）
```bash
PORT=8787 node mock-server.js
```
- 確認：`mock Azure Speech on http://localhost:8787` と表示されること
- このターミナルは、試験の間ずっと開いたままにする
- 止める：`Ctrl + C`

### 6-2 再試行を確かめる起動（失敗を混ぜる）
```bash
FAIL_EVERY=2 PORT=8787 node mock-server.js
```
- 意味：2 回に 1 回、429（利用上限）を返す
- 確かめ方は手順 7 を参照

### 6-3 応答の遅さを変える（任意）
- 既定では、正常な応答は約 1.2 秒後に返る。これはファイルの中で決まっている（mock-server.js の `setTimeout` の値）
- 遅さを変えたい場合は、mock-server.js の値を直す（直したら、必ず試験を実行し直す）

---

## 7. 手順 4：モックに、直接、正しく応答するかを確かめる

### 7-1 自動の確認（推奨）
別のターミナル（ターミナル2）で、次を実行する。
```bash
bash scripts/azure_mock_check.sh          # 基本の確認（4 件）
bash scripts/azure_mock_check.sh retry    # 再試行の確認（2 件）
```
- 確認：最後の行が `不合格 0` であること（終了コードは 0）
- このスクリプトは、自分でモックを起動し、確かめ、止める。ターミナル1のモックとは別に動くため、ポートが空いている必要がある（手順 6 のモックを止めてから実行する）

### 7-2 手動の確認（仕組みを理解するため）
ターミナル1のモックが起動している状態で、ターミナル2で次を実行する。

**(a) 正しいキーで送る（期待：HTTP 200、combinedPhrases が返る）**
```bash
curl -s -X POST "http://localhost:8787/speechtotext/transcriptions:transcribe?api-version=2024-11-15" \
  -H "Ocp-Apim-Subscription-Key: mock-key" \
  -F "audio=@test/sample-2min.wav;filename=segment.wav;type=audio/wav" \
  -F 'definition={"locales":["ja-JP"],"profanityFilterMode":"None"}'
```
- 応答の例：`{"durationMilliseconds":600000,"combinedPhrases":[{"text":"【モック】3.7MBの区間 #1 の文字起こし結果です。"}]}`

**(b) 誤ったキー（期待：HTTP 401）**
```bash
curl -s -o /dev/null -w "HTTP %{http_code}\n" -X POST "http://localhost:8787/speechtotext/transcriptions:transcribe?api-version=2024-11-15" \
  -H "Ocp-Apim-Subscription-Key: wrong" -F "audio=@test/sample-2min.wav"
```

**(c) 経路の誤り（期待：HTTP 404）**
```bash
curl -s -o /dev/null -w "HTTP %{http_code}\n" -X POST "http://localhost:8787/wrong-path" -H "Ocp-Apim-Subscription-Key: mock-key"
```

> Windows（PowerShell）で行う場合は、`curl.exe`（Windows 10 以降に入っている）を使う。`curl` は PowerShell の別の命令になっているため、`curl.exe` と書く。

---

## 8. 手順 5：画面で、手で試す（手動の試験）

### 8-1 画面を配信する（ターミナル2。モックは動いたまま）
```bash
cd ~/work/azure-speech-transcriber
python3 -m http.server 8000
```
- 確認：`Serving HTTP on ... port 8000` と表示されること
- 止める：`Ctrl + C`（試験が終わったら）

### 8-2 ブラウザで開く
ブラウザで **http://localhost:8000/index.html** を開く（`file://` で開かない）。

### 8-3 操作と、期待する結果
| 操作 | 期待する結果 |
|---|---|
| 「音声ファイル」で test/sample-2min.wav を選ぶ | ファイル名、容量（3.7 MB）、再生時間（00:02:00）が表示される |
| 分割単位を「1分」にする | 分割数の目安が「→ 分割数 2 件」になる |
| 開始時刻は「0」のまま | （空欄だと案内が出る。0 と入力する） |
| 「文字起こし開始」を押す | 進捗が「第1/2部」→「第2/2部」と進み、完了する（各約 1.2 秒） |
| 結果欄を見る | `--- 第1部（00:00:00〜00:01:00）---` と `--- 第2部（00:01:00〜00:02:00）---` の見出し。本文は「【モック】…」 |
| 「テキストで保存」 | sample-2min.txt が保存される |

---

## 9. 手順 6：自動の試験を実行する（画面の総合試験）

この試験は、**自分でモックと画面の配信を起動し、終わったら止める**。手順 3 と 8 のサーバーは止めておく。
```bash
npm run e2e
```
- 確認：最後の行が `== 結果: 合格 13 / 13 件 ==`
- 内容：正常系（表示、分割、結合、保存、BOM）、認証誤り（401）、再試行（429 → 完了）、中止、接続不可、コンソールエラーの確認

> 注意：この試験は、config.js を使わず、一時フォルダに練習用の設定を作る。本番の config.js は書き換えない。

---

## 10. 手順 7：失敗の場面を、手で確かめる（再試行・中止）

### 10-1 再試行（2 回に 1 回が 429）
1. ターミナル1で、`FAIL_EVERY=2 PORT=8787 node mock-server.js` を起動する（手順 6-2）
2. 手順 8 の画面で、分割 1 分、2 分の音声で開始する
3. 期待する結果：1 部目が完了 → 2 部目で「再試行中（1/3）…」が出る → 完了する（結果欄に 2 部分）

### 10-2 中止
1. 通常のモックで、分割 1 分の音声を開始する
2. 1 部目が完了したところで「中止」を押す
3. 期待する結果：「中止しました（1/2部まで完了）」。1 部目の結果は残り、コピーと保存ができる

### 10-3 認証の誤り
1. config.js の apiKey を `wrong` に書き換え、画面を読み直す（練習後は必ず mock-key に戻す）
2. 開始する → 期待：「APIキーまたは endpoint（リージョン）が正しくありません（401）」

---

## 11. 手順 8：結果を記録する（任意）

```bash
python3 scripts/run_all_tests.py      # 全試験（単体・画面・結合など）。結果は test/results/latest
npm run collect:e2e                   # 証跡の回収（報告書 report.md と manifest.json）
```
- 記録の仕方は、docs/evidence-guide.md を参照
- 報告には、必ず「確かめていないこと」（本物の Azure）を書く

---

## 12. 手順 9：後片付け（必ず行う）

1. 起動しているサーバーを止める（ターミナル1、2の `Ctrl + C`）
2. 練習用の設定を元に戻す
   ```bash
   [ -f config.real.js ] && mv config.real.js config.js && echo "本番の設定に戻しました"
   ```
   - 退避がない場合（最初から config.js が無かった場合）は、`rm -f config.js` で練習用の設定を消す
3. 確認：ポートが空いていること
   ```bash
   ss -ltn | grep -E ":8787 |:8000 " || echo "ポートは空いています"
   ```
4. 確認：`git status` で、config.js が追跡されていないこと（`.gitignore` で除外されている）

---

## 13. 手順 10：本物の Azure へ切り替える前の確認

モックで手順 1〜10 が通っても、次を確かめてから、本物を使う。

| 確認 | 方法 | 対応する未確定事項 |
|---|---|---|
| api-version が受け付けられる | 公式ドキュメントで最新を確認し、config.js の apiVersion を合わせる | OQ-01 |
| 項目名（audio、definition）が正しい | 公式ドキュメントの要求の形と照らす | OQ-01 |
| 応答の形（combinedPhrases）が正しい | 1 分の音声で 1 回だけ送り、Network の応答を見る | OQ-01 |
| ブラウザから直接通信できる（CORS） | http://localhost:8000 で開いて、コンソールに CORS のエラーがないか見る | OQ-02 |
| キーは環境変数などで渡す | config.js に、キーを書いた状態で共有・コミットしない | 秘密情報の方針 |
| 費用と利用の上限 | Azure の料金表と、利用の上限を確かめる | OQ-06 |

> 本物で1回だけ確かめる際は、音声を 1 分程度にする。長い音声は、結果の形が確かめられてから行う。

---

## 14. うまくいかないときの対処

| 症状 | 原因の候補 | 対処 |
|---|---|---|
| `EADDRINUSE` や「Address already in use」 | ポート 8787 または 8000 が使用中 | `ss -ltnp \| grep -E ":8787 \|:8000 "` で確かめ、そのプロセスを止める |
| 画面で「接続できません」 | モックが起動していない、config.js の endpoint が違う | ターミナル1のモックを確かめ、config.js が `http://localhost:8787` か確認 |
| 画面で「APIキーまたは endpoint が正しくありません（401）」 | apiKey が mock-key ではない | config.js の apiKey を mock-key に戻す |
| 画面で「Azure APIエラー（404）」 | endpoint の末尾や経路の誤り | endpoint は `http://localhost:8787`（経路は書かない）。末尾に余分な文字がないか確かめる |
| 進捗が止まったまま | 遅い応答、または中止の操作 | 数十秒待つ。止まる場合は中止して、モックを再起動する |
| `ss` コマンドが無い | 道具が入っていない | `sudo apt-get install -y iproute2` |
| curl で文字化けする | 端末の文字コード | `chcp 65001`（Windows の cmd）、ターミナルを UTF-8 にする |
| `npm run e2e` が Chromium を見つけられない | ブラウザ未導入 | `python3 -m playwright install chromium` |

---

## 15. 付録：アプリが送る内容と、モックの応答（対応表）

| 項目 | アプリの送信（app の run → callAzure） | モックの扱い |
|---|---|---|
| メソッド | POST | POST のみ受け付ける。それ以外は 404 |
| 経路 | `{endpoint}/speechtotext/transcriptions:transcribe` | この経路以外は 404 |
| api-version | URL の `?api-version=2024-11-15`（config.js の apiVersion） | 値は確かめない（本物では確認が必要：OQ-01） |
| 認証 | ヘッダー `Ocp-Apim-Subscription-Key` | 値が mock-key と一致しなければ 401 |
| 本文 | `audio`（WAV）、`definition`（JSON） | 中身は解析しない。受信したバイト数だけを数える |
| 成功の応答 | 200、JSON の `combinedPhrases[].text` を改行で連結 | 同じ形で返す（本物と一致するかは未確認：OQ-01） |
| 失敗 | 429・5xx は再試行、401・400 は再試行しない | FAIL_EVERY の回数ごとに 429 |

> 注意：この表の「モックの扱い」は、模倣の規則であり、本物の仕様ではない。本物の仕様は、公式ドキュメントで確かめる。
