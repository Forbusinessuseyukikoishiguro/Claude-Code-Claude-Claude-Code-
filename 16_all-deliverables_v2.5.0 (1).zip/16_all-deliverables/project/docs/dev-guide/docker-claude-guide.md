# Docker で仕様駆動開発をするとき：Claude から見えない問題の直し方

## 1. 結論
- **Ubuntu のイメージを自分で作る必要はありません。** 公式の `node:22-bookworm`（Debian）か `ubuntu:24.04` を基にした Dockerfile で十分です。
- 「Claude が見えない」は、**Claude を動かしている場所**と**ファイルがある場所**がずれていることが原因のことがほとんどです。

## 2. 仕組み（確認済み）
| 場所 | 見えるもの | 確認結果 |
|---|---|---|
| ホスト（あなたのPC） | ホストのフォルダ | `-v` で割り当てたフォルダの変更は、両側から見える（確認済み） |
| コンテナ（`-v` なし） | イメージの中のファイルだけ。作業フォルダ（/work）は空 | ホストのファイルは見えない（確認済み） |
| コンテナで作ったファイル（`-v` のフォルダの中） | ホストからも見える | 確認済み |
| コンテナで作ったファイル（`-v` の外） | `--rm` で消える | 一般的な動作（Docker の仕様） |

## 3. よくある原因と直し方
| 症状 | 原因 | 直し方 |
|---|---|---|
| Claude が、ソースや結果を見つけられない | Claude をホストで動かし、結果がコンテナの中だけにある | 結果を `-v` のフォルダへ出す（例：/app/test/results） |
| コンテナの中の Claude が、プロジェクトを見ない | `-v` を付けていない | `docker run -v "$PWD:/work" -w /work ...` |
| Windows で、パスが認識されない | cmd と PowerShell の書き方の違い | PowerShell は `"${PWD}:/work"`、cmd は `"%cd%:/work"` |
| Windows の WSL で遅い、または変更が反映されない | プロジェクトが `/mnt/c` にある | プロジェクトを WSL の中（~/）に置く |
| Linux で、コンテナが作ったファイルを編集できない | コンテナが root で作成 | `docker run --user "$(id -u):$(id -g)" ...`（Linux・WSL のユーザーの場合。未確認） |
| コンテナの中から `docker` が使えない | 既定ではホストの Docker に触れない | Claude のテストは、コンテナの中の `npm test` や `python3` で行う。Docker の起動は、ホストで行う |

## 4. 推奨の運用（2通り）
### A. Claude Code はホストで動かす（最も簡単）
1. VS Code（ホスト）で Claude Code を使い、仕様とコードを編集する
2. 試験は、コンテナで実行する
   ```
   docker run --rm --shm-size=1g -v "$PWD:/work" -w /work web-dev:1.0 sh -c "npm run verify && npm run e2e"
   ```
3. 結果は `-v` のフォルダ（test/results）に残るので、Claude が読める

### B. Claude Code をコンテナの中で動かす（環境を揃えたいとき）
1. VS Code の「Dev Containers」で、フォルダをコンテナの中で開く（`/work` が作業フォルダになる）
2. その中で Claude Code を起動する。コンテナの中のファイルと試験を、同じ場所で扱える
3. Claude Code の認証（キー）は、環境変数で渡す。Git やファイルに書かない

## 5. 確認の手順（5分でできる）
```bash
echo "hello" > host-check.txt
docker run --rm -v "$PWD:/work" -w /work web-dev:1.0 cat host-check.txt   # hello が出ればOK
docker run --rm -v "$PWD:/work" -w /work web-dev:1.0 sh -c "echo from-container > c.txt"
cat c.txt                                                                   # ホストから見えればOK
rm -f host-check.txt c.txt
```

## 6. 注意
- 仕様駆動の記録（docs/spec.md、docs/decisions.md、test/results）は、必ず `-v` の中に置く。コンテナの中だけに置くと、消える
- APIキーは、イメージにもフォルダにも入れない（環境変数で渡す）
- この手順は、このプロジェクトの検証環境（Ubuntu 24.04 の基礎イメージ）で確かめた部分と、一般的な動作に基づく部分を含む。Windows の Docker Desktop と、非 root の Linux での所有者の問題は、お手元で確かめてください
