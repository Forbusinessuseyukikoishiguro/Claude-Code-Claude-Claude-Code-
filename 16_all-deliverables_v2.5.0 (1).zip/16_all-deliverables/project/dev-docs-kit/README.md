# 実装中・前後の資料テンプレート一式

| 番号 | ファイル | 使う段階 |
|---|---|---|
| 00 | 00-development-set.md（開発のセット：全体マップ） | 全体 |
| 01 | 01-spec-to-requirements.md（仕様を要件に起こす） | 作成前 |
| 02 | 02-task-summary.md（タスクまとめ） | 作成前 |
| 03 | 03-personal-notes.md（自分用資料） | 実装中 |
| 04 | 04-pre-review-material.md（レビュー前資料） | 実装中 |
| 05 | 05-customer-report-template.md（お客様向け資料） | 完成後 |
| 06 | 06-review-request-template.md（レビュー依頼） | 実装中 |
| 07 | 07-review-response-template.md（指摘対応） | 実装中 |
| 08 | 08-skills-summary.md（スキルまとめ） | 全体 |
| 09 | 09-skills-usage.md（スキル使い方） | 全体 |
| 10 | 10-glossary.md（用語まとめ） | 全体 |

## 使い方
1. 00 で、全体の流れを確認する
2. 01 で、仕様を要件に起こし、発注者と合意する
3. 02 で、タスクに分ける
4. 作業中は 03 に記録し、レビューの前に 04、依頼に 06、指摘の対応に 07 を使う
5. 納品のときに 05 を使う（社内の記録は含めない）

Notion に取り込む場合は、../notion-kit/IMPORT-GUIDE.md を参照する。
