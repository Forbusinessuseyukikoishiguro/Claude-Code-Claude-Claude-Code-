# Azure Speech 文字起こしツール

ブラウザで音声ファイルを文字起こしする、単一HTMLのツールです（Azure Speech の Fast transcription API を使用）。

## まず読むもの
| 目的 | 文書 |
|---|---|
| 新人向けの解説（図解つき） | `docs/beginner-guide/beginner-guide.md` |
| Docker で試験（ブラウザ起動の確認つき） | `docker-guide.md` |
| 初めて触る（Windows・Git・GitHub・Docker） | `docs/setup-guide.md` |
| 仕様（要件・受け入れ基準） | `docs/spec-integrated.md`（統合版）、`docs/spec.md` |
| 試験 | `TEST-PROCEDURE.md`、`npm run verify`、`npm run e2e` |
| 証跡の回収 | `docs/evidence-guide.md`、`npm run collect` |
| 決定事項・未解消事項 | `docs/decisions.md`、`docs/open-questions.md` |
| Claude Code での作業 | `CLAUDE.md`、`.claude/skills/evidence-collect/` |

## 最短の使い方（Windows）
```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\windows\setup.ps1   # 初回のみ
npm run verify
npm run e2e
```

## 利用者の使い方
1. `index.html` をブラウザで開く（Chrome または Edge 推奨）。ネットワーク制限がある場合は、`python -m http.server 8000` で配信して `http://localhost:8000/index.html` を開く。
2. 音声ファイルを選ぶ（またはドロップ）。
3. 分割単位を選ぶ。30分を超える音声を分割したピースを続けて処理する場合は、「このファイルの開始時刻（分）」に、そのピースの開始位置を分で入力する（最初のピースは 0）。
4. 「文字起こし開始」を押す。
5. 結果をコピー、または「テキストで保存」で .txt に保存する。

> 30分を超える音声は、事前に分割してから処理してください（docs/operations.md）。

## 注意
- 音声は設定された Azure Speech リソースに送信されます。機密情報の取り扱いに注意してください。
- `config.js` には APIキーを書きます。リポジトリにはコミットしません。
