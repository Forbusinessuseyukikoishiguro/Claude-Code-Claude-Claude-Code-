/* ============================================================================
 * lib.js — 純粋関数の集まり（DOM・ネットワーク・ブラウザAPIに依存しない）
 * ----------------------------------------------------------------------------
 * 役割:
 *   テストしやすいロジックをここに置きます。単体テストは test/unit/lib.test.js。
 *
 * 取り扱いルール:
 *   - 編集はこのファイルで行う。配布用の index.html は node build.js が生成する。
 *   - 副作用を持たない。同じ入力には必ず同じ出力を返す。
 *   - 追加・変更したら、対応する単体テストも更新する（TST-01）。
 * ============================================================================ */
(function (root) {
  "use strict";

  /**
   * 秒数を「hh:mm:ss」形式にする。
   * 有限の数値以外（NaN・Infinity・undefined・負数）は 00:00:00 として扱う。
   * 例: 3725 → "01:02:05"
   * 関連: FR-08（結果の時間表示）、FR-03（区間の見出し）
   */
  function fmtTime(sec) {
    // 有限で、正で、かつ現実的な上限（約31年）以下の数だけを対象にする（指数表記の崩れを防ぐ）
    const s = Number.isFinite(sec) && sec > 0 && sec < 1e9 ? Math.floor(sec) : 0;
    const pad = (n) => String(n).padStart(2, "0");
    return `${pad(Math.floor(s / 3600))}:${pad(Math.floor((s % 3600) / 60))}:${pad(s % 60)}`;
  }

  /**
   * バイト数を読みやすい単位にする。1MB未満は KB、それ以上は MB（小数1桁）。
   * 例: 12582912 → "12.0 MB"、500 → "1 KB"
   * 関連: FR-01（ファイル情報の表示）
   */
  function fmtSize(b) {
    if (!Number.isFinite(b) || b < 0) return "不明";  // 不正値は数値として表示しない
    return b >= 1048576
      ? (b / 1048576).toFixed(1) + " MB"
      : Math.max(1, Math.round(b / 1024)) + " KB";
  }

  /**
   * Float32の数値列（-1.0〜1.0）を、16bit PCMのWAVファイル（バイト列）にする。
   *
   * WAVの構成:
   *   [0-11]  RIFFヘッダー      [12-35] fmtチャンク（PCM・モノラル・周波数・16bit）
   *   [36-43] dataチャンク      [44〜]  音声データ（Int16、リトルエンディアン）
   *
   * 範囲外の値は -1〜1 に収めてから変換する（クリッピング）。
   * 関連: FR-07（Azureへ送る形式の作成）、NFR-02（16kHz・モノラルで通信量を抑える）
   * @param {Float32Array} f32 サンプル値
   * @param {number} rate      サンプリング周波数（Hz）
   * @returns {ArrayBuffer}
   */
  function wavFromFloat(f32, rate) {
    const n = f32.length;
    const view = new DataView(new ArrayBuffer(44 + n * 2));
    const writeStr = (o, s) => { for (let i = 0; i < s.length; i++) view.setUint8(o + i, s.charCodeAt(i)); };

    writeStr(0, "RIFF"); view.setUint32(4, 36 + n * 2, true); writeStr(8, "WAVE");
    writeStr(12, "fmt "); view.setUint32(16, 16, true); view.setUint16(20, 1, true);
    view.setUint16(22, 1, true); view.setUint32(24, rate, true); view.setUint32(28, rate * 2, true);
    view.setUint16(32, 2, true); view.setUint16(34, 16, true);
    writeStr(36, "data"); view.setUint32(40, n * 2, true);

    let o = 44;
    for (let i = 0; i < n; i++, o += 2) {
      const s = Math.max(-1, Math.min(1, f32[i]));
      view.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    }
    return view.buffer;
  }

  /**
   * 音声の長さと分割単位から、区間の一覧を作る。
   * 最後の区間は残りの長さだけにする（端数を捨てない）。
   * 例: (3725, 600) → 7区間。最後は offset 3600・duration 125
   * 関連: FR-03（分割）、FR-05（分割単位の変更）、FR-06（自動処理）
   * @param {number} durationSec 音声の全長（秒）
   * @param {number} segSec      分割単位（秒）
   * @returns {{index:number, offset:number, duration:number, total:number}[]}
   */
  function buildSegments(durationSec, segSec) {
    if (!(durationSec > 0) || !(segSec > 0)) return [];
    // 浮動小数点の誤差（例：600.0000000000001 ÷ 600 = 1.0000000000000002）で
    // 長さ0秒の余分な区間が出ないように、1e-6 の許容差を入れて切り上げる
    const total = Math.ceil(durationSec / segSec - 1e-6);
    const out = [];
    for (let i = 0; i < total; i++) {
      const offset = i * segSec;
      out.push({
        index: i,
        offset,
        duration: Math.min(segSec, durationSec - offset),
        total,
      });
    }
    return out;
  }

  /**
   * 区間の見出し行を作る。結合後の結果で、どの時間の文字起こしかを示す。
   * 例: {index:0, offset:0, duration:600} → "--- 第1部（00:00:00〜00:10:00）---"
   * 関連: FR-06（結合）、FR-08（結果表示）
   */
  function segmentHeader(seg, baseSec) {
    // baseSec：このファイルの開始時刻（秒）。省略時は 0（従来どおり。FR-12 AC-12b）
    const base = Number.isFinite(baseSec) ? baseSec : 0;
    return `--- 第${seg.index + 1}部（${fmtTime(base + seg.offset)}〜${fmtTime(base + seg.offset + seg.duration)}）---`;
  }

  /**
   * ファイルの開始時刻（分）の入力を検査する（FR-12 AC-12c）。
   * 0 以上、100000 分（約69日）以下の有限の数だけを受け付ける。
   * @param {number} minutes 入力された分
   * @returns {{ok: boolean, seconds?: number, reason?: string}}
   */
  const BASE_MINUTES_MAX = 100000;   // 開始時刻の上限（分）。画面の入力欄の上限もこの値を使う（R-02）

  function validateBaseMinutes(minutes) {
    if (!Number.isFinite(minutes) || minutes < 0 || minutes > BASE_MINUTES_MAX) {
      return { ok: false, reason: `開始時刻は 0 から ${BASE_MINUTES_MAX} 分の範囲で入力してください。` };
    }
    return { ok: true, seconds: Math.round(minutes * 60) };
  }

  /**
   * 再試行してよい失敗かを判定する。
   * 再試行する: 通信断（TypeError）、429（利用上限）、5xx（サーバー側の障害）
   * 再試行しない: 400・401・403 など（同じ入力では結果が変わらない）、中止（AbortError）、タイムアウト（TimeoutError）
   * 関連: FR-10（エラーの扱い）、NFR-02（負荷の抑制）
   * @param {Error & {status?: number}} e
   * @returns {boolean}
   */
  function isRetryable(e) {
    if (!e || e.name === "AbortError" || e.name === "TimeoutError" || e.name === "InvalidResponse") return false;
    return e.name === "TypeError" || e.status === 429 || e.status >= 500;
  }

  /**
   * 失敗の種類に応じて、利用者向けの日本語メッセージを作る。
   * 原因の切り分けに必要なHTTPステータスは必ず含める。
   * 関連: FR-10（処理状況とエラーの把握）
   */
  function friendlyError(e) {
    if (e.name === "InvalidResponse") {
      return "Azureからの応答を読み取れませんでした。時間をおいて再実行してください。";
    }
    if (e.name === "TimeoutError") {
      return "Azureからの応答が時間内に返りませんでした（タイムアウト）。音声を短くして再度お試しください。";
    }
    if (e.name === "TypeError") {
      return "Azureに接続できません。ネットワーク・endpoint・ブラウザの制限（CORS）を確認してください。";
    }
    switch (e.status) {
      case 400: return `Azureが音声を受け付けませんでした（400）。${e.detail || ""}`;
      case 401:
      case 403: return `APIキーまたはendpoint（リージョン）が正しくありません（${e.status}）。`;
      case 413: return "1回の送信サイズが上限を超えました。分割単位を短くしてください。";
      case 429: return "APIの利用上限に達しました（429）。時間をおいて再実行してください。";
      default:
        return e.status
          ? `Azure APIエラー（${e.status}）。${e.detail || ""}`
          : (e.message || "不明なエラーです。");
    }
  }

  const api = { fmtTime, fmtSize, wavFromFloat, buildSegments, segmentHeader, validateBaseMinutes, BASE_MINUTES_MAX, isRetryable, friendlyError };

  // ブラウザ：グローバル window.AzureLib として公開
  root.AzureLib = api;
  // Node.js：require() で読み込めるように公開（テスト用）
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
