# レビュー依頼：CHG-2026-11-01（FR-12 事前分割ピースの開始時刻）

**件名**：【レビュー依頼】FR-12（開始時刻の連続化）

**依頼の要点**
- 対応する要件：FR-12（AC-12a、b、c）
- 変更の範囲：src/lib.js（segmentHeader、validateBaseMinutes、BASE_MINUTES_MAX）、src/index.html（入力欄、検査）、試験（AC-UT-12a〜d、I-08、A-25、A-26）、文書（spec、実装仕様、README）
- 期限：（YYYY-MM-DD）

**見てほしい点（3つまで）**
1. 見出しの時刻の計算（開始時刻を加える）が、仕様の例と一致しているか
2. 空欄と不正な入力が、送信されずに止まるか
3. 上限の定義が1か所になっているか

**見なくてよい点**
- 画面の見た目の細部（入力欄の幅）

**自分で確かめた結果**
- 単体：27件合格（node --test）
- 全試験：77件合格（run_all_tests.py）。変更前の70件は、すべて同じ結果（02-regression-report.md）

**確かめていないこと**
- 実 Azure、Edge、Windows での動作
- 人によるレビュー（このレビューの一回目は自己レビュー）

**資料**：00-change-request.md、01-review-findings.md、02-regression-report.md
