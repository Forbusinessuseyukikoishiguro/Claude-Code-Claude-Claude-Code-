#!/usr/bin/env python3
"""check_timetable.py — 時間割の合計が 180 分になることを確かめる（講座制作の検査）"""
import re, sys
rows = [l for l in open('01-timetable.md', encoding='utf-8') if re.match(r'^\| \d+:\d\d \|', l)]
total = 0
for r in rows:
    cols = [c.strip() for c in r.strip().strip('|').split('|')]
    start, end, minutes = cols[0], cols[1], int(cols[2])
    sh, sm = map(int, start.split(':')); eh, em = map(int, end.split(':'))
    span = (eh * 60 + em) - (sh * 60 + sm)
    if span != minutes:
        print(f'NG: {start}-{end} は {span} 分だが、表の値は {minutes} 分'); sys.exit(1)
    total += minutes
print(f'行数 {len(rows)}、合計 {total} 分')
sys.exit(0 if total == 180 else 1)
