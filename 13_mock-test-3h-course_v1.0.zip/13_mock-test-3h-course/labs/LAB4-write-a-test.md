# LAB4 テストを1つ追加する（15分）

## 目的
既存のテストと同じ形で、1つテストを追加し、実行する。

## 課題
「messages の content が 2000 文字を超えたら、送る前に ValueError になる」ことを確かめるテストを追加する。

## 手順
1. `tests/test_api_contract.py` を開く
2. `TestValidation` のクラスの最後に、次の形で追加する（名前は番号 V05 にする）
   ```python
   def test_V05_too_long_content_raises_value_error(self):
       """V05：content が 2000 文字を超えたら、通信せずに ValueError"""
       with self.assertRaises(ValueError):
           self.client().chat([{"role": "user", "content": "あ" * 2001}])
       self.assertEqual(self.requests_made(), 0)
   ```
3. 実装がまだ無いので、この試験は**不合格になるのが正しい**。実行して、どの行で失敗するかを読む
   ```
   python3 -m unittest -v -k V05 tests/test_api_contract.py
   ```
4. 講師の解答を見て、`client/chat_client.py` の `validate_messages` に 2000 文字の検査を足す（講師と一緒に）
5. もう一度実行し、合格になることを確かめる

## 確認
- 追加した試験の名前が、V05 で始まる
- 追加前と後で、全体の件数が 18 件になる（確認：`python3 -m unittest tests/test_api_contract.py`）

## 解答の方針（講師用）
```python
if len(m["content"]) > 2000:
    raise ValueError("content は2000文字以下にしてください")
```
- 注意：`validate_messages` の中の、既存の判定の後に入れる
