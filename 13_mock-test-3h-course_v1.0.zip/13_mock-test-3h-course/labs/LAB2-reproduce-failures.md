# LAB2 失敗を再現する（20分）

## 目的
失敗の応答を起こし、送信処理の扱いを、テストで確かめる。

## 手順
1. ターミナル1で、429 の模倣サーバーを起動する
   ```
   cd ~/work/azure-speech-transcriber/api-testing-kit
   MOCK_FAIL=429 PORT=8790 python3 server/mock_chat_server.py
   ```
2. ターミナル2で、curl で送る。`HTTP 429` が返ることを確かめる
   ```
   curl -s -o /dev/null -w "HTTP %{http_code}\n" -X POST http://127.0.0.1:8790/v1/chat/completions \
     -H "Authorization: Bearer test-key" -H "Content-Type: application/json" \
     -d '{"model":"mock-model","messages":[{"role":"user","content":"x"}]}'
   ```
3. ターミナル1で `Ctrl + C` を押して止める
4. 送信処理のテストを、失敗の名前で実行する（模倣サーバーは試験が自分で立てる）
   ```
   python3 -m unittest -v -k fail_429 tests/test_api_contract.py
   python3 -m unittest -v -k fail_500 tests/test_api_contract.py
   python3 -m unittest -v -k fail_bad_json tests/test_api_contract.py
   ```
5. 次の表に、結果を書く

| 試験 | 送った回数 | 最後の種類 | 合否 |
|---|---|---|---|
| fail_429 | 3 | rate_limit | |
| fail_500 | 3 | server | |
| fail_bad_json | 1 | bad_response | |

## 確認
- 429 と 500 は 3 回送られ、bad_json は 1 回だけ送られている
- 試験が合格していれば、表の数字と一致する

## 考えること
- なぜ bad_json は 1 回だけか
