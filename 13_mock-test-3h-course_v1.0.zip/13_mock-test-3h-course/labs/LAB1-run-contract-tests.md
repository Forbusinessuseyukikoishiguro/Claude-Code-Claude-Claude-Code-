# LAB1 契約テストを動かす（12分）

## 目的
17 件の契約テストを実行し、結果を読めるようにする。

## 手順
1. api-testing-kit のフォルダで、次を実行する
   ```
   python3 -m unittest -v tests/test_api_contract.py
   ```
2. 表示される行を、1行ずつ見る。`... ok` の行が、合格の試験
3. 最後の行を確かめる：`Ran 17 tests` と `OK`
4. 任意：1件だけ実行する（名前で絞る）
   ```
   python3 -m unittest -v -k auth tests/test_api_contract.py
   ```

## 確認
- 17 件が、すべて ok である
- 認証（auth）の 2 件は、通信の回数を確かめている（テストのコードの `requests_made` を見る）

## 困ったとき
- `FAIL:` が出た場合：その行の名前（例：`test_A02_...`）を控え、LAB2 の前に講師へ見せる
