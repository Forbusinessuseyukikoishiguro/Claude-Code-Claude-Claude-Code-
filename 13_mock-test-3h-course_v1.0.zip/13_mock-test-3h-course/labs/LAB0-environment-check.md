# LAB0 環境の確認（10分）

## 目的
道具が入っていて、講座の教材を開けることを確かめる。

## 手順
1. ターミナルを開く（Ubuntu または WSL）
2. 次を1行ずつ実行する
   ```
   python3 --version
   node -v
   ls ~/work/azure-speech-transcriber/api-testing-kit
   ```
3. api-testing-kit の中に `tests` と `server` があることを確かめる
4. 次を実行する（API の試験が動くことを確かめる）
   ```
   cd ~/work/azure-speech-transcriber/api-testing-kit
   python3 -m unittest tests/test_api_contract.py
   ```

## 確認
- Python が 3.12 以上を表示する
- `Ran 17 tests` と `OK` が表示される

## うまくいかないとき
- `No such file or directory`：フォルダの場所を確かめる（`pwd`、`ls`）
- `python3: command not found`：講師に確認する（Ubuntu には `sudo apt-get install -y python3` で入る）
