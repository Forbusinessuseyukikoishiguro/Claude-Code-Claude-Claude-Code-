# LAB3 画面テストと壊しに行くテスト（15分）

## 目的
画面テストを実行し、結果を読み、「壊れない」を確かめる試験を理解する。

## 手順
1. api-testing-kit のフォルダで、次を実行する
   ```
   python3 -m unittest -v tests/test_web_browser.py
   ```
   - ブラウザを使うので、数秒から十数秒かかる
   - Chromium が無い場合は、`skipped` と表示される（その場合は講師のデモを見る）
2. 5 件の結果を、次の表に書く

| 試験名（先頭の部分） | 結果 |
|---|---|
| web_send_shows_reply | |
| web_wrong_key_is_explained | |
| web_unreachable_server_is_explained | |
| web_empty_text_is_blocked_without_request | |
| web_html_in_reply_is_shown_as_text | |

3. 「web_html_in_reply_is_shown_as_text」を開き、何を確かめているかを読む
4. 任意：壊しに行く試験の考え方を、次の文で言い換える
   > 「応答に HTML があっても、画面で実行されず、文字として表示される」

## 確認
- 5 件すべてが ok または、講師の確認で合格とみなせる
- 「壊れない」を、判定できる形で書けている（「実行されない」「文字として表示される」）

## 困ったとき
- ブラウザが見つからない：`python3 -m playwright install chromium`（講師に確認）
