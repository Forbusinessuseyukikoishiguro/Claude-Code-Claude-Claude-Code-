# モックサーバーで学ぶテスト（3時間講座）

| フォルダ・ファイル | 内容 |
|---|---|
| 00-overview.md | 講座の概要、到達目標、構成 |
| 01-timetable.md | 1分単位の時間割（合計 180 分） |
| lectures/ | 講義の台本（L01〜L06） |
| labs/ | 実習（LAB0〜LAB4）。コマンドと確認の方法つき |
| quiz/quiz.md | 確認クイズ（10問、解答つき） |
| instructor-notes.md | 講師用の準備と進め方 |
| check_timetable.py | 時間割の合計が 180 分であることを確かめる |

教材（api-testing-kit）は、リポジトリの api-testing-kit フォルダ（zip 番号 06）を使う。
