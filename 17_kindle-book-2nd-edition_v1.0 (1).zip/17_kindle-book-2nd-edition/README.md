# 仕様を真実の源にする開発 第2版（Kindle・Word）

## 中身
| ファイル | 用途 |
|---|---|
| spec-driven-development-2nd.epub | Kindle（KDP）へ投入する EPUB（目次つき、EPUB3 形式の構造） |
| spec-driven-development-2nd.docx | Word 版（同じ原稿から作成。見出しは Word の見出しスタイル） |
| book.md | 原稿（唯一の正本。EPUB と Word は、ここから作る） |
| kindle.css | EPUB 用の簡素なスタイル |
| reference-jp.docx | Word 版の既定のスタイル（游ゴシック） |

## 原稿を直すとき（EPUB と Word を同時に直す）
```bash
cd book-2nd-edition
# 1) book.md を直す
# 2) EPUB を作る
pandoc book.md -o spec-driven-development-2nd.epub --css kindle.css --toc --toc-depth=2 -M lang=ja --split-level=1
# 3) Word 版を作る
pandoc book.md -o spec-driven-development-2nd.docx --toc --reference-doc=reference-jp.docx -M lang=ja
```
- 直した後、必ず両方を作り直す（片方だけ直すと、版がずれる）
- identifier（本の識別子）は変えない（変えると、別の本として扱われる）。版を上げるときだけ、新しい値にする

## Kindle（KDP）へ投入する手順
1. KDP にサインインし、「新しい Kindle 電子書籍」を作る
2. 言語：日本語。タイトル：「仕様を真実の源にする開発 第2版」
3. 原稿：spec-driven-development-2nd.epub をアップロードする（Word 版の .docx も投入できる）
4. 表紙：この一式には表紙画像を含めていない。表紙を用意する場合は、KDP の表紙の規格（サイズと解像度）を確認して差し込む
5. 内容の説明（description）：book.md の description を使う
6. 権利（rights）：本書の注記を確認し、必要なら社内の承認を得る
7. 投入の前に、**Kindle Previewer**（Amazon の公式ツール）で表示を確かめる（この作業環境では確かめていない）
8. 価格と販売地域は、社内の規程に従って決める

## 確かめたこと・確かめていないこと
| 項目 | 状態 |
|---|---|
| EPUB の構造（mimetype が先頭で無圧縮、XML の整形、言語 ja、書名、識別子） | 確認済み（検査スクリプト） |
| 章の数（18ファイル）、表（14）、生のマークアップが残っていないこと | 確認済み |
| Word 版：開けること（PDF に変換して開いた。19ページ）、見出し（18）、表（14）、游ゴシック | 確認済み |
| Kindle Previewer での表示 | 未確認（投入前に確かめる） |
| 表紙、ISBN、価格 | 未設定（社内の判断が必要） |
| 人によるレビュー（原稿の内容の確認） | 未実施 |
