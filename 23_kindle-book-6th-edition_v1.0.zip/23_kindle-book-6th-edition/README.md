# 仕様を真実の源にする開発 第6版（Kindle・Word）

## 中身
| ファイル | 用途 |
|---|---|
| spec-driven-development-6th.epub | Kindle（KDP）へ投入する EPUB（目次つき、図12点を内蔵） |
| spec-driven-development-6th.docx | Word 版（同じ原稿から作成） |
| book.md | 原稿（正本）。EPUB と Word は、ここから作る |
| figures/ | 図（PNG 12点） |
| kindle.css、reference-jp.docx | スタイル |

## 第6版で追加した章
- 第35章：ふんわりした依頼を仕様にする
- 第36章：要件を機能要件と非機能要件に分ける（ISO/IEC 25010 の観点）
- 第37章：デバッグの方法（実例3件）
- 第38章：回帰試験（実例 CHG-2026-11-01）
- 第39章：テスト用語
- 第40章：システム設計の基本
- 付録G：用語索引

## 原稿を直すとき
```bash
pandoc book.md -o spec-driven-development-6th.epub --css kindle.css --toc --toc-depth=2 -M lang=ja --split-level=1 --resource-path=.
pandoc book.md -o spec-driven-development-6th.docx --toc --reference-doc=reference-jp.docx -M lang=ja --resource-path=.
```

## 確かめたこと・確かめていないこと
| 項目 | 状態 |
|---|---|
| EPUB の構造、全 XML の整形、言語 ja、書名、図12点 | 確認済み |
| Word 版：開けること、見出し、表、図12点 | 確認済み |
| 用語の定義（ISTQB 用語集、回帰テストの定義） | 確認済み（公式の用語集の掲載内容を検索で確認） |
| ISO/IEC 25010：2011年版の8特性 | 確認済み（解説資料による。規格の本文は未確認） |
| ISO/IEC 25010：2023年改訂の内容 | 未確認（解説資料の説明のみ。規格の公式本文で確かめる） |
| bisect の検証 | 確認済み（4つの版のテスト用リポジトリ） |
| 回帰試験の数字（70→77、同じ66、変わった0、消えた0） | 確認済み（記録と一致） |
| Kindle Previewer での表示 | 未確認 |
